import {randomUUID} from 'node:crypto';
import {statfs,writeFile,mkdir,rename} from 'node:fs/promises';
import {dirname,parse,resolve} from 'node:path';
export class DownloadPool {
 constructor({limit=3,queue=null,blocked=()=>false}={}){Object.assign(this,{limit,queue,blocked});this.jobs=new Map();this.pending=[];this.active=new Set();this.files=new Map();this.reservations=new Map();this.timer=setInterval(()=>this.pump(),300);this.timer.unref();}
 get busy(){return this.active.size>0||this.pending.some(job=>job.state==='queued');}
 public(job){return {id:job.id,kind:'download',label:job.label,category:job.category,key:job.key,state:job.state,position:job.state==='queued'?this.pending.filter(j=>j.state==='queued').indexOf(job)+1:0,message:job.message,downloaded:job.downloaded||0,total:job.total||0,progress:job.state==='done'?100:job.total?Math.min(99,Math.floor(100*(job.downloaded||0)/job.total)):null,created:job.created,result:job.result,error:job.error};}
 status(){this.prune();return {limit:this.limit,busy:this.busy,jobs:[...this.jobs.values()].map(job=>this.public(job))};}
 emit(job,event){const item={sequence:job.events.length,...event};job.events.push(item);if(job.events.length>200)job.events.shift();for(const listener of job.listeners)listener(item);}
 submit(owner,{category,key,label,timeout=6*3600000},run){
  this.prune();if([...this.jobs.values()].some(job=>job.key===key&&['queued','running'].includes(job.state)))throw Error('Questo modello è già in download o in attesa.');
  if(this.pending.filter(job=>job.state==='queued').length>=30)throw Error('La coda dei download è piena. Attendi o annulla un download.');
  const job={id:randomUUID(),owner,category,key,label,run,timeout,state:'queued',message:'In attesa',text:'',events:[],listeners:new Set(),controller:new AbortController(),created:Date.now(),result:null,error:null,downloadPool:this};
  job.promise=new Promise((resolve,reject)=>{job.resolve=resolve;job.reject=reject});job.promise.catch(()=>{});this.jobs.set(job.id,job);this.queue?.jobs.set(job.id,job);this.pending.push(job);this.pump();return job;
 }
 pump(){
  this.pending=this.pending.filter(job=>job.state==='queued');
  while(!this.blocked()&&this.active.size<this.limit&&this.pending.length){
   const job=this.pending.shift();this.active.add(job.id);job.state='running';job.message='Preparazione del download';this.emit(job,{kind:'state',state:'running',label:job.label});
   const signal=AbortSignal.any([job.controller.signal,AbortSignal.timeout(job.timeout)]);
   Promise.resolve().then(()=>job.run(signal,value=>{Object.assign(job,value);this.emit(job,{kind:'state',state:'running',label:job.label});})).then(result=>{signal.throwIfAborted();job.result=result;job.state='done';job.message=result?.message||'Download completato';this.emit(job,{kind:'done',result});job.resolve(result);}).catch(error=>{job.state=job.controller.signal.aborted?'cancelled':'error';job.error=job.controller.signal.aborted?'Download annullato':signal.aborted?'Tempo massimo del download superato':error.message;job.message=job.error;this.emit(job,{kind:job.state,error:job.error});job.reject(error);}).finally(()=>{job.finished=Date.now();job.run=null;this.active.delete(job.id);this.pump();});
  }
 }
 cancel(id,owner){const job=this.jobs.get(id);if(!job||owner&&job.owner!==owner)throw Error('Download non disponibile');if(!['queued','running'].includes(job.state))return;job.controller.abort(Error('Download annullato'));if(job.state==='queued'){job.state='cancelled';job.finished=Date.now();job.message='Download annullato';job.run=null;job.reject(job.controller.signal.reason);this.emit(job,{kind:'cancelled',error:job.message});this.pump();}}
 prune(){for(const [id,job]of this.jobs)if(job.finished&&Date.now()-job.finished>20*60000)this.jobs.delete(id);}
 async file(path,signal,run){
  signal.throwIfAborted();const key=resolve(path).toLowerCase(),previous=this.files.get(key)||Promise.resolve();let release,abort;
  const gate=new Promise(r=>release=r),tail=previous.catch(()=>{}).then(()=>gate);this.files.set(key,tail);
  tail.finally(()=>{if(this.files.get(key)===tail)this.files.delete(key);});
  try{await Promise.race([previous.catch(()=>{}),new Promise((_,reject)=>{abort=()=>reject(signal.reason);signal.addEventListener('abort',abort,{once:true});})]);signal.throwIfAborted();return await run();}
  finally{signal.removeEventListener('abort',abort);release();}
 }
 async reserve(directory,bytes,margin=0,token=randomUUID(),completed=0){
  let path=directory,disk;for(;;){try{disk=await statfs(path);break;}catch(error){if(error.code!=='ENOENT'||dirname(path)===path)throw error;path=dirname(path);}}
  const volume=parse(resolve(path)).root.toLowerCase(),reserved=[...this.reservations.entries()].filter(([id,r])=>id!==token&&r.volume===volume).reduce((n,[,r])=>n+r.bytes,0);
  const remaining=Math.max(0,bytes-completed);
  if(remaining+reserved+margin>Number(disk.bavail)*Number(disk.bsize))throw Error('Spazio insufficiente per questo modello e gli altri download in corso.');
  this.reservations.set(token,{volume,bytes:remaining});const release=()=>this.reservations.delete(token);
  release.update=downloaded=>{const reservation=this.reservations.get(token);if(reservation)reservation.bytes=Math.max(0,bytes-downloaded);};return release;
 }
 stop(){clearInterval(this.timer);for(const job of this.jobs.values())this.cancel(job.id);}
}
export function configureModelDownloads(manager,pool){
 manager.downloads=pool||new DownloadPool();let current=manager.job;
 Object.defineProperty(manager,'job',{get(){const live=current?.id&&manager.downloads.jobs.get(current.id);if(live)current=manager.downloads.public(live);return current;},set(value){current=value},configurable:true});
}
export function startModelDownload(manager,input,{category,key,label,timeout,owner='admin'}){
 if(manager.isBusy()||manager.job?.kind==='activate'&&manager.job.state==='running')throw Error('Attendi le operazioni in corso.');
 const job=manager.downloads.submit(owner,{category,key,label,timeout},(signal,progress)=>manager.install(input,signal,progress));manager.job=manager.downloads.public(job);
 job.promise.finally(()=>{if(manager.job?.id===job.id)manager.job=manager.downloads.public(job);}).catch(()=>{});return manager.job;
}
export function persistModels(manager,data){
 manager.persistence=(manager.persistence||Promise.resolve()).catch(()=>{}).then(async()=>{await mkdir(dirname(manager.file),{recursive:true});const temp=manager.file+'.'+randomUUID()+'.tmp';await writeFile(temp,JSON.stringify(data(),null,2));await rename(temp,manager.file);});return manager.persistence;
}
