param([Parameter(Mandatory=$true)][string]$NodePath,[Parameter(Mandatory=$true)][string]$Redist,[Parameter(Mandatory=$true)][string]$Result)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'prerequisites.ps1')
try {
    if (!(Test-AtlanteVisualCpp)) {
        if (!(Test-Path -LiteralPath $Redist -PathType Leaf)) { throw 'Runtime Visual C++ assente: ripetere installa.bat per scaricarlo.' }
        $signature = Get-AuthenticodeSignature -LiteralPath $Redist
        if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Microsoft Corporation') { throw 'Firma del runtime Visual C++ non valida.' }
        $p = Start-Process -FilePath $Redist -ArgumentList '/install /quiet /norestart' -Wait -PassThru -WindowStyle Hidden
        if ($p.ExitCode -notin @(0,1638,3010)) { throw "Visual C++: codice $($p.ExitCode)" }
    }
    $rule = 'Atlante Local - Private LAN'
    $existing = Get-NetFirewallRule -Name $rule -ErrorAction SilentlyContinue
    if ($existing) { $existing | Remove-NetFirewallRule }
    New-NetFirewallRule -Name $rule -DisplayName 'Atlante - rete privata locale' -Direction Inbound -Action Allow -Profile Private -RemoteAddress LocalSubnet -Protocol TCP -LocalPort 3210,3212 -Program $NodePath | Out-Null
    # System.Speech uses the Desktop voice registry. Expose installed Italian OneCore voices.
    $source = 'HKLM:\SOFTWARE\Microsoft\Speech_OneCore\Voices\Tokens'
    $target = 'HKLM:\SOFTWARE\Microsoft\Speech\Voices\Tokens'
    Get-ChildItem $source -ErrorAction SilentlyContinue | Where-Object PSChildName -Match 'ITIT' | ForEach-Object {
        if (-not (Test-Path (Join-Path $target $_.PSChildName))) { Copy-Item -LiteralPath $_.PSPath -Destination $target -Recurse }
    }
    if (!(Test-AtlanteItalianVoice)) {
        $cap = Get-WindowsCapability -Online -Name 'Language.TextToSpeech~~~it-IT~0.0.1.0'
        if ($cap.State -ne 'Installed') { Add-WindowsCapability -Online -Name $cap.Name | Out-Null }
        # Newly installed OneCore tokens may need exposing after Windows Update.
        Get-ChildItem $source -ErrorAction SilentlyContinue | Where-Object PSChildName -Match 'ITIT' | ForEach-Object {
            if (-not (Test-Path (Join-Path $target $_.PSChildName))) { Copy-Item -LiteralPath $_.PSPath -Destination $target -Recurse }
        }
    } else { Write-Host 'Voce italiana gia disponibile. Nessun download Windows Update.' }
    Set-Content -LiteralPath $Result -Value 'OK' -Encoding ASCII
} catch {
    Set-Content -LiteralPath $Result -Value $_.Exception.Message -Encoding UTF8
    exit 1
}
