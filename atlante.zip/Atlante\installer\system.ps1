param([Parameter(Mandatory=$true)][string]$NodePath,[Parameter(Mandatory=$true)][string]$Redist,[Parameter(Mandatory=$true)][string]$Result)
$ErrorActionPreference = 'Stop'
try {
    $vc = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' -ErrorAction SilentlyContinue
    if (-not $vc -or $vc.Installed -ne 1 -or [version]$vc.Version.TrimStart('v') -lt [version]'14.42.0') {
        $p = Start-Process -FilePath $Redist -ArgumentList '/install /quiet /norestart' -Wait -PassThru -WindowStyle Hidden
        if ($p.ExitCode -notin @(0,1638,3010)) { throw "Visual C++: codice $($p.ExitCode)" }
    }
    $rule = 'Atlante Local - Private LAN'
    $existing = Get-NetFirewallRule -Name $rule -ErrorAction SilentlyContinue
    if ($existing) { $existing | Remove-NetFirewallRule }
    New-NetFirewallRule -Name $rule -DisplayName 'Atlante - rete privata locale' -Direction Inbound -Action Allow -Profile Private -RemoteAddress LocalSubnet -Protocol TCP -LocalPort 3210,3212 -Program $NodePath | Out-Null
    $cap = Get-WindowsCapability -Online -Name 'Language.TextToSpeech~~~it-IT~0.0.1.0'
    if ($cap.State -ne 'Installed') { Add-WindowsCapability -Online -Name $cap.Name | Out-Null }
    # System.Speech uses the Desktop voice registry. Expose installed Italian OneCore voices.
    $source = 'HKLM:\SOFTWARE\Microsoft\Speech_OneCore\Voices\Tokens'
    $target = 'HKLM:\SOFTWARE\Microsoft\Speech\Voices\Tokens'
    Get-ChildItem $source -ErrorAction SilentlyContinue | Where-Object PSChildName -Match 'ITIT' | ForEach-Object {
        if (-not (Test-Path (Join-Path $target $_.PSChildName))) { Copy-Item -LiteralPath $_.PSPath -Destination $target -Recurse }
    }
    Set-Content -LiteralPath $Result -Value 'OK' -Encoding ASCII
} catch {
    Set-Content -LiteralPath $Result -Value $_.Exception.Message -Encoding UTF8
    exit 1
}
