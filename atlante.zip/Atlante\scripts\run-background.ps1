$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$nodePath = (Get-Command node.exe -ErrorAction SilentlyContinue).Source
$installConfig = Join-Path $projectRoot 'runtime\install.json'
if (Test-Path -LiteralPath $installConfig) {
    $config = Get-Content -LiteralPath $installConfig -Raw | ConvertFrom-Json
    $nodePath = $config.nodePath
    $env:ATLANTE_OLLAMA_PATH = $config.ollamaPath
}
if (-not $nodePath -or -not (Test-Path -LiteralPath $nodePath)) { throw 'Node.js non trovato. Eseguire installa.bat.' }
$startInfo = New-Object System.Diagnostics.ProcessStartInfo
$startInfo.FileName = $nodePath
$startInfo.Arguments = '"' + (Join-Path $PSScriptRoot 'watchdog.mjs') + '"'
$startInfo.WorkingDirectory = $projectRoot
$startInfo.UseShellExecute = $false
$startInfo.CreateNoWindow = $true
$startInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
$workerProcess = [System.Diagnostics.Process]::Start($startInfo)
$workerProcess.WaitForExit()
exit $workerProcess.ExitCode
