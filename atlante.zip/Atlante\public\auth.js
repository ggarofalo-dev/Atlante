// Share the same close control and backdrop behavior across static and dynamic dialogs.
const initialized = new WeakSet();
const closeIcon = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="m6 6 12 12M18 6 6 18"/></svg>';

function initialize(dialog) {
 if (initialized.has(dialog)) return;
 initialized.add(dialog);
 const title = dialog.querySelector('h2');
 let close = [...dialog.querySelectorAll('button')].find(button => button.textContent.trim() === 'Chiudi' || button.id === 'setup-later');
 const originalForm = close?.closest('form');
 const nativeClose = originalForm?.getAttribute('method') === 'dialog';
 if (!close) {
  close = document.createElement('button');
  close.addEventListener('click', () => dialog.requestClose());
 } else if (nativeClose) {
  close.addEventListener('click', () => dialog.close());
 }
 close.type = 'button';
 close.classList.add('modal-close', 'icon-button');
 close.setAttribute('aria-label', 'Chiudi finestra');
 close.title = 'Chiudi finestra';
 close.innerHTML = closeIcon;
 const header = document.createElement('div');
 header.className = 'modal-heading';
 const oldHeading = title?.parentElement;
 if (title) header.append(title);
 header.append(close);
 dialog.prepend(header);
 if (nativeClose && !originalForm.children.length) originalForm.remove();
 if (oldHeading !== dialog && oldHeading && !oldHeading.children.length) oldHeading.remove();

 const outside = event => {
  if (event.target !== dialog) return false;
  const bounds = dialog.getBoundingClientRect();
  return event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom;
 };
 let startedOutside = false;
 dialog.addEventListener('pointerdown', event => { startedOutside = outside(event); });
 dialog.addEventListener('pointercancel', () => { startedOutside = false; });
 dialog.addEventListener('click', event => {
  if (startedOutside && outside(event)) close.click();
  startedOutside = false;
 });
 dialog.addEventListener('close', () => { startedOutside = false; });
}

function scan(root) {
 if (root instanceof HTMLDialogElement) initialize(root);
 root.querySelectorAll?.('dialog').forEach(initialize);
}
scan(document);
new MutationObserver(records => {
 for (const record of records) for (const node of record.addedNodes) scan(node);
}).observe(document.body, {childList: true, subtree: true});

const $=id=>document.getElementById(id);
const originalFetch=window.fetch.bind(window);
function closeMenu(){if(document.body.classList.contains('sidebar-open'))$('sidebar-close').click();}
window.fetch=async(...args)=>{const response=await originalFetch(...args);if(response.status===401)location.replace('/login');return response;};
async function request(path,body){const response=await fetch('/api/'+path,body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{});const result=await response.json();if(!response.ok)throw Error(result.error);return result;}
try{
 const {user}=await request('auth/me');window.atlanteUser=user;
 $('account-name').textContent=user.username;
 $('users-open').hidden=!user.admin;
 $('library-section').hidden=!(user.admin||user.library);
 $('password-open').onclick=()=>{closeMenu();$('password-form').reset();$('password-error').textContent='';$('password-dialog').showModal();};
 $('password-form').onsubmit=async e=>{e.preventDefault();$('password-error').textContent='';if($('password-new').value!==$('password-repeat').value){$('password-error').textContent='Le nuove password non coincidono';return;}$('password-save').disabled=true;try{await request('auth/password',{current:$('password-current').value,password:$('password-new').value});location.replace('/login');}catch(error){$('password-error').textContent=error.message;}finally{$('password-save').disabled=false;}};
 $('logout').onclick=async()=>{try{await request('auth/logout',{});location.replace('/login');}catch(e){alert(e.message);}};
 let editing=null;
 function editUser(item){editing=item?.id||null;$('user-form').reset();$('user-editor').hidden=false;$('user-editor-title').textContent=item?'Modifica '+item.username:'Nuovo utente';$('user-name').value=item?.username||'';$('user-name').disabled=!!item;$('user-password').required=!item;$('user-admin').checked=item?.admin||false;$('user-library').checked=item?.library||false;$('user-enabled').checked=item?.enabled??true;$('user-error').textContent='';$('user-name').focus();}
 async function refreshUsers(){
  const {users}=await request('users');$('users-list').replaceChildren();
  for(const item of users){const row=document.createElement('div');row.className='user-row';const text=document.createElement('span');text.textContent=item.username+(item.admin?' · Admin':'')+(item.library?' · Biblioteca':'')+(!item.enabled?' · Disabilitato':'');
   const edit=document.createElement('button');edit.type='button';edit.textContent='Modifica';edit.onclick=()=>editUser(item);
   const remove=document.createElement('button');remove.type='button';remove.textContent='Elimina';remove.disabled=item.id===user.id;remove.onclick=async()=>{if(!confirm('Eliminare l’account '+item.username+'? Non potrà più accedere.'))return;try{await request('users/delete',{id:item.id});await refreshUsers();}catch(e){$('users-error').textContent=e.message;}};
   row.append(text,edit,remove);$('users-list').append(row);
  }
 }
 $('users-open').onclick=async()=>{closeMenu();$('user-editor').hidden=true;$('users-error').textContent='';$('users-dialog').showModal();try{await refreshUsers();}catch(e){$('users-error').textContent=e.message;}};
 $('user-new').onclick=()=>editUser(null);$('user-cancel').onclick=()=>{$('user-editor').hidden=true;};
 $('user-form').onsubmit=async e=>{e.preventDefault();$('user-save').disabled=true;try{await request('users/save',{id:editing||undefined,username:$('user-name').value.trim(),password:$('user-password').value,admin:$('user-admin').checked,library:$('user-library').checked,enabled:$('user-enabled').checked});if(editing===user.id&&$('user-password').value){location.replace('/login');return;}$('user-editor').hidden=true;await refreshUsers();if(editing===user.id)location.reload();}catch(error){$('user-error').textContent=error.message;}finally{$('user-save').disabled=false;}};
 await import('/app.js');await import('/devices.js');
 await import('/organize.js');await import('/maintenance.js');await import('/setup.js');await import('/models.js');await import('/diagnostics.js');await import('/workspace.js');await import('/integrations.js');await import('/collaboration.js');
 await import('/codeg.js');
 await import('/image-studio.js');
 await import('/prompts.js');
 await import('/response-settings.js');
 await import('/api-access.js');
 await import('/sidebar.js');
 window.atlanteReady=true;
}catch(error){if(!window.atlanteUser)location.replace('/login');else console.error(error);}
