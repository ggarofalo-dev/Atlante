const $=id=>document.getElementById(id);
const originalFetch=window.fetch.bind(window);
function closeMenu(){if(document.body.classList.contains('sidebar-open'))$('sidebar-close').click();}
window.fetch=async(...args)=>{const response=await originalFetch(...args);if(response.status===401)location.replace('/login');return response;};
async function request(path,body){const response=await fetch('/api/'+path,body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{});const result=await response.json();if(!response.ok)throw Error(result.error);return result;}
try{
 const {user}=await request('auth/me');window.atlanteUser=user;
 $('account-name').textContent=user.username;
 $('users-open').hidden=!user.admin;
 $('library-section').hidden=!(user.admin||user.library);
 $('password-open').onclick=()=>{closeMenu();$('password-form').reset();$('password-error').textContent='';$('password-dialog').showModal();};
 $('password-form').onsubmit=async e=>{e.preventDefault();$('password-error').textContent='';if($('password-new').value!==$('password-repeat').value){$('password-error').textContent='Le nuove password non coincidono';return;}$('password-save').disabled=true;try{await request('auth/password',{current:$('password-current').value,password:$('password-new').value});location.replace('/login');}catch(error){$('password-error').textContent=error.message;}finally{$('password-save').disabled=false;}};
 $('logout').onclick=async()=>{try{await request('auth/logout',{});location.replace('/login');}catch(e){alert(e.message);}};
 let editing=null;
 function editUser(item){editing=item?.id||null;$('user-form').reset();$('user-editor').hidden=false;$('user-editor-title').textContent=item?'Modifica '+item.username:'Nuovo utente';$('user-name').value=item?.username||'';$('user-name').disabled=!!item;$('user-password').required=!item;$('user-admin').checked=item?.admin||false;$('user-library').checked=item?.library||false;$('user-enabled').checked=item?.enabled??true;$('user-error').textContent='';$('user-name').focus();}
 async function refreshUsers(){
  const {users}=await request('users');$('users-list').replaceChildren();
  for(const item of users){const row=document.createElement('div');row.className='user-row';const text=document.createElement('span');text.textContent=item.username+(item.admin?' · Admin':'')+(item.library?' · Biblioteca':'')+(!item.enabled?' · Disabilitato':'');
   const edit=document.createElement('button');edit.type='button';edit.textContent='Modifica';edit.onclick=()=>editUser(item);
   const remove=document.createElement('button');remove.type='button';remove.textContent='Elimina';remove.disabled=item.id===user.id;remove.onclick=async()=>{if(!confirm('Eliminare l’account '+item.username+'? Non potrà più accedere.'))return;try{await request('users/delete',{id:item.id});await refreshUsers();}catch(e){$('users-error').textContent=e.message;}};
   row.append(text,edit,remove);$('users-list').append(row);
  }
 }
 $('users-open').onclick=async()=>{closeMenu();$('user-editor').hidden=true;$('users-error').textContent='';$('users-dialog').showModal();try{await refreshUsers();}catch(e){$('users-error').textContent=e.message;}};
 $('user-new').onclick=()=>editUser(null);$('user-cancel').onclick=()=>{$('user-editor').hidden=true;};
 $('user-form').onsubmit=async e=>{e.preventDefault();$('user-save').disabled=true;try{await request('users/save',{id:editing||undefined,username:$('user-name').value.trim(),password:$('user-password').value,admin:$('user-admin').checked,library:$('user-library').checked,enabled:$('user-enabled').checked});if(editing===user.id&&$('user-password').value){location.replace('/login');return;}$('user-editor').hidden=true;await refreshUsers();if(editing===user.id)location.reload();}catch(error){$('user-error').textContent=error.message;}finally{$('user-save').disabled=false;}};
 await import('/app.js');await import('/devices.js');
 await import('/organize.js');await import('/maintenance.js');await import('/setup.js');await import('/models.js');await import('/diagnostics.js');await import('/workspace.js');await import('/integrations.js');await import('/collaboration.js');
 await import('/codeg.js');
 await import('/image-studio.js');
 await import('/prompts.js');
 await import('/response-settings.js');
 await import('/api-access.js');
 await import('/sidebar.js');
 window.atlanteReady=true;
}catch(error){if(!window.atlanteUser)location.replace('/login');else console.error(error);}
