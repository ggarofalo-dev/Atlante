Option Explicit
Dim shell, files, folder, gui, command
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
folder = files.GetParentFolderName(WScript.ScriptFullName)
gui = files.BuildPath(folder, "installer\gui.ps1")
If Not files.FileExists(gui) Then gui = files.BuildPath(folder, "gui.ps1")
If Not files.FileExists(gui) Then
    MsgBox "File dell'installer mancanti. Estrai tutto lo ZIP e riprova.", vbCritical, "Installa Atlante"
    WScript.Quit 1
End If
command = "powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & gui & """"
shell.Run command, 0, False
