export class SpeechTurn{
 constructor(){this.reset();}
 reset(){this.frames=[];this.started=false;this.voiced=0;this.silence=0;this.duration=0;this.noise=.003;}
 feed(samples,rate){
  const ms=samples.length/rate*1000;let energy=0;for(const value of samples)energy+=value*value;const rms=Math.sqrt(energy/samples.length),speech=rms>Math.max(.009,Math.min(.06,this.noise*2.8));
  if(!this.started&&!speech)this.noise=this.noise*.95+rms*.05;
  this.frames.push(samples);
  if(!this.started){if(this.frames.length>6)this.frames.shift();this.voiced=speech?this.voiced+ms:0;if(this.voiced>=120){this.started=true;this.duration=this.frames.reduce((n,f)=>n+f.length/rate*1000,0);}return {started:this.started,ended:false};}
  this.duration+=ms;this.silence=speech?0:this.silence+ms;
  return {started:true,ended:this.silence>=1400||this.duration>=58000};
 }
}
