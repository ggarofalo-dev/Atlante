import {load} from 'cheerio';
import {readPage} from './browser.mjs';
export function currentWeek(now=new Date()){
 const day=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Rome',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
 const date=new Date(day+'T12:00:00Z');date.setUTCDate(date.getUTCDate()-((date.getUTCDay()+6)%7));
 const start=date.toISOString().slice(0,10);date.setUTCDate(date.getUTCDate()+6);return {start,end:date.toISOString().slice(0,10)};
}
export function wantsWeb(message){
 if(/\b(?:non|senza)\s+(?:cercare|usare|internet|web|ricerc)/i.test(message))return false;
 return /\b(?:online|on-line|internet|cerca sul web|cerca in rete|cerca online|tempo reale|aggiornat[oaie]|ultim[oaie] (?:notizie|novità|aggiornamenti)|questa settimana|questo mese|oggi|attualmente|in questi giorni)\b/i.test(message)||/\b(?:trovami|cerca|recupera)\b.*\b(?:film|notizie|prezzi|meteo|orari|uscite|eventi|dati|informazioni)\b/i.test(message);
}
export function searchQuery(message){return message.replace(/^\s*(?:puoi\s+)?(?:per favore\s+)?(?:trovami|cercami|cerca|recupera|dimmi|mostrami)\s+/i,'').replace(/https?:\/\/\S+/g,'').trim().slice(0,350);}
export function parseResults(html){
 const $=load(html),results=[];
 $('.result').each((_i,node)=>{const el=$(node),anchor=el.find('.result__a'),title=anchor.text().trim();try{let url=new URL(anchor.attr('href'),'https://html.duckduckgo.com');if(url.hostname.endsWith('duckduckgo.com')&&url.searchParams.has('uddg'))url=new URL(url.searchParams.get('uddg'));if(!['http:','https:'].includes(url.protocol)||!title||url.hostname.endsWith('duckduckgo.com')||results.some(r=>r.url===url.href))return;results.push({title,url:url.href,text:el.find('.result__snippet').text().replace(/\s+/g,' ').trim()});}catch{}});
 if(!results.length&&/anomaly|captcha|challenge-form/i.test(html))throw Error('Il motore di ricerca richiede una verifica anti-bot. Riprova più tardi o incolla una URL.');
 return results.slice(0,5);
}
export function parseGoogleResults(html){
 if(/\/sorry\/|g-recaptcha|unusual traffic|traffico insolito|consent\.google\./i.test(html))throw Error('Google richiede consenso o verifica anti-bot.');
 const $=load(html),results=[];
 $('h3').each((_i,node)=>{const heading=$(node),anchor=heading.closest('a[href]');if(!anchor.length)return;try{
  let url=new URL(anchor.attr('href'),'https://www.google.com');
  if(url.hostname==='www.google.com'&&url.pathname==='/url')url=new URL(url.searchParams.get('q')||url.searchParams.get('url'));
  if(!['http:','https:'].includes(url.protocol)||url.username||url.password||/(^|\.)google\.[a-z.]+$/i.test(url.hostname)||results.some(r=>r.url===url.href))return;
  const title=heading.text().trim();if(!title)return;
  const container=heading.closest('div.MjjYud,div.g,div.Gx5Zad');
  const text=container.find('.VwiC3b,.BNeawe,.IsZvec,[data-sncf]').first().text().replace(/\s+/g,' ').trim().slice(0,1800);
  results.push({title,url:url.href,text});
 }catch{}});
 if(!results.length&&/enablejs|enable JavaScript/i.test(html))throw Error('Google richiede JavaScript per mostrare i risultati.');
 return results.slice(0,5);
}
export function preferredSearchResults(hits){
 const selected=hits.slice(0,3);
 const wikidata=hits.find(hit=>{try{const url=new URL(hit.url);return /^(?:www\.)?wikidata\.org$/i.test(url.hostname)&&/^\/wiki\/(?:Q\d+|Property:P\d+)$/.test(url.pathname);}catch{return false;}});
 if(wikidata&&!selected.includes(wikidata))selected.splice(2,1,wikidata);
 return selected;
}
export async function liveSearch(message,{fetcher=fetch,reader=readPage,now=new Date(),signal,engine='auto'}={}){
 signal?.throwIfAborted();
 if(!['auto','google','duckduckgo'].includes(engine))throw Error('Motore di ricerca non valido');
 const query=searchQuery(message);if(!query)throw Error('Specifica una ricerca');
 let hits=[],usedEngine,warning=null;const failures=[];
 for(const provider of engine==='auto'?['google','duckduckgo']:[engine]){
  signal?.throwIfAborted();
  try{
   const url=provider==='google'?'https://www.google.com/search?'+new URLSearchParams({q:query,hl:'it',gl:'it'}):'https://html.duckduckgo.com/html/?'+new URLSearchParams({q:query,kl:'it-it'});
   const response=await fetcher(url,{headers:{'User-Agent':'Mozilla/5.0 (compatible; AtlanteLocal/0.2)','Accept':'text/html'},signal:signal?AbortSignal.any([signal,AbortSignal.timeout(12000)]):AbortSignal.timeout(12000)});
   if(!response.ok)throw Error('HTTP '+response.status);
   const html=await response.text();if(html.length>2000000)throw Error('Risposta di ricerca troppo grande');
   hits=provider==='google'?parseGoogleResults(html):parseResults(html);
   if(!hits.length)throw Error('Nessun risultato leggibile');
   usedEngine=provider;if(failures.length)warning='Google non disponibile ('+failures[0]+'): ricerca eseguita con DuckDuckGo.';break;
  }catch(error){signal?.throwIfAborted();failures.push(error.message);}
 }
 if(!hits.length)throw Error('Ricerca online non disponibile: '+failures.join('; '));
 const pages=await Promise.all(preferredSearchResults(hits).map(async hit=>{try{const page=await reader(hit.url);return {...page,text:page.text.slice(0,6500),kind:'pagina web letta ora',live:true,fetchedAt:now.toISOString()};}catch{return {...hit,text:hit.text,links:[],kind:'estratto del motore di ricerca, pagina non letta',live:true,fetchedAt:now.toISOString()};}}));
 signal?.throwIfAborted();return {pages:pages.filter(p=>p.text),query,checkedAt:now.toISOString(),engine:usedEngine,warning};
}
