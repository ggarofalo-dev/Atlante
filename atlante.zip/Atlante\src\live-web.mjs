import {load} from 'cheerio';
import {readPage} from './browser.mjs';
export function currentWeek(now=new Date()){
 const day=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Rome',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
 const date=new Date(day+'T12:00:00Z');date.setUTCDate(date.getUTCDate()-((date.getUTCDay()+6)%7));
 const start=date.toISOString().slice(0,10);date.setUTCDate(date.getUTCDate()+6);return {start,end:date.toISOString().slice(0,10)};
}
export function wantsWeb(message){
 if(/\b(?:non|senza)\s+(?:cercare|usare|internet|web|ricerc)/i.test(message))return false;
 return /\b(?:online|on-line|internet|cerca sul web|cerca in rete|cerca online|tempo reale|aggiornat[oaie]|ultim[oaie] (?:notizie|novità|aggiornamenti)|questa settimana|questo mese|oggi|attualmente|in questi giorni)\b/i.test(message)||/\b(?:trovami|cerca|recupera)\b.*\b(?:film|notizie|prezzi|meteo|orari|uscite|eventi|dati|informazioni)\b/i.test(message);
}
export function searchQuery(message){return message.replace(/^\s*(?:puoi\s+)?(?:per favore\s+)?(?:trovami|cercami|cerca|recupera|dimmi|mostrami)\s+/i,'').replace(/https?:\/\/\S+/g,'').trim().slice(0,350);}
export function parseResults(html){
 const $=load(html),results=[];
 $('.result').each((_i,node)=>{const el=$(node),anchor=el.find('.result__a'),title=anchor.text().trim();try{let url=new URL(anchor.attr('href'),'https://html.duckduckgo.com');if(url.hostname.endsWith('duckduckgo.com')&&url.searchParams.has('uddg'))url=new URL(url.searchParams.get('uddg'));if(!['http:','https:'].includes(url.protocol)||!title||url.hostname.endsWith('duckduckgo.com')||results.some(r=>r.url===url.href))return;results.push({title,url:url.href,text:el.find('.result__snippet').text().replace(/\s+/g,' ').trim()});}catch{}});
 if(!results.length&&/anomaly|captcha|challenge-form/i.test(html))throw Error('Il motore di ricerca richiede una verifica anti-bot. Riprova più tardi o incolla una URL.');
 return results.slice(0,5);
}
export async function liveSearch(message,{fetcher=fetch,reader=readPage,now=new Date(),signal}={}){
 signal?.throwIfAborted();
 const query=searchQuery(message),url='https://html.duckduckgo.com/html/?'+new URLSearchParams({q:query,kl:'it-it'});
 const response=await fetcher(url,{headers:{'User-Agent':'Mozilla/5.0 (compatible; AtlanteLocal/0.2)','Accept':'text/html'},signal:signal?AbortSignal.any([signal,AbortSignal.timeout(20000)]):AbortSignal.timeout(20000)});
 if(!response.ok)throw Error('Motore di ricerca HTTP '+response.status);
 const html=await response.text();if(html.length>2000000)throw Error('Risposta di ricerca troppo grande');
 const hits=parseResults(html);if(!hits.length)throw Error('Nessun risultato web disponibile. Prova una ricerca più specifica.');
 const pages=await Promise.all(hits.slice(0,3).map(async hit=>{try{const page=await reader(hit.url);return {...page,text:page.text.slice(0,6500),kind:'pagina web letta ora',live:true,fetchedAt:now.toISOString()};}catch{return {...hit,text:hit.text,links:[],kind:'estratto del motore di ricerca, pagina non letta',live:true,fetchedAt:now.toISOString()};}}));
 signal?.throwIfAborted();return {pages:pages.filter(p=>p.text),query,checkedAt:now.toISOString()};
}
