// The backend connects to Ollama; browsers always use the Atlante server.
const endpoint=new URL(process.env.ATLANTE_OLLAMA_URL||'http://127.0.0.1:11434');
if(!['http:','https:'].includes(endpoint.protocol)||endpoint.username||endpoint.password||endpoint.search||endpoint.hash)throw Error('Indirizzo Ollama non valido');
export const ollamaBase=endpoint.href.replace(/\/$/,'');
