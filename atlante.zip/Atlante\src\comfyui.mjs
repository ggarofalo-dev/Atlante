import sharp from 'sharp';
import {randomUUID} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {decodeImage} from './images.mjs';

export function localComfyUrl(value){
 const u=new URL(value);if(u.protocol!=='http:'||!['127.0.0.1','[::1]'].includes(u.hostname)||u.username||u.password||u.search||u.hash||u.pathname!=='/')throw Error('ComfyUI deve essere sullo stesso PC: http://127.0.0.1:8188');return u.origin;
}
const allowed=new Set(['CheckpointLoaderSimple','CLIPTextEncode','KSampler','EmptyLatentImage','VAEDecode','VAEEncode','VAEEncodeForInpaint','LoadImage','ImageToMask','SetLatentNoiseMask','SaveImage','FluxGuidance','EmptySD3LatentImage']);
export function validateWorkflow(graph){
 if(!graph||typeof graph!=='object'||Array.isArray(graph)||Object.keys(graph).length>100||!Object.keys(graph).length)throw Error('Importa un workflow JSON in formato API, massimo 100 nodi');
 for(const [id,node]of Object.entries(graph)){if(!/^\d+$/.test(id)||!allowed.has(node?.class_type)||!node.inputs||typeof node.inputs!=='object'||Array.isArray(node.inputs))throw Error('Workflow non supportato: sono ammessi solo i nodi locali standard di generazione, codifica, maschera e salvataggio');}
 if(!Object.values(graph).some(n=>n.class_type==='SaveImage'))throw Error('Il workflow deve contenere SaveImage');return graph;
}
export function bindWorkflow(graph,values){
 validateWorkflow(graph);const bind=value=>{if(typeof value==='string'){const m=value.match(/^\{\{(\w+)\}\}$/);if(m){if(values[m[1]]===undefined)throw Error('Valore workflow mancante: '+m[1]);return values[m[1]];}return value;}if(Array.isArray(value))return value.map(bind);if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,bind(v)]));return value;};return bind(graph);
}
export function standardWorkflow(p,{image,mask}={}){
 const g={'1':{class_type:'CheckpointLoaderSimple',inputs:{ckpt_name:p.checkpoint}},'2':{class_type:'CLIPTextEncode',inputs:{text:p.prompt,clip:['1',1]}},'3':{class_type:'CLIPTextEncode',inputs:{text:p.negative,clip:['1',1]}},'4':{class_type:'EmptyLatentImage',inputs:{width:p.width,height:p.height,batch_size:1}},'5':{class_type:'KSampler',inputs:{seed:p.seed,steps:p.steps,cfg:p.cfg,sampler_name:p.sampler,scheduler:p.scheduler,denoise:image?p.strength:1,model:['1',0],positive:['2',0],negative:['3',0],latent_image:['4',0]}},'6':{class_type:'VAEDecode',inputs:{samples:['5',0],vae:['1',2]}},'7':{class_type:'SaveImage',inputs:{filename_prefix:'Atlante',images:['6',0]}}};
 if(p.architecture==='flux1'){g['4']={class_type:'EmptySD3LatentImage',inputs:{width:p.width,height:p.height,batch_size:1}};g['10']={class_type:'FluxGuidance',inputs:{conditioning:['2',0],guidance:3.5}};g['5'].inputs.positive=['10',0];g['5'].inputs.cfg=1;}
 if(image){g['8']={class_type:'LoadImage',inputs:{image}};g['4']={class_type:'VAEEncode',inputs:{pixels:['8',0],vae:['1',2]}};}
 if(mask){g['9']={class_type:'LoadImage',inputs:{image:mask}};g['10']={class_type:'ImageToMask',inputs:{image:['9',0],channel:'red'}};g['4']={class_type:'VAEEncodeForInpaint',inputs:{pixels:['8',0],vae:['1',2],mask:['10',0],grow_mask_by:0}};}
 return g;
}
export class ComfyUI {
 constructor(url,{request=fetch,pollMs=1000}={}){this.url=localComfyUrl(url);this.request=request;this.pollMs=pollMs;}
 async api(path,{method='GET',body,signal}={}){const r=await this.request(this.url+path,{method,body:body instanceof FormData?body:body===undefined?undefined:JSON.stringify(body),headers:body instanceof FormData?undefined:{'Content-Type':'application/json'},redirect:'error',signal:AbortSignal.any([...(signal?[signal]:[]),AbortSignal.timeout(30000)])});if(!r.ok)throw Error('ComfyUI: '+(await r.text()).slice(0,700));return r;}
 async catalog(signal){const info=await(await this.api('/object_info',{signal})).json();return {checkpoints:(info.CheckpointLoaderSimple?.input?.required?.ckpt_name?.[0]||[]).filter(n=>/\.(safetensors|ckpt|pt)$/i.test(n)),samplers:info.KSampler?.input?.required?.sampler_name?.[0]||[],schedulers:info.KSampler?.input?.required?.scheduler?.[0]||[]};}
 async upload(bytes,signal){const data=new FormData();data.set('image',new Blob([bytes],{type:'image/png'}),'atlante-'+randomUUID()+'.png');data.set('type','input');const result=await(await this.api('/upload/image',{method:'POST',body:data,signal})).json();if(typeof result.name!=='string'||result.name.includes('..')||/^[\\/]|:/.test(result.name))throw Error('Nome immagine ComfyUI non valido');return result.subfolder?result.subfolder+'/'+result.name:result.name;}
 async generate(p,signal,onProgress=()=>{}){
  const combined=AbortSignal.any([...(signal?[signal]:[]),AbortSignal.timeout(15*60*1000)]);combined.throwIfAborted();let imageName,maskName,original,maskBytes,id,completed=false;
  if(p.image){const {bytes}=await decodeImage(p.image);original=await sharp(bytes).rotate().resize(p.width,p.height,{fit:'fill'}).png().toBuffer();imageName=await this.upload(original,combined);}
  if(p.mask){if(!original)throw Error('La maschera richiede un’immagine');const {bytes,meta}=await decodeImage(p.mask);if(meta.width!==p.width||meta.height!==p.height)throw Error('La maschera deve avere le dimensioni della generazione');maskBytes=await sharp(bytes).removeAlpha().greyscale().png().toBuffer();maskName=await this.upload(maskBytes,combined);}
  const graph=p.workflow?bindWorkflow(p.workflow,{...p,image:imageName,mask:maskName}):standardWorkflow(p,{image:imageName,mask:maskName});validateWorkflow(graph);
  try{
   const queued=await(await this.api('/prompt',{method:'POST',body:{prompt:graph,client_id:randomUUID()},signal:combined})).json();if(!queued.prompt_id||queued.error)throw Error('Workflow rifiutato da ComfyUI: '+JSON.stringify(queued.error||queued.node_errors||{}));id=queued.prompt_id;
   for(;;){combined.throwIfAborted();const history=await(await this.api('/history/'+encodeURIComponent(id),{signal:combined})).json(),job=history[id];
    if(job?.status?.status_str==='error')throw Error('Workflow ComfyUI fallito: '+JSON.stringify(job.status.messages||[]).slice(0,700));
    if(job?.status?.completed){const entry=Object.values(job.outputs||{}).flatMap(o=>o.images||[]).find(i=>i.type==='output');if(!entry)throw Error('ComfyUI non ha prodotto un’immagine');const q=new URLSearchParams({filename:entry.filename,subfolder:entry.subfolder||'',type:'output'});const response=await this.api('/view?'+q,{signal:combined});const length=Number(response.headers.get('content-length')||0);if(length>20*1024*1024)throw Error('Immagine ComfyUI troppo grande');let size=0;const chunks=[];for await(const c of response.body){size+=c.length;if(size>20*1024*1024)throw Error('Immagine ComfyUI troppo grande');chunks.push(c);}let output=await sharp(Buffer.concat(chunks),{limitInputPixels:25000000}).png().toBuffer();
     if(maskBytes){const a=await sharp(original).ensureAlpha().raw().toBuffer(),b=await sharp(output).resize(p.width,p.height).ensureAlpha().raw().toBuffer(),m=await sharp(maskBytes).greyscale().raw().toBuffer();for(let i=0;i<m.length;i++){const weight=m[i]/255;for(let c=0;c<4;c++)b[i*4+c]=Math.round(a[i*4+c]*(1-weight)+b[i*4+c]*weight);}output=await sharp(b,{raw:{width:p.width,height:p.height,channels:4}}).png().toBuffer();}
     completed=true;return output;
    }
    onProgress('ComfyUI: generazione in corso');await delay(this.pollMs,undefined,{signal:combined});
   }
  }finally{if(combined.aborted&&id){try{await this.api('/queue',{method:'POST',body:{delete:[id]}});await this.api('/interrupt',{method:'POST',body:{prompt_id:id}});}catch{}}if(completed){try{const queue=await(await this.api('/queue')).json();if(!queue.queue_running?.length&&!queue.queue_pending?.length)await this.api('/free',{method:'POST',body:{unload_models:true,free_memory:true}});}catch{}}}
 }
}
