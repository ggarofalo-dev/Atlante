import {existsSync,createWriteStream,readFileSync} from 'node:fs';
import {mkdir,writeFile,rename} from 'node:fs/promises';
import {join} from 'node:path';
import {spawn} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {detectHardware} from './setup.mjs';
import {ComfyUI} from './comfyui.mjs';

export function recommendImages(hardware){
 const gpu=(hardware.gpus||[]).filter(g=>g.memorySource==='NVIDIA'&&g.memoryGB>=4).sort((a,b)=>b.memoryGB-a.memoryGB)[0];
 return gpu?{backend:'comfyui',device:gpu.name,reason:'Scheda NVIDIA rilevata: verifichiamo l’accelerazione prima di attivarla.'}:{backend:'sd',device:'CPU',reason:'Nessuna scheda NVIDIA con almeno 4 GB verificata: uso del processore.'};
}
export class ImageRuntime{
 constructor({root,settings,hardware=()=>detectHardware(root),request=fetch,run,probe,isBusy=()=>false,lock=()=>{},unlock=()=>{}}){
  Object.assign(this,{root,settings,hardware,request,isBusy,lock,unlock});this.run=run||((file,args,signal)=>this.command(file,args,signal));this.job=null;this.controller=null;
  this.probe=probe||((config,signal)=>new ComfyUI('http://127.0.0.1:8188',{request:this.request}).generate({...config,prompt:'A simple red circle on a white background',width:256,height:256,steps:4,seed:42,customWorkflow:false,workflow:undefined},signal));
  this.file=join(root,'data/image-runtime.json');try{this.result=JSON.parse(readFileSync(this.file,'utf8'));}catch{this.result=null;}
 }
 portable(){return join(this.root,'runtime/comfyui/ComfyUI_windows_portable/python_embeded/python.exe');}
 cpuReady(){return existsSync(join(this.root,'runtime/sd/sd-cli.exe'))&&existsSync(join(this.root,'models',this.settings.get().sdModel))&&existsSync(join(this.root,'models/sd15.ready'));}
 async status(hardware){const config=this.settings.get();return {mode:this.result?.mode||'auto',backend:config.backend,device:config.backend==='comfyui'?(this.result?.device||'Scheda video da verificare'):'CPU',cpuReady:this.cpuReady(),gpuInstalled:existsSync(this.portable()),recommendation:recommendImages(hardware||await this.hardware()),result:this.result,job:this.job};}
 async command(file,args,signal){
  signal?.throwIfAborted();await mkdir(join(this.root,'data'),{recursive:true});
  return new Promise((resolve,reject)=>{
   const log=createWriteStream(join(this.root,'data/image-setup.log'),{flags:'a'}),child=spawn(file,args,{cwd:this.root,windowsHide:true,stdio:['ignore','pipe','pipe']});let tail='',ended=false;
   const collect=chunk=>{log.write(chunk);tail=(tail+chunk.toString()).slice(-5000);};child.stdout.on('data',collect);child.stderr.on('data',collect);
   const abort=()=>{if(ended)return;if(process.platform==='win32'&&child.pid){const kill=spawn('taskkill',['/PID',String(child.pid),'/T','/F'],{windowsHide:true,stdio:'ignore'});kill.on('error',()=>child.kill());}else child.kill();};signal?.addEventListener('abort',abort,{once:true});
   const finish=error=>{if(ended)return;ended=true;clearTimeout(timeout);signal?.removeEventListener('abort',abort);log.end();error?reject(error):resolve(tail);};
   const timeout=setTimeout(()=>{abort();finish(Error('Preparazione immagini troppo lunga: riprova dalla configurazione.'));},3*3600000);
   child.on('error',()=>finish(Error('Impossibile avviare la preparazione immagini.')));child.on('close',code=>finish(signal?.aborted?Error('Operazione interrotta'):code===0?null:Error('Preparazione immagini non riuscita. Dettagli in data/image-setup.log.')));
  });
 }
 async cpu(signal){if(!this.cpuReady())throw Error('Il motore immagini di base manca: esegui nuovamente l’installer Atlante.');await this.run(join(this.root,'runtime/sd/sd-cli.exe'),['--help'],AbortSignal.any([signal,AbortSignal.timeout(15000)]));}
 async configure(mode='auto',signal=new AbortController().signal,progress=()=>{}){
  if(!['auto','cpu','gpu'].includes(mode))throw Error('Modalità immagini non valida');
  progress('Riconosco la scheda video…');const hardware=await this.hardware(),recommendation=recommendImages(hardware);let result;
  const gpu=mode==='gpu'||mode==='auto'&&recommendation.backend==='comfyui';
  if(gpu){try{
   if(recommendation.backend!=='comfyui')throw Error('Non è stata rilevata una scheda NVIDIA compatibile con almeno 4 GB.');
   if(!existsSync(this.portable())){
    if(hardware.diskFreeGB===null||hardware.diskFreeGB<15)throw Error('Servono almeno 15 GB liberi per preparare l’accelerazione immagini.');
    progress('Scarico e preparo l’accelerazione immagini. Il primo download può richiedere diversi GB…');
    await this.run(join(process.env.SystemRoot||'C:/Windows','System32/WindowsPowerShell/v1.0/powershell.exe'),['-NoProfile','-ExecutionPolicy','Bypass','-File',join(this.root,'scripts/setup-comfyui.ps1')],signal);
   }
   progress('Verifico che la scheda esegua realmente i calcoli…');
   await this.run(this.portable(),['-s','-c',"import torch; assert torch.cuda.is_available(); x=torch.ones((64,64),device='cuda'); y=x@x; torch.cuda.synchronize(); assert y[0,0].item()==64; print('GPU_OK')"],AbortSignal.any([signal,AbortSignal.timeout(60000)]));
   progress('Avvio il motore immagini…');await this.run(process.execPath,[join(this.root,'scripts/start-comfyui.mjs')],AbortSignal.any([signal,AbortSignal.timeout(15000)]));
   let stats;for(let attempt=0;attempt<90;attempt++){signal.throwIfAborted();try{const response=await this.request('http://127.0.0.1:8188/system_stats',{redirect:'error',signal:AbortSignal.any([signal,AbortSignal.timeout(2500)])});if(response.ok){stats=await response.json();break;}}catch(e){signal.throwIfAborted();}await delay(2000,undefined,{signal});}
   const device=stats?.devices?.find(d=>d.type==='cuda');if(!device)throw Error('L’accelerazione GPU del motore immagini non è disponibile.');
   const catalog=await new ComfyUI('http://127.0.0.1:8188',{request:this.request}).catalog(signal),old=this.settings.get();
   const checkpoint=catalog.checkpoints.includes(old.checkpoint)?old.checkpoint:catalog.checkpoints.includes(old.sdModel)?old.sdModel:null;
   if(!checkpoint)throw Error('Il modello immagini installato non è disponibile nel motore GPU.');
   progress('Genero una piccola immagine di prova sulla scheda video…');await this.probe({...old,checkpoint},AbortSignal.any([signal,AbortSignal.timeout(180000)]));
   signal.throwIfAborted();this.settings.save({...old,backend:'comfyui',url:'http://127.0.0.1:8188',checkpoint});
   result={mode,backend:'comfyui',device:device.name,message:'Immagini pronte: accelerazione della scheda video verificata.',verified:true};
  }catch(error){signal.throwIfAborted();if(mode==='gpu')throw error;progress('Uso il motore CPU disponibile…');await this.cpu(signal);signal.throwIfAborted();this.settings.save({...this.settings.get(),backend:'sd'});result={mode,backend:'sd',device:'CPU',message:'Immagini pronte sul processore. '+error.message,verified:true,fallback:true};}}
  else{progress('Verifico il motore immagini sul processore…');await this.cpu(signal);signal.throwIfAborted();this.settings.save({...this.settings.get(),backend:'sd'});result={mode,backend:'sd',device:'CPU',message:'Immagini pronte sul processore.',verified:true};}
  result.checkedAt=new Date().toISOString();await mkdir(join(this.root,'data'),{recursive:true});const temp=this.file+'.'+randomUUID()+'.tmp';await writeFile(temp,JSON.stringify(result,null,2));await rename(temp,this.file);this.result=result;return result;
 }
 start(mode='auto'){
  if(!['auto','cpu','gpu'].includes(mode))throw Error('Modalità immagini non valida');if(this.job?.state==='running'||this.isBusy())throw Error('Attendi il completamento dell’operazione in corso.');
  this.lock();this.controller=new AbortController();const signal=this.controller.signal;this.job={kind:'images',state:'running',started:Date.now(),message:'Preparo le immagini…'};
  this.configure(mode,signal,message=>{this.job.message=message;}).then(result=>{this.job={...this.job,state:'done',message:result.message,result};}).catch(error=>{this.job={...this.job,state:signal.aborted?'cancelled':'error',message:error.message};}).finally(()=>{this.controller=null;this.unlock();});return {...this.job};
 }
 cancel(){if(this.controller){this.job.message='Interruzione in corso…';this.controller.abort();}}
}
