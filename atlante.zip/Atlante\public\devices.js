const deviceButton=document.getElementById('device-open');
const deviceDialog=document.getElementById('device-dialog');
const deviceSelect=document.getElementById('device-network');
const deviceStatus=document.getElementById('device-status');
const deviceDetails=document.getElementById('device-details');
let deviceLinks=[];
function showDevice(){
 const item=deviceLinks[Number(deviceSelect.value)];
 if(!item)return;
 document.getElementById('device-qr').src=item.qr;
 const link=document.getElementById('device-url');link.textContent=item.url;link.href=item.url;
 document.getElementById('device-copy').textContent='Copia indirizzo';
 deviceDetails.hidden=false;
}
deviceSelect.onchange=showDevice;
deviceButton.onclick=async()=>{
 if(document.body.classList.contains('sidebar-open'))document.getElementById('sidebar-close').click();
 deviceDetails.hidden=true;deviceSelect.hidden=true;deviceStatus.textContent='Cerco gli indirizzi di rete…';
 deviceDialog.showModal();
 try{
  const response=await fetch('/api/devices');const data=await response.json();
  if(!response.ok)throw Error(data.error||'Indirizzi non disponibili');
  deviceLinks=data.devices;deviceSelect.replaceChildren();
  if(!deviceLinks.length){deviceStatus.textContent='Collega il PC a una rete Wi-Fi o Ethernet e riprova.';return;}
  for(const [index,item]of deviceLinks.entries())deviceSelect.add(new Option(`${item.name} · ${item.address}`,String(index)));
  deviceSelect.hidden=deviceLinks.length<2;
  deviceStatus.textContent='Scansiona il QR code con la fotocamera del dispositivo da collegare.';
  showDevice();
 }catch(error){deviceStatus.textContent=error.message;}
};
document.getElementById('device-copy').onclick=async()=>{
 const url=deviceLinks[Number(deviceSelect.value)]?.url;if(!url)return;
 try{
  if(navigator.clipboard&&isSecureContext)await navigator.clipboard.writeText(url);
  else{
   const field=document.createElement('textarea');field.value=url;field.style.position='fixed';field.style.opacity='0';deviceDialog.append(field);field.select();
   const copied=document.execCommand('copy');field.remove();if(!copied)throw Error();
  }
  document.getElementById('device-copy').textContent='Indirizzo copiato';
 }catch{deviceStatus.textContent='Puoi selezionare e copiare l’indirizzo sotto il QR code.';}
};
