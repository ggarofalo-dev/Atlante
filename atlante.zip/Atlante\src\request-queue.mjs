import {randomUUID} from 'node:crypto';
export class RequestQueue {
 constructor({blocked=()=>false}={}){this.blocked=blocked;this.jobs=new Map();this.pending=[];this.active=null;this.lastOwner=null;this.timer=setInterval(()=>this.pump(),300);this.timer.unref();}
 submit(owner,run,{label='Richiesta',session=null}={}){
  this.prune();if(this.pending.length>=30||this.pending.filter(j=>j.owner===owner).length>=5)throw Error('La coda è piena. Attendi o annulla una richiesta.');
  const job={id:randomUUID(),owner,run,label,session,state:'queued',text:'',events:[],listeners:new Set(),controller:new AbortController(),created:Date.now(),result:null,error:null};
  job.promise=new Promise((resolve,reject)=>{job.resolve=resolve;job.reject=reject;});job.promise.catch(()=>{});this.jobs.set(job.id,job);this.pending.push(job);this.notify();this.pump();return job;
 }
 public(job){return {id:job.id,label:job.label,session:job.session,state:job.state,position:job.state==='queued'?this.pending.indexOf(job)+1:0,text:job.text,result:job.result,error:job.error,created:job.created};}
 get(id,owner){const job=this.jobs.get(id);if(!job||job.owner!==owner)throw Object.assign(Error('Richiesta non trovata'),{status:404});return job;}
 emit(job,event){const item={sequence:job.events.length,...event};job.events.push(item);for(const listener of job.listeners)listener(item);}
 notify(){for(const job of this.pending)this.emit(job,{kind:'state',state:'queued',position:this.pending.indexOf(job)+1});}
 async pump(){
  if(this.active||this.blocked()||!this.pending.length)return;
  const index=this.pending.findIndex(j=>j.owner!==this.lastOwner),job=this.pending.splice(index<0?0:index,1)[0];this.active=job;this.lastOwner=job.owner;job.state='running';this.emit(job,{kind:'state',state:'running'});this.notify();
  try{const result=await job.run(job.controller.signal,text=>{job.text+=text;if(job.text.length>200000)throw Error('Risposta troppo lunga');this.emit(job,{kind:'delta',text});},label=>{job.label=label;this.emit(job,{kind:'state',state:'running',label});});job.controller.signal.throwIfAborted();job.result=result;job.state='done';this.emit(job,{kind:'done',result});job.resolve(result);}
  catch(e){job.state=job.controller.signal.aborted?'cancelled':'error';job.error=job.state==='cancelled'?'Richiesta interrotta':e.message;this.emit(job,{kind:job.state,error:job.error,text:job.text});job.reject(e);}
  finally{job.finished=Date.now();job.run=null;this.active=null;this.pump();}
 }
 cancel(id,owner){const job=this.get(id,owner);if(!['queued','running'].includes(job.state))return;job.controller.abort(Error('Richiesta interrotta'));if(job.state==='queued'){this.pending=this.pending.filter(j=>j!==job);job.state='cancelled';job.finished=Date.now();this.emit(job,{kind:'cancelled',text:''});job.reject(job.controller.signal.reason);job.run=null;this.notify();}}
 cancelOwner(owner){for(const job of this.jobs.values())if(job.owner===owner)this.cancel(job.id,owner);}
 prune(){for(const [id,job]of this.jobs)if(job.finished&&Date.now()-job.finished>20*60000&&!job.listeners.size)this.jobs.delete(id);}
 stop(){clearInterval(this.timer);for(const job of this.jobs.values())this.cancel(job.id,job.owner);}
}
