import 'reflect-metadata';
for (const name of ['sharp','@napi-rs/canvas','pdfjs-dist/legacy/build/pdf.mjs','tesseract.js','@peculiar/x509','qrcode','adm-zip','markdown-it','dompurify','@modelcontextprotocol/sdk/client/index.js','ajv']) await import(name);
const {createRequire}=await import('node:module'),{existsSync}=await import('node:fs');if(!existsSync(createRequire(import.meta.url).resolve('@ffmpeg-installer/win32-x64/ffmpeg.exe')))throw Error('FFmpeg video non installato');
console.log('Librerie di produzione verificate');
