import 'reflect-metadata';
for (const name of ['sharp','@napi-rs/canvas','pdfjs-dist/legacy/build/pdf.mjs','tesseract.js','@peculiar/x509','qrcode','adm-zip','markdown-it','dompurify','@modelcontextprotocol/sdk/client/index.js','ajv']) await import(name);
console.log('Librerie di produzione verificate');
