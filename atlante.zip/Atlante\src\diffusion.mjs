import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {mkdir,writeFile,readFile,rm} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import sharp from 'sharp';
import {decodeImage} from './images.mjs';
import {saveArtifact} from './artifacts.mjs';
import {ollama} from './engine.mjs';
import {ImageSettings,imageParameters} from './image-settings.mjs';
import {ComfyUI} from './comfyui.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const executable=root+'runtime/sd/sd-cli.exe';
export const imageSettings=new ImageSettings(root);
export function diffusionAvailable(){const settings=imageSettings.get();return settings.backend==='comfyui'||existsSync(executable)&&existsSync(root+'models/'+settings.sdModel)&&existsSync(root+'models/sd15.ready');}
export async function generateImage(input,signal,onProgress=()=>{},config=imageSettings.get()){
 const p=imageParameters({...config,...Object.fromEntries(['width','height','steps','cfg','seed','strength','negative','sampler','scheduler'].filter(k=>input[k]!==undefined).map(k=>[k,input[k]]))});
 const model=config.backend==='comfyui'?config.checkpoint:config.sdModel;
 const imageModel=config.customWorkflow?'Workflow personalizzato':config.modelLabel|| (model==='sd15.safetensors'?'Stable Diffusion 1.5 · '+model:model);
 const progress=value=>onProgress('Modello immagini: '+imageModel+' · '+value);
 const result=async bytes=>({...await saveArtifact(bytes,'png',mask?'Ritocco con maschera':image?'Trasformazione AI':'Immagine AI'),imageModel});
 const {prompt,image,mask}=input;let {steps,strength}=p;
 signal?.throwIfAborted();
 if(!diffusionAvailable())throw Error('Motore immagini non pronto: completa il setup locale.');
 if(typeof prompt!=='string'||!prompt.trim()||prompt.length>2000)throw Error('Descrizione richiesta (massimo 2000 caratteri).');
 if(mask&&!image)throw Error('La maschera richiede un’immagine');
 progress('Preparazione motore locale');
 const running=await ollama('ps',undefined,signal);for(const m of running.models||[])await ollama('generate',{model:m.name,keep_alive:0},signal);
 if(config.backend==='comfyui'){
  const mode=mask?'inpaint':image?'transform':'generate',workflow=config.customWorkflow?config.workflows[mode]:undefined;if(config.customWorkflow&&!workflow)throw Error('Importa un workflow API per '+mode+' oppure usa il workflow standard');
  progress('Generazione locale');const bytes=await new ComfyUI(config.url).generate({...p,prompt,image,mask,workflow},signal,progress);return result(bytes);
 }
 if(mask)throw Error('Per modificare con una maschera seleziona ComfyUI nelle impostazioni immagini');
 if(!imageSettings.sdModels().includes(config.sdModel))throw Error('Modello SD non trovato');
 const dir=root+'data/image-jobs/'+randomUUID();await mkdir(dir,{recursive:true});
 try{
  await writeFile(dir+'/prompt.txt',prompt);
  const sdSampler=({euler:'euler',euler_ancestral:'euler_a',euler_a:'euler_a',heun:'heun',dpmpp_2m:'dpm++2m'})[p.sampler];const sdScheduler=({normal:'discrete',discrete:'discrete',karras:'karras',exponential:'exponential'})[p.scheduler];if(!sdSampler||!sdScheduler)throw Error('Sampler o scheduler non supportato dal motore SD locale');
  const args=['-m',root+'models/'+config.sdModel,'--prompt-file',dir+'/prompt.txt','-n',p.negative,'-o',dir+'/output.png','-W',String(p.width),'-H',String(p.height),'--steps',String(steps),'--seed',String(p.seed),'--cfg-scale',String(p.cfg),'--sampling-method',sdSampler,'--scheduler',sdScheduler,'--vae-tiling','--backend',process.env.ATLANTE_SD_BACKEND||'diffusion=vulkan1,vae=cpu,clip=cpu','--max-vram','3','--log-level','info'];
  if(image){const {bytes}=await decodeImage(image);await sharp(bytes).rotate().resize(p.width,p.height,{fit:'contain',background:'#ffffff'}).png().toFile(dir+'/input.png');args.push('--init-img',dir+'/input.png','--strength',String(strength));}
  await new Promise((resolve,reject)=>{signal?.throwIfAborted();const child=spawn(executable,args,{cwd:root+'runtime/sd',windowsHide:true,shell:false});let log='';const stop=()=>child.kill();signal?.addEventListener('abort',stop,{once:true});const collect=c=>{log=(log+c.toString()).slice(-24000);};child.stdout.on('data',collect);child.stderr.on('data',collect);const timer=setTimeout(()=>child.kill(),15*60*1000);const clean=()=>{clearTimeout(timer);signal?.removeEventListener('abort',stop);};child.once('error',e=>{clean();reject(e);});child.once('close',async code=>{clean();await writeFile(dir+'/run.log',log).catch(()=>{});signal?.aborted?reject(signal.reason):code===0?resolve():reject(Error('Motore immagini terminato con errore '+code+'. Vedi '+dir+'/run.log'));});});
  const bytes=await readFile(dir+'/output.png');await sharp(bytes).metadata();return await result(bytes);
 }finally{await rm(dir+'/input.png',{force:true});await rm(dir+'/prompt.txt',{force:true});}
}
