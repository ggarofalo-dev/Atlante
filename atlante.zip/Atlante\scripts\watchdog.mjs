import http from 'node:http';
import {spawn} from 'node:child_process';
import {mkdirSync,appendFileSync,existsSync,statSync,renameSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url));
mkdirSync(root+'data/service',{recursive:true});
const appPort=Number(process.env.PORT||3210),watchdogPort=Number(process.env.ATLANTE_WATCHDOG_PORT||3211);
let app=null,ollamaChild=null,checking=false,stopping=false,failures=0,lastAppStart=0,lastOllamaStart=0;
function log(text){const file=root+'data/service/supervisor.log';try{if(existsSync(file)&&statSync(file).size>5*1024*1024)renameSync(file,file+'.previous');appendFileSync(file,new Date().toISOString()+' '+text.slice(-4000)+'\n');}catch{}}
function launch(exe,args,label){const child=spawn(exe,args,{cwd:root,windowsHide:true,shell:false,stdio:['ignore','pipe','pipe']});child.stdout.on('data',c=>log(label+': '+c));child.stderr.on('data',c=>log(label+': '+c));child.on('error',e=>{child.failed=true;log(label+' ERROR '+e.message);});child.on('exit',code=>log(label+' exit '+code));return child;}
async function health(url){try{const res=await fetch(url,{signal:AbortSignal.timeout(5000)});return res.ok?await res.json():null;}catch{return null;}}
async function check(){
 if(checking||stopping)return;checking=true;
 try{
  const appStatus=await health(`http://127.0.0.1:${appPort}/api/health`);
  if(appStatus?.app==='atlante')failures=0;else{
   failures++;
   if(app&&app.exitCode===null&&!app.killed&&failures>=3){log('Server non risponde: riavvio del processo figlio');app.kill();}
   if((!app||app.failed||app.exitCode!==null||app.killed)&&Date.now()-lastAppStart>30000){lastAppStart=Date.now();app=launch(process.execPath,['src/server.mjs'],'Atlante');}
  }
  const ollamaStatus=await health('http://127.0.0.1:11434/api/tags');
  if(!ollamaStatus&&(!ollamaChild||ollamaChild.failed||ollamaChild.exitCode!==null||ollamaChild.killed)&&Date.now()-lastOllamaStart>60000){
   const exe=process.env.ATLANTE_OLLAMA_PATH||join(process.env.LOCALAPPDATA||'', 'Programs','Ollama','ollama.exe');if(existsSync(exe)){lastOllamaStart=Date.now();ollamaChild=launch(exe,['serve'],'Ollama');}else log('Ollama non trovato');
  }
  writeFileSync(root+'data/service/status.json',JSON.stringify({updated:new Date().toISOString(),supervisorPid:process.pid,appPid:appStatus?.pid||app?.pid||null,healthy:appStatus?.app==='atlante',ollama:!!ollamaStatus}));
 }finally{checking=false;}
}
// A local listener is an OS-managed singleton lock; a crash releases it automatically.
const lock=http.createServer((_req,res)=>{res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({app:'atlante-supervisor'}));});
lock.on('error',e=>{if(e.code==='EADDRINUSE')process.exit(0);throw e;});
lock.listen(watchdogPort,'127.0.0.1',()=>{log('Supervisore avviato');check().catch(e=>log(e.message));});
const timer=setInterval(()=>check().catch(e=>log(e.message)),20000);
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{stopping=true;clearInterval(timer);app?.kill();ollamaChild?.kill();lock.close(()=>process.exit(0));});
