import {mkdirSync} from 'node:fs';
import {Store} from './store.mjs';
import {Scheduler} from './scheduler.mjs';
export class Profiles {
 constructor({root,auth,legacyStore,isBusy,execute}){this.root=root;this.auth=auth;this.legacyStore=legacyStore;this.isBusy=isBusy;this.execute=execute;this.entries=new Map();}
 get(user){
  if(this.entries.has(user.id)){const entry=this.entries.get(user.id);if(user.enabled&&entry.scheduler.stopped)entry.scheduler.start();return entry;}
  const directory=this.root+'data/users/';mkdirSync(directory,{recursive:true});
  const store=user.id==='admin'?this.legacyStore:new Store(directory+user.id+'.sqlite');
  const localSearch=store.search.bind(store);
  // Only imported knowledge is shared; private memories and web sources stay in the user's store.
  store.search=(query,limit=6)=>{const local=localSearch(query,limit);if(user.id==='admin')return local;const shared=this.legacyStore.search(query,100).filter(d=>d.kind==='document');return [...local,...shared].slice(0,limit);};
  const scheduler=new Scheduler(store,{isBusy:this.isBusy,execute:input=>{const current=this.auth.user(user.id);if(!current?.enabled)throw Error('Utente disabilitato');return this.execute(input,store,current);}});
  const entry={store,scheduler};this.entries.set(user.id,entry);scheduler.start();return entry;
 }
 start(){for(const user of this.auth.users())if(user.enabled)this.get(user);}
 stop(){for(const {store,scheduler}of this.entries.values()){scheduler.stop();if(store!==this.legacyStore)store.close();}}
 disable(id){const entry=this.entries.get(id);if(entry){entry.scheduler.stop();for(const job of entry.scheduler.jobs())entry.scheduler.cancelPending(job.id,'Account disabilitato');}}
}
