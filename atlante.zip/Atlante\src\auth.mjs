import {DatabaseSync} from 'node:sqlite';
import {randomBytes,randomUUID,scrypt,timingSafeEqual,createHash,createCipheriv,createDecipheriv} from 'node:crypto';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {promisify} from 'node:util';
const derive=promisify(scrypt);
const digest=value=>createHash('sha256').update(value).digest('hex');
const publicUser=u=>u?({id:u.id,username:u.username,admin:!!u.admin,library:!!u.library,enabled:!!u.enabled}):null;
export class Auth {
 constructor(path){
  this.db=new DatabaseSync(path);this.attempts=new Map();
  this.db.exec(`PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE,salt TEXT,password TEXT,admin INTEGER,library INTEGER,enabled INTEGER,deleted INTEGER DEFAULT 0);
   CREATE TABLE IF NOT EXISTS login_sessions(token TEXT PRIMARY KEY,user_id TEXT,expires INTEGER);
   CREATE TABLE IF NOT EXISTS api_tokens(user_id TEXT PRIMARY KEY,hash TEXT NOT NULL,prefix TEXT NOT NULL,created INTEGER NOT NULL,last_used INTEGER);
   CREATE TABLE IF NOT EXISTS artifact_owners(url TEXT PRIMARY KEY,user_id TEXT);
   CREATE TABLE IF NOT EXISTS auth_meta(key TEXT PRIMARY KEY,value TEXT);`);
  if(!this.db.prepare('PRAGMA table_info(api_tokens)').all().some(c=>c.name==='secret'))this.db.exec('ALTER TABLE api_tokens ADD COLUMN secret TEXT');
  const keyPath=path+'.api.key';if(path===':memory:')this.apiKey=randomBytes(32);else{if(!existsSync(keyPath))writeFileSync(keyPath,randomBytes(32),{flag:'wx',mode:0o600});this.apiKey=readFileSync(keyPath);if(this.apiKey.length!==32)throw Error('Chiave API non valida');}
 }
 async initialize(){if(!this.db.prepare('SELECT id FROM users LIMIT 1').get())await this.create({id:'admin',username:'admin',password:'admin123',admin:true,library:true});}
 users(){return this.db.prepare('SELECT * FROM users WHERE deleted=0 ORDER BY username').all().map(publicUser);}
 user(id){return publicUser(this.db.prepare('SELECT * FROM users WHERE id=? AND deleted=0').get(id));}
 async passwordFields(password){if(typeof password!=='string'||password.length<8||password.length>256)throw Error('La password deve avere da 8 a 256 caratteri');const salt=randomBytes(16).toString('hex');return {salt,password:(await derive(password,salt,64)).toString('hex')};}
 async verify(user,password){if(typeof password!=='string'||password.length>256)return false;const key=await derive(password,user.salt,64);return timingSafeEqual(key,Buffer.from(user.password,'hex'));}
 async create(input){
  if(typeof input.username!=='string'||! /^[a-zA-Z0-9_.-]{3,40}$/.test(input.username))throw Error('Username: da 3 a 40 lettere, numeri, punti, trattini o underscore');
  const username=input.username.toLowerCase();if(this.db.prepare('SELECT id FROM users WHERE username=?').get(username))throw Error('Username gia utilizzato');
  const fields=await this.passwordFields(input.password),id=input.id||randomUUID();
  this.db.prepare('INSERT INTO users(id,username,salt,password,admin,library,enabled) VALUES(?,?,?,?,?,?,?)').run(id,username,fields.salt,fields.password,input.admin?1:0,input.library?1:0,input.enabled===false?0:1);return this.user(id);
 }
 async update(input,actor){
  if(!input.id)return this.create({...input,id:undefined});
  const user=this.user(input.id);if(!user)throw Error('Utente non trovato');
  const admin=input.admin===true,enabled=input.enabled!==false;
  if(user.id===actor.id&&(!admin||!enabled))throw Error('Non puoi disabilitare o rimuovere il tuo ruolo admin');
  if(user.admin&&(!admin||!enabled)&&!this.users().some(u=>u.id!==user.id&&u.admin&&u.enabled))throw Error('Deve rimanere almeno un admin attivo');
  if(input.password){const fields=await this.passwordFields(input.password);this.db.prepare('UPDATE users SET salt=?,password=? WHERE id=?').run(fields.salt,fields.password,user.id);this.invalidate(user.id);}
  this.db.prepare('UPDATE users SET admin=?,library=?,enabled=? WHERE id=?').run(admin?1:0,input.library?1:0,enabled?1:0,user.id);
  if(!enabled)this.invalidate(user.id);return this.user(user.id);
 }
 remove(id,actor){const user=this.user(id);if(!user)throw Error('Utente non trovato');if(id===actor.id)throw Error('Non puoi eliminare il tuo account');if(user.admin&&!this.users().some(u=>u.id!==id&&u.admin&&u.enabled))throw Error('Deve rimanere almeno un admin attivo');this.db.prepare('UPDATE users SET deleted=1,enabled=0 WHERE id=?').run(id);this.invalidate(id);}
 invalidate(id){this.db.prepare('DELETE FROM login_sessions WHERE user_id=?').run(id);this.revokeApiToken(id);}
 apiToken(id){return this.db.prepare('SELECT prefix,created,last_used AS lastUsed FROM api_tokens WHERE user_id=?').get(id)||null;}
 recoverApiToken(id){const row=this.db.prepare('SELECT secret FROM api_tokens WHERE user_id=?').get(id);if(!row?.secret)return null;const bytes=Buffer.from(row.secret,'base64'),cipher=createDecipheriv('aes-256-gcm',this.apiKey,bytes.subarray(0,12));cipher.setAAD(Buffer.from(id));cipher.setAuthTag(bytes.subarray(12,28));return Buffer.concat([cipher.update(bytes.subarray(28)),cipher.final()]).toString('utf8');}
 createApiToken(id,{renew=false}={}){if(!this.user(id)?.enabled)throw Error('Account non disponibile');const old=this.apiToken(id);if(old&&!renew)throw Error('Revoca il token esistente prima di generarne uno nuovo');if(renew&&!old)throw Error('Nessun token da rinnovare');const token='atlante_'+randomBytes(32).toString('hex'),iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',this.apiKey,iv);cipher.setAAD(Buffer.from(id));const encrypted=Buffer.concat([cipher.update(token,'utf8'),cipher.final()]),secret=Buffer.concat([iv,cipher.getAuthTag(),encrypted]).toString('base64');this.db.prepare('INSERT INTO api_tokens(user_id,hash,prefix,created,secret) VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET hash=excluded.hash,prefix=excluded.prefix,created=excluded.created,secret=excluded.secret,last_used=NULL').run(id,digest(token),token.slice(0,15),Date.now(),secret);return {token,...this.apiToken(id)};}
 revokeApiToken(id){this.db.prepare('DELETE FROM api_tokens WHERE user_id=?').run(id);}
 async changePassword(id,current,password){const user=this.db.prepare('SELECT * FROM users WHERE id=? AND deleted=0').get(id);if(!user||!await this.verify(user,current))throw Error('Password attuale errata');const fields=await this.passwordFields(password);this.db.prepare('UPDATE users SET salt=?,password=? WHERE id=?').run(fields.salt,fields.password,id);this.invalidate(id);}
 async login(username,password,ip){
  const now=Date.now(),key=String(ip)+'|'+String(username).toLowerCase();
  for(const [k,v]of this.attempts)if(v.until<now)this.attempts.delete(k);
  const attempt=this.attempts.get(key)||{count:0,until:now+15*60000};
  if(attempt.count>=10)throw Error('Troppi tentativi. Riprova tra 15 minuti');
  attempt.count++;this.attempts.set(key,attempt);if(this.attempts.size>10000)this.attempts.delete(this.attempts.keys().next().value);
  const user=this.db.prepare('SELECT * FROM users WHERE username=? AND enabled=1 AND deleted=0').get(String(username).toLowerCase());
  if(!user||!await this.verify(user,password))throw Error('Username o password errati');
  this.attempts.delete(key);const token=randomBytes(32).toString('hex');
  this.db.prepare('DELETE FROM login_sessions WHERE expires<?').run(now);
  this.db.prepare('INSERT INTO login_sessions VALUES(?,?,?)').run(digest(token),user.id,now+12*3600000);return {user:publicUser(user),token};
 }
 token(req){const name=req.socket.encrypted?'atlante_tls':'atlante_session';return (req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(name+'='))?.slice(name.length+1)||'';}
 authenticate(req){if(req.headers.authorization!==undefined){const match=/^Bearer (atlante_[a-f0-9]{64})$/i.exec(req.headers.authorization);if(!match)return null;const hash=digest(match[1]),user=publicUser(this.db.prepare('SELECT u.* FROM users u JOIN api_tokens t ON t.user_id=u.id WHERE t.hash=? AND u.enabled=1 AND u.deleted=0').get(hash));if(user)this.db.prepare('UPDATE api_tokens SET last_used=? WHERE hash=?').run(Date.now(),hash);return user;}return this.authenticateSession(req);}
 authenticateSession(req){const token=this.token(req);if(!/^[a-f0-9]{64}$/.test(token))return null;return publicUser(this.db.prepare('SELECT u.* FROM users u JOIN login_sessions s ON s.user_id=u.id WHERE s.token=? AND s.expires>? AND u.enabled=1 AND u.deleted=0').get(digest(token),Date.now()));}
 cookie(req,token=''){return `${req.socket.encrypted?'atlante_tls':'atlante_session'}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${token?43200:0}${req.socket.encrypted?'; Secure':''}`;}
 logout(req){const token=this.token(req);if(token)this.db.prepare('DELETE FROM login_sessions WHERE token=?').run(digest(token));}
 own(url,id){if(url)this.db.prepare('INSERT INTO artifact_owners VALUES(?,?) ON CONFLICT(url) DO NOTHING').run(url,id);}
 owns(url,id){return !!this.db.prepare('SELECT 1 FROM artifact_owners WHERE url=? AND user_id=?').get(url,id);}
 close(){this.db.close();}
}
