import {networkInterfaces} from 'node:os';
import QRCode from 'qrcode';

export function deviceAddresses(interfaces=networkInterfaces(),preferred='') {
 preferred=preferred.replace(/^::ffff:/,'');
 const addresses=[];
 for(const [name,entries] of Object.entries(interfaces))for(const item of entries||[]){
  if(item.internal||item.family!=='IPv4'||! /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(item.address))continue;
  if(!addresses.some(a=>a.address===item.address))addresses.push({name,address:item.address});
 }
 return addresses.sort((a,b)=>Number(b.address===preferred)-Number(a.address===preferred)||Number(/vpn|virtual|vethernet|docker|wsl|tailscale/i.test(a.name))-Number(/vpn|virtual|vethernet|docker|wsl|tailscale/i.test(b.name))||a.name.localeCompare(b.name));
}

export async function deviceLinks({port,protocol='http',preferred,interfaces}={}) {
 if(!['http','https'].includes(protocol))throw Error('Protocollo non supportato');
 return Promise.all(deviceAddresses(interfaces,preferred).map(async({name,address})=>{
  const url=`${protocol}://${address}:${port}`;
  return {name,address,url,qr:await QRCode.toDataURL(url,{errorCorrectionLevel:'M',width:288,margin:4})};
 }));
}
