const headers={'User-Agent':'AtlanteLocal/0.1 (local personal knowledge assistant)'};
export async function research(query,store,language='it',signal) {
  if(!['it','en'].includes(language))throw Error('Lingua non supportata');
  const base=`https://${language}.wikipedia.org/w/api.php`;
  async function request(params){
    const res=await fetch(base+'?'+new URLSearchParams({format:'json',...params}),{headers,signal:signal?AbortSignal.any([signal,AbortSignal.timeout(20000)]):AbortSignal.timeout(20000)});
    if(!res.ok)throw Error('Wikipedia HTTP '+res.status);
    const json=await res.json();if(json.error)throw Error(json.error.info);return json;
  }
  const results=await request({action:'query',list:'search',srsearch:query,srlimit:'3'});
  const sources=[];
  for(const hit of results.query.search){
    const page=await request({action:'query',prop:'extracts|info',pageids:String(hit.pageid),explaintext:'1',exintro:'1',inprop:'url'});
    const data=page.query.pages[hit.pageid];
    if(!data.extract?.trim())continue;
    sources.push({...store.add({title:data.title,text:data.extract,url:data.fullurl,license:'CC BY-SA; vedi cronologia e licenza della pagina',kind:'web'}),title:data.title,url:data.fullurl});
  }
  return sources;
}
