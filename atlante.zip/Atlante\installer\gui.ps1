﻿$ErrorActionPreference='Stop'
$installerDirectory=$PSScriptRoot
. (Join-Path $PSScriptRoot 'consent.ps1')
. (Join-Path $PSScriptRoot 'gui-window.ps1')
try {
    . (Join-Path $installerDirectory 'existing.ps1')
    $defaultRoot=Join-Path $env:LOCALAPPDATA 'Atlante'
    $existing=Find-ExistingAtlante $defaultRoot
    if($existing){$defaultRoot=$existing.root}
    $ui=New-InstallerWindow $defaultRoot
    $timer=[Windows.Forms.Timer]::new();$timer.Interval=500
    $ui.start.Add_Click({
        try {
            foreach($key in @('installRoot','modelsRoot','ollamaModelsRoot')){if([string]::IsNullOrWhiteSpace($ui[$key].Text) -or ![IO.Path]::IsPathRooted($ui[$key].Text) -or $ui[$key].Text -notmatch '^(?:[A-Za-z]:[\\/]|\\\\)'){throw 'Scegli cartelle con percorsi assoluti, ad esempio D:\Atlante.'}}
            . (Join-Path $installerDirectory 'consent.ps1')
            $terms=Join-Path $installerDirectory 'CONDIZIONI.txt'
            if(!(Show-InstallerConditions $terms $ui.start.Text)){return}
            $jobDir=Join-Path ([IO.Path]::GetTempPath()) ('AtlanteInstaller-'+[Guid]::NewGuid().ToString('N'))
            New-Item -ItemType Directory -Path $jobDir -Force|Out-Null
            $ui.jobPath=Join-Path $jobDir 'job.json'
            $job=@{installRoot=$ui.installRoot.Text.Trim();modelsRoot=$ui.modelsRoot.Text.Trim();ollamaModelsRoot=$ui.ollamaModelsRoot.Text.Trim();mode=$ui.mode;accepted=$true;termsSha256=(Get-FileHash -LiteralPath $terms).Hash;acceptedAt=[DateTime]::UtcNow.ToString('o')}
            $job.autoStart=[bool]$ui.autoStart.Checked
            [IO.File]::WriteAllText($ui.jobPath,($job|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
            $worker=Join-Path $installerDirectory 'worker.ps1'
            $command="& '$($worker.Replace("'","''"))' -JobPath '$($ui.jobPath.Replace("'","''"))'"
            $encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
            $ui.worker=Start-Process powershell.exe -ArgumentList @('-NoLogo','-NoProfile','-NonInteractive','-STA','-ExecutionPolicy','Bypass','-EncodedCommand',$encoded) -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $jobDir 'worker-output.log') -RedirectStandardError (Join-Path $jobDir 'worker-error.log')
            $ui.running=$true;$ui.started=$true;$ui.folders.Enabled=$false;$ui.start.Enabled=$false;$ui.close.Enabled=$false;$ui.status.Text='Controllo del pacchetto e preparazione...';$timer.Start()
        } catch {[void][Windows.Forms.MessageBox]::Show($ui.form,$_.Exception.Message,'Installazione Atlante','OK','Error')}
    }.GetNewClosure())
    $timer.Add_Tick({
        try {
            . (Join-Path $installerDirectory 'gui-window.ps1')
            $file=Join-Path (Split-Path -Parent $ui.jobPath) 'progress.json'
            if(Test-Path -LiteralPath $file){$state=Get-Content -LiteralPath $file -Raw -Encoding UTF8|ConvertFrom-Json;Update-InstallerWindow $ui $state}
            $ui.worker.Refresh()
            if($ui.worker.HasExited){
                if($ui.running){$message='Installazione interrotta. Consulta il log o ripeti con il pacchetto aggiornato.';$ui.logPath=Join-Path (Split-Path -Parent $ui.jobPath) 'worker-error.log';$ui.status.Text=$message;$ui.running=$false;$ui.close.Enabled=$true;$ui.close.Text='Chiudi';$ui.log.Enabled=Test-Path -LiteralPath $ui.logPath}
                if(!$ui.log.Enabled -and $ui.lastState.state -eq 'error'){$ui.logPath=Join-Path (Split-Path -Parent $ui.jobPath) 'worker-error.log';$ui.log.Enabled=Test-Path -LiteralPath $ui.logPath}
                $timer.Stop()
            }
        } catch { $ui.status.Text='Installazione in corso. Aggiorno lo stato...' }
    }.GetNewClosure())
    $ui.close.Add_Click({$ui.form.Close()}.GetNewClosure())
    $ui.log.Add_Click({if(Test-Path -LiteralPath $ui.logPath){Start-Process notepad.exe -ArgumentList ('"'+$ui.logPath+'"')}}.GetNewClosure())
    $ui.form.Add_FormClosing({param($sender,$eventArgs)if($ui.running){$eventArgs.Cancel=$true;[void][Windows.Forms.MessageBox]::Show($ui.form,'Attendi la conclusione della procedura. La finestra può essere ridotta a icona.','Installazione in corso','OK','Information')}}.GetNewClosure())
    [void]$ui.form.ShowDialog()
} catch {Add-Type -AssemblyName System.Windows.Forms;[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Installazione Atlante','OK','Error')}
finally{if($timer){$timer.Dispose()};if($ui){$ui.form.Dispose()}}
