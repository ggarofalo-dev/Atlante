import {mkdir,writeFile,readFile,access} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const directory=fileURLToPath(new URL('../models/ocr/',import.meta.url));await mkdir(directory,{recursive:true});
const expected={ita:'b8f89e1e785118dac4d51ae042c029a64edb5c3ee42ef73027a6d412748d8827',eng:'7d4322bd2a7749724879683fc3912cb542f19906c83bcc1a52132556427170b2'};
for(const language of ['ita','eng']){
 const file=directory+language+'.traineddata';let bytes;
 try{await access(file);bytes=await readFile(file);}catch{
  const url=`https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/4.1.0/${language}.traineddata`;
  const response=await fetch(url,{signal:AbortSignal.timeout(120000)});if(!response.ok)throw Error('Download OCR HTTP '+response.status);bytes=Buffer.from(await response.arrayBuffer());if(createHash('sha256').update(bytes).digest('hex')!==expected[language])throw Error('Checksum modello OCR non valido');await writeFile(file,bytes);
 }
 const hash=createHash('sha256').update(bytes).digest('hex');if(hash!==expected[language])throw Error('Checksum modello OCR locale non valido: '+language);console.log(language,bytes.length,'bytes SHA256',hash);
}
console.log('Modelli OCR italiano e inglese disponibili in locale');
