import {createWorker,PSM} from 'tesseract.js';
import sharp from 'sharp';
import {existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const models=fileURLToPath(new URL('../models/ocr/',import.meta.url));
export function ocrAvailable(){return ['ita','eng'].every(lang=>existsSync(models+lang+'.traineddata'));}
export function wantsImageText(prompt){return /\b(?:ocr|testo|testi|trascriv\w*|trascrizione|scanner|scansion\w*|documento|fattura|scontrino|ricevuta|leggi|lettura|codice|importo|totale|targa)\b/i.test(prompt);}
export function wantsTranscription(prompt){return (/\b(?:trascriv\w*|trascrizione|estrai|estrarre|ocr)\b/i.test(prompt)||/\bleggi\b.*\b(?:testo|tutto|documento)\b/i.test(prompt))&&!/\b(?:riassum\w*|traduc\w*|spiega|quanto|quale|qual è)\b/i.test(prompt);}
export async function createOcr(){
 if(!ocrAvailable())throw Error('OCR locale non installato. Esegui scripts/setup-ocr.mjs.');
 const worker=await createWorker('ita+eng',1,{langPath:models,gzip:false,cacheMethod:'none',errorHandler:()=>{}});
 try{await worker.setParameters({tessedit_pageseg_mode:PSM.AUTO,preserve_interword_spaces:'1',user_defined_dpi:'200'});}catch(e){await worker.terminate();throw e;}
 let stopped=false;
 return {
  async read(bytes){
   if(stopped)throw Error('OCR interrotto');
   const image=sharp(bytes,{limitInputPixels:25000000}).rotate().flatten({background:'#ffffff'}),metadata=await image.metadata();if(!['png','jpeg','webp'].includes(metadata.format))throw Error('OCR immagini: usa PNG, JPEG o WebP');if(!metadata.width||!metadata.height)throw Error('Dimensioni immagine non valide');
   const prepared=await image.resize({width:Math.min(3600,Math.max(metadata.width,1400)),height:4200,fit:'inside',withoutEnlargement:false}).grayscale().normalize().png().toBuffer();let timer;
   try{const result=await Promise.race([worker.recognize(prepared,{rotateAuto:true}),new Promise((_,reject)=>{timer=setTimeout(()=>{stopped=true;worker.terminate().catch(()=>{});reject(Error('OCR troppo lento per questa pagina. Riduci il documento o migliora la scansione.'));},45000);})]);return {text:result.data.text.trim(),confidence:Math.round(result.data.confidence)};}finally{clearTimeout(timer);}
  },
  async close(){if(!stopped){stopped=true;await worker.terminate();}}
 };
}
export async function readImageText(bytes){const reader=await createOcr();try{return await reader.read(bytes);}finally{await reader.close();}}
