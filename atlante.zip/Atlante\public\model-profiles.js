const google='https://ai.google.dev/gemma/docs/core/model_card_3';
const meta='https://huggingface.co/meta-llama/Llama-3.2-3B-Instruct';
const benchmark=(value,test,source,protocol)=>({value,test,source,note:protocol+' · dato pubblicato dal produttore, non misurato sul tuo PC; quantizzazione e versione possono cambiare i risultati.'});
export const profiles={
 'llama3.2:1b':{text:benchmark(59.5,'IFEval',meta,'1B Instruct BF16, 0-shot, media accuratezza prompt/istruzioni'),reasoning:benchmark(44.4,'GSM8K',meta,'1B Instruct BF16, CoT 8-shot'),vision:false},
 'llama3.2:latest':{text:benchmark(77.4,'IFEval',meta,'3B Instruct BF16, 0-shot, media accuratezza prompt/istruzioni'),reasoning:benchmark(77.7,'GSM8K',meta,'3B Instruct BF16, CoT 8-shot'),vision:false},
 'llama3.2:3b':{text:benchmark(77.4,'IFEval',meta,'3B Instruct BF16, 0-shot, media accuratezza prompt/istruzioni'),reasoning:benchmark(77.7,'GSM8K',meta,'3B Instruct BF16, CoT 8-shot'),vision:false},
 'gemma3:4b':{text:benchmark(90.2,'IFEval',google,'4B instruction-tuned, 0-shot'),reasoning:benchmark(89.2,'GSM8K',google,'4B instruction-tuned, 0-shot'),vision:benchmark(75.8,'DocVQA',google,'4B instruction-tuned')},
 'gemma3:12b':{text:benchmark(88.9,'IFEval',google,'12B instruction-tuned, 0-shot'),reasoning:benchmark(94.4,'GSM8K',google,'12B instruction-tuned, 0-shot'),vision:benchmark(87.1,'DocVQA',google,'12B instruction-tuned')}
};
export function estimatedImageCompatibility(bytes,family,hardware={}){
 if(!bytes||!family||family==='components')return {level:'unknown',label:'Non stimabile',message:'Architettura o memoria richiesta non ancora determinate.'};
 const size=bytes/1024**3,ram=Math.ceil(size*1.4+4),vram=Math.max(0,...(hardware.gpus||[]).filter(g=>g.memorySource==='NVIDIA').map(g=>g.memoryGB||0)),requiredGPU=family==='sd15'?4:family==='sdxl'?8:Math.ceil(size+3);
 const level=hardware.ramGB<ram?'limited':vram>=requiredGPU?'suitable':'partial';
 return {level,label:level==='suitable'?'Adatto':level==='limited'?'Memoria limitata':'GPU parziale / CPU',message:`Stima: circa ${ram} GB di RAM e ${requiredGPU} GB di VRAM per un uso agevole. Può funzionare con meno VRAM usando la RAM, con tempi maggiori. Driver, risoluzione e programmi aperti influiscono.`};
}
export function capabilitiesFor(row){
 if(row.kind==='image')return {text:false,reasoning:false,generation:row.family==='components'?null:undefined,vision:false};
 const profile=profiles[row.id],embedding=row.capabilities?.includes('embedding'),vision=row.capabilities?.includes('vision');
 return {text:embedding?false:profile?.text,reasoning:embedding?false:profile?.reasoning,generation:false,vision:embedding?false:profile?.vision===false?false:profile?.vision|| (vision?undefined:row.installed?false:undefined)};
}
export function estimatedChatCompatibility(bytes,minRAM,hardware={},remote=false){
 if(remote)return {level:'unknown',label:'Non stimabile',message:'Ollama remoto: hardware del motore non rilevabile.'};
 if(!bytes&&!minRAM)return {level:'unknown',label:'Non stimabile',message:'Dimensione del modello non ancora disponibile.'};
 const size=bytes/1024**3,required=minRAM||Math.ceil(size*1.5+2),gpu=Math.max(0,...(hardware.gpus||[]).filter(g=>g.memorySource==='NVIDIA').map(g=>g.memoryGB||0));const level=hardware.ramGB<required?'limited':gpu>=size+1?'suitable':'partial';return {level,label:level==='limited'?'Memoria limitata':level==='suitable'?'Adatto':'GPU parziale / CPU',message:`Stima: ${required} GB di RAM consigliati. ${gpu>=size+1?'Memoria GPU stimata sufficiente.':'Possibile uso della CPU o della GPU in parte.'} Contesto e programmi aperti influiscono.`};
}
export const imageDescriptions={
 'Comfy-Org/stable-diffusion-v1-5-archive':{name:'Stable Diffusion 1.5',family:'sd15',description:'Genera immagini da una descrizione. Modello leggero per illustrazioni e fotografie a risoluzione contenuta.'},
 'stabilityai/stable-diffusion-xl-base-1.0':{name:'Stable Diffusion XL',family:'sdxl',description:'Genera immagini con più dettaglio, fotografie e illustrazioni. Pensato per immagini intorno a 1024 pixel.'},
 'stabilityai/sdxl-turbo':{name:'SDXL Turbo',family:'sdxl',description:'Generazione rapida di immagini con pochi passaggi. Variante SDXL orientata alla velocità.'},
 'Comfy-Org/flux1-schnell':{name:'FLUX.1 Schnell',family:'flux1',description:'Genera immagini da descrizioni articolate in pochi passaggi. Richiede più memoria dei modelli SD 1.5.'}
};
