import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';

export const atlanteGuide={title:'Come funziona Atlante',kind:'document',url:'',license:'CC0',text:readFileSync(new URL('./atlante-guide.md',import.meta.url),'utf8')};
const revision='atlante-guide-manual-v1';

export function installDefaultKnowledge(store){
 store.db.exec('CREATE TABLE IF NOT EXISTS library_defaults(key TEXT PRIMARY KEY,document_id TEXT,installed TEXT)');
 const key='atlante-guide',previous=store.db.prepare('SELECT document_id FROM library_defaults WHERE key=?').get(key);
 if(store.db.prepare('SELECT 1 FROM library_defaults WHERE key=?').get(revision))return {added:false};
 if(previous){
  const doc=store.document(previous.document_id);
  // Update the previously installed guide in place; a deletion remains a deletion.
  let updated=false;
  store.db.exec('BEGIN');
  try{
   if(doc?.kind==='document'&&doc.title===atlanteGuide.title&&doc.text!==atlanteGuide.text){
    const hash=createHash('sha256').update('document\0'+atlanteGuide.text).digest('hex');
    const duplicate=store.db.prepare('SELECT id FROM documents WHERE hash=? AND id<>?').get(hash,doc.id);
    if(!duplicate){
     store.db.exec('CREATE TABLE IF NOT EXISTS library_default_history(document_id TEXT,revision TEXT,text TEXT,updated TEXT)');
     store.db.prepare('INSERT INTO library_default_history VALUES(?,?,?,?)').run(doc.id,revision,doc.text,new Date().toISOString());
     store.purgeChunks(doc.id);
     store.db.prepare('UPDATE documents SET hash=? WHERE id=?').run(hash,doc.id);
     store.db.prepare('INSERT OR REPLACE INTO document_texts VALUES(?,?)').run(doc.id,atlanteGuide.text);
     store.writeChunks(doc.id,atlanteGuide.text);updated=true;
    }
   }
   store.db.prepare('INSERT INTO library_defaults VALUES(?,?,?)').run(revision,previous.document_id,new Date().toISOString());
   store.db.exec('COMMIT');
  }catch(e){store.db.exec('ROLLBACK');throw e;}
  return {id:previous.document_id,added:false,updated};
 }
 const existing=store.db.prepare("SELECT id FROM documents WHERE title=? AND kind='document' LIMIT 1").get(atlanteGuide.title);
 const result=existing||store.add(atlanteGuide);
 store.db.exec('BEGIN');try{
  const insert=store.db.prepare('INSERT INTO library_defaults VALUES(?,?,?)');
  for(const marker of [key,revision])insert.run(marker,result.id,new Date().toISOString());
  store.db.exec('COMMIT');
 }catch(e){store.db.exec('ROLLBACK');throw e;}
 return {id:result.id,added:!existing&&!result.duplicate};
}
