import {homedir} from 'node:os';
import {createHash} from 'node:crypto';
import {statfs} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {ollamaBase} from './ollama-config.mjs';
import {modelCatalog} from './setup.mjs';
import {OllamaCatalog} from './ollama-catalog.mjs';
const GB=1024**3;
export function modelName(value){
 if(typeof value!=='string'||value.length>160||! /^(?:[a-zA-Z0-9][a-zA-Z0-9._-]*\/)?[a-zA-Z0-9][a-zA-Z0-9._-]*(?::[a-zA-Z0-9][a-zA-Z0-9._-]*)?$/.test(value))throw Error('Nome modello non valido. Usa nome:tag oppure autore/nome:tag.');
 return value.includes(':')?value:value+':latest';
}
export function compatibility(model,hardware,remote=false){
 const known=modelCatalog.find(m=>modelName(m.id)===model.name);
 const requiredRAM=known?.minRAM||Math.ceil((model.size||0)/GB*1.5+2);
 const gpu=hardware.gpus?.reduce((max,g)=>Math.max(max,g.memoryGB||0),0)||0;
 return {requiredRAM,level:remote?'unknown':hardware.ramGB<requiredRAM?'limited':'suitable',message:remote?'Ollama remoto: hardware non verificabile':hardware.ramGB<requiredRAM?`RAM inferiore ai ${requiredRAM} GB consigliati`:gpu>(model.size||0)/GB+1?'RAM adeguata; modello stimato compatibile con la memoria GPU':'RAM adeguata; possibile uso della CPU o GPU parziale'};
}
export class ModelManager{
 constructor({setup,queue,request=fetch}){this.setup=setup;this.queue=queue;this.request=request;this.catalog=new OllamaCatalog({root:setup.root||process.cwd(),request});this.catalogReady=this.catalog.initialize();this.metadata=new Map();this.operations=new Map();this.remote=!['localhost','127.0.0.1','[::1]'].includes(new URL(ollamaBase).hostname);}
 async api(path,body,method=body?'POST':'GET',signal=AbortSignal.timeout(15000)){
  const response=await this.request(ollamaBase+'/api/'+path,{method,headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,signal});
  if(!response.ok)throw Error('Ollama: '+(await response.text()).slice(0,250));const text=await response.text();return text?JSON.parse(text):{};
 }
 async installed(){
  const {models=[]}=await this.api('tags');
  return Promise.all(models.map(async m=>{
   const key=m.name+'|'+m.digest;let cached=this.metadata.get(key);
   if(!cached||Date.now()-cached.at>300000){let capabilities;try{capabilities=(await this.api('show',{model:m.name})).capabilities;}catch{}
    cached={at:Date.now(),capabilities:Array.isArray(capabilities)?capabilities:/embed|bge-|e5-|all-minilm/i.test(m.name)?['embedding']:['completion']};this.metadata.set(key,cached);
   }
   return {...m,capabilities:cached.capabilities,chat:cached.capabilities.includes('completion')&&!m.name.startsWith('moondream:')};
  }));
 }
 async status(owner){
  await this.catalogReady;
  const [state,installed]=await Promise.all([this.setup.status(),this.installed()]);let diskFreeGB=null;
  if(!this.remote){let path=process.env.OLLAMA_MODELS||join(homedir(),'.ollama','models');for(let i=0;i<8;i++){try{const disk=await statfs(path);diskFreeGB=Number(disk.bavail)*Number(disk.bsize)/GB;break;}catch{const parent=dirname(path);if(parent===path)break;path=parent;}}}
  for(const [id,op]of this.operations)if(!this.queue.jobs.has(id))this.operations.delete(id);
  const defaultModel=this.setup.config.defaultModel||(installed.some(m=>m.name==='llama3.2:latest')?'llama3.2:latest':installed.find(m=>m.chat)?.name||null);
  return {hardware:state.hardware,remote:this.remote,diskFreeGB,defaultModel,configCompleted:this.setup.config.completed,recommendation:state.recommendation,installed:installed.map(m=>({...m,update:this.updates?.has(m.name)?{...this.updates.get(m.name),available:m.digest&&this.updates.get(m.name).digest?this.updates.get(m.name).digest!==m.digest?.replace(/^sha256:/,''):null}:null,compatibility:compatibility(m,state.hardware,this.remote)})),totalBytes:installed.reduce((sum,m)=>sum+(m.size||0),0),catalog:[...new Map([...this.catalog.models,...modelCatalog,{id:'embeddinggemma:latest',name:'Ricerca semantica',downloadGB:0.62,minRAM:4,description:'Per biblioteca e documenti. Non è un modello di chat.'}].map(m=>[modelName(m.id),m])).values()].map(m=>({...m,installed:installed.some(v=>v.name===modelName(m.id)),suitable:state.hardware.ramGB>=m.minRAM})),operations:[...this.operations].filter(([id])=>this.queue.jobs.get(id)?.owner===owner).map(([id,op])=>({...this.queue.public(this.queue.jobs.get(id)),...op}))};
 }
 async checkUpdates(){if(!this.updates)this.updates=new Map();const models=await this.installed();const results=[];for(const model of models){const name=modelName(model.name),[repository,tag]=name.split(':'),path=repository.includes('/')?repository:'library/'+repository;try{const response=await this.request('https://registry.ollama.ai/v2/'+path+'/manifests/'+encodeURIComponent(tag),{method:'GET',signal:AbortSignal.timeout(15000)});const body=await response.text();if(body.length>1024*1024)throw Error();const manifest=JSON.parse(body);if(manifest.schemaVersion!==2||!Array.isArray(manifest.layers))throw Error();const digest=response.headers.get('docker-content-digest')?.replace(/^sha256:/,'')||createHash('sha256').update(body).digest('hex');if(!response.ok||!/^[a-f0-9]{64}$/.test(digest||''))throw Error();const update={available:model.digest?digest!==model.digest.replace(/^sha256:/,''):null,checkedAt:new Date().toISOString(),digest};this.updates.set(name,update);results.push({name,...update});}catch{const update={available:null,checkedAt:new Date().toISOString(),message:'Versione remota non verificabile'};this.updates.set(name,update);results.push({name,...update});}}return {results};}
 async setDefault(value){const name=modelName(value),model=(await this.installed()).find(m=>m.name===name);if(!model?.chat)throw Error('Scegli un modello di chat installato');await this.setup.saveConfig({...this.setup.config,defaultModel:name,...(!this.setup.config.completed?{completed:true,completedAt:new Date().toISOString()}: {})});return {model:name};}
 start(owner,kind,value){
  const name=modelName(value);if(!['download','delete'].includes(kind))throw Error('Operazione non valida');
  if(kind==='download'&&(/(?:^|[-:])cloud(?:$|-)/i.test(name)||this.catalog.models.find(m=>m.id===name)?.cloudOnly))throw Error('Questo modello usa un servizio cloud: Atlante propone download per esecuzione locale.');
  for(const [id,op]of this.operations)if(op.model===name&&['queued','running'].includes(this.queue.jobs.get(id)?.state))throw Error('È già in corso un’operazione su questo modello');
  const progress={model:name,kind,progress:0,message:'In attesa'};
  const job=this.queue.submit(owner,async(signal,onDelta,onProgress)=>{
   if(kind==='delete'){
    const installed=await this.installed();const fallback=this.setup.config.defaultModel||(installed.some(m=>m.name==='llama3.2:latest')?'llama3.2:latest':installed.find(m=>m.chat)?.name);
    if(name===fallback)throw Error('Scegli prima un altro modello predefinito');
    if(!installed.some(m=>m.name===name))throw Error('Modello non installato');
    await this.api('delete',{model:name},'DELETE',signal);
   }else{
    await this.catalogReady;
    if(this.catalog.models.some(m=>m.id.split(':')[0]===name.split(':')[0])){const variants=await this.catalog.inspect(name.split(':')[0],signal);const selected=variants.models.find(m=>m.id===name);if(selected?.cloud)throw Error('La variante scelta usa il cloud: scegli una versione locale.');}
    signal.throwIfAborted();const monitor=setInterval(()=>onProgress(`${name}: ${progress.message}${progress.totalBytes?' '+progress.progress+'%':''}`),400);monitor.unref();
    try{await this.setup.pull.call({...this.setup,job:progress},name,signal);}finally{clearInterval(monitor);}
   }
   this.metadata.clear();progress.progress=100;progress.message=kind==='delete'?'Modello eliminato':'Modello pronto';return {model:name};
  },{label:(kind==='download'?'Download ':'Elimina ')+name});
  this.operations.set(job.id,progress);return {id:job.id};
 }
}
