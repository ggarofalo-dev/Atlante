﻿import {existsSync} from 'node:fs';
import {mkdir,writeFile,rename,rm,readFile} from 'node:fs/promises';
import {join,resolve,sep} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import AdmZip from 'adm-zip';
export const vulkanRelease={url:'https://github.com/leejet/stable-diffusion.cpp/releases/download/master-929-3f8527a/sd-master-3f8527a-bin-win-vulkan-x64.zip',size:30067605,sha256:'60e6850d650417409f18c2170ab5e27335db96da70cd3d1ad1e930bcffc2fd35'};
export function vulkanDevices(text){
 return String(text).split(/\r?\n/).flatMap(line=>{const m=line.trim().match(/^(vulkan\d+)\s+(.+)$/i);if(!m||/lavapipe|llvmpipe|software|swiftshader/i.test(m[2]))return [];const index=m[1].match(/\d+/)[0];const meta=String(text).split(/\r?\n/).find(l=>new RegExp('ggml_vulkan: '+index+' = ').test(l));return [{id:m[1].toLowerCase(),name:m[2].trim(),integrated:/uma: 1\b/.test(meta||'')}];}).sort((a,b)=>Number(a.integrated)-Number(b.integrated));
}
export function sdExecution(root,config){
 const device=config.sdDevice||'cpu';if(!/^(cpu|vulkan\d+)$/.test(device))throw Error('Dispositivo SD non valido');
 return {executable:join(root,'runtime',device==='cpu'?'sd':'sd-vulkan','sd-cli.exe'),backend:'diffusion='+device+',vae=cpu,clip=cpu',device};
}
export function sdGenerationArgs({model,promptFile,output,width=256,height=256,steps=4,seed=42,cfg=7,negative='',sampler='euler',scheduler='discrete',backend}){
 return ['-m',model,'--prompt-file',promptFile,'-n',negative,'-o',output,'-W',String(width),'-H',String(height),'--steps',String(steps),'--seed',String(seed),'--cfg-scale',String(cfg),'--sampling-method',sampler,'--scheduler',scheduler,'--vae-tiling','--backend',backend,'--max-vram','3','--log-level','info'];
}
export async function installVulkan(root,{request=fetch,release=vulkanRelease,signal=AbortSignal.timeout(300000),progress=console.log}={}){
 const runtime=resolve(root,'runtime');await mkdir(runtime,{recursive:true});const target=join(runtime,'sd-vulkan'),marker=join(target,'installation.json');
 if(existsSync(marker)&&existsSync(join(target,'sd-cli.exe'))&&existsSync(join(target,'ggml-vulkan.dll'))){try{if(JSON.parse(await readFile(marker,'utf8')).sha256===release.sha256)return target;}catch{}}
 progress('Scarico il runtime ufficiale Vulkan (circa 30 MB)…');const response=await request(release.url,{signal,redirect:'follow'});if(!response.ok||!response.body)throw Error('Download Vulkan non riuscito: HTTP '+response.status);
 const chunks=[];let size=0;const hash=createHash('sha256');for await(const chunk of response.body){signal.throwIfAborted();size+=chunk.length;if(size>release.size)throw Error('Dimensione runtime Vulkan non valida');hash.update(chunk);chunks.push(chunk);}
 if(size!==release.size||hash.digest('hex')!==release.sha256)throw Error('Checksum runtime Vulkan non valido');
 const zip=new AdmZip(Buffer.concat(chunks)),stage=join(runtime,'sd-vulkan-'+randomUUID()+'.tmp'),backup=join(runtime,'sd-vulkan-'+randomUUID()+'.previous');let previous=false;
 try{await mkdir(stage);for(const entry of zip.getEntries()){const name=entry.entryName.replaceAll('\\','/'),file=resolve(stage,name);if(!file.startsWith(stage+sep)||/^[\/]|^[a-z]:|(^|\/)\.\.($|\/)/i.test(name)||((entry.header.attr>>>16)&0xf000)===0xa000)throw Error('Percorso runtime Vulkan non sicuro');if(entry.isDirectory)await mkdir(file,{recursive:true});else{await mkdir(resolve(file,'..'),{recursive:true});await writeFile(file,entry.getData());}}
  if(!existsSync(join(stage,'sd-cli.exe'))||!existsSync(join(stage,'ggml-vulkan.dll')))throw Error('Runtime Vulkan incompleto');
  await writeFile(join(stage,'installation.json'),JSON.stringify({...release,installed:new Date().toISOString()},null,2));signal.throwIfAborted();if(existsSync(target)){await rename(target,backup);previous=true;}try{await rename(stage,target);}catch(error){if(previous)await rename(backup,target);previous=false;throw error;}
 }finally{await rm(stage,{recursive:true,force:true});if(previous)await rm(backup,{recursive:true,force:true});}
 progress('Runtime Vulkan verificato e installato.');return target;
}
