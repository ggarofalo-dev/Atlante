import AdmZip from 'adm-zip';
import {DatabaseSync} from 'node:sqlite';
import {createHash,randomUUID} from 'node:crypto';
import {mkdirSync,readFileSync,writeFileSync,readdirSync,lstatSync,existsSync,rmSync} from 'node:fs';
import {join,resolve,relative} from 'node:path';
import {spawn} from 'node:child_process';
import {tmpdir} from 'node:os';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const backupPath=/^data\/(?:atlante\.sqlite|auth\.sqlite|setup\.json|mcp\.key|users\/[a-f0-9-]{36}\.sqlite|artifacts\/[a-f0-9-]{36}\.(?:png|txt|pdf|docx|xlsx|pptx)|tls\/[a-zA-Z0-9_.-]+)$/;
export function safeArchiveEntries(zip,{limit=512*1024*1024}={}){
 const entries=zip.getEntries();if(entries.length>12000)throw Error('Troppi file nel pacchetto');let size=0;const seen=new Set();
 for(const e of entries){const path=e.entryName.replace(/\\/g,'/');if(path.startsWith('/')||path.includes(':')||path.split('/').includes('..')||path.includes('\0')||seen.has(path.toLowerCase())||((e.attr>>>16)&0xf000)===0xa000)throw Error('Percorso ZIP non valido');seen.add(path.toLowerCase());size+=e.header.size;if(size>limit||e.header.size>256*1024*1024)throw Error('Pacchetto troppo grande');}
 return entries.filter(e=>!e.isDirectory);
}
export class Maintenance {
 constructor({root,auth,stores,isBusy,launch=true}){Object.assign(this,{root,auth,stores,isBusy,launch});this.directory=join(root,'.maintenance');mkdirSync(this.directory,{recursive:true});this.stages=new Map();}
 status(){const version=JSON.parse(readFileSync(join(this.root,'package.json'),'utf8')).version;let latest=null;for(const name of readdirSync(this.directory)){const file=join(this.directory,name,'result.json');if(existsSync(file)){try{const result=JSON.parse(readFileSync(file,'utf8').replace(/^\uFEFF/,''));if(!latest||result.updated>latest.updated)latest=result;}catch{}}}if(this.running&&latest?.id===this.running&&latest.state==='error')this.running=null;return {version,latest,restoreLimitMB:256,updates:'zip'};}
 backup(){
  if(this.isBusy())throw Error('Attendi il completamento delle richieste prima del backup');const stage=join(this.directory,randomUUID());mkdirSync(stage);const zip=new AdmZip(),files=[];
  const add=(name,bytes)=>{files.push({path:name,sha256:hash(bytes)});zip.addFile(name,bytes);};
  const snapshots=new Map();for(const {path,db}of this.stores()){const target=join(stage,randomUUID()+'.sqlite');db.prepare('VACUUM INTO ?').run(target);snapshots.set(resolve(path),target);}
  const authCopy=snapshots.get(resolve(join(this.root,'data/auth.sqlite')));if(authCopy){const db=new DatabaseSync(authCopy);db.exec('DELETE FROM login_sessions');if(db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='api_tokens'").get())db.exec('DELETE FROM api_tokens');db.close();}
  let bytes=0;const walk=directory=>{for(const item of readdirSync(directory,{withFileTypes:true})){const path=join(directory,item.name),name=relative(this.root,path).replace(/\\/g,'/');if(lstatSync(path).isSymbolicLink()||/^(data\/(service|backups|image-jobs))\//.test(name)||/-wal$|-shm$|\.tmp$/.test(name)||item.name.startsWith('.setup-write'))continue;if(item.isDirectory())walk(path);else if(backupPath.test(name)){let file=snapshots.get(resolve(path));if(!file&&name.endsWith('.sqlite')){file=join(stage,randomUUID()+'.sqlite');const db=new DatabaseSync(path);try{db.prepare('VACUUM INTO ?').run(file);}finally{db.close();}}const data=readFileSync(file||path);bytes+=data.length;if(bytes>512*1024*1024)throw Error('Backup oltre 512 MB. Riduci la libreria immagini prima di esportarlo.');add(name,data);}}};
  try{walk(join(this.root,'data'));zip.addFile('backup-manifest.json',Buffer.from(JSON.stringify({kind:'atlante-backup',version:this.status().version,created:new Date().toISOString(),files})));const output=zip.toBuffer();if(output.length>256*1024*1024)throw Error('Backup oltre il limite di ripristino di 256 MB');return output;}finally{rmSync(stage,{recursive:true,force:true});}
 }
 stage(kind,bytes){
  if(!['update','restore'].includes(kind))throw Error('Operazione non valida');if(bytes.length>256*1024*1024)throw Error('ZIP massimo 256 MB');const zip=new AdmZip(bytes),entries=safeArchiveEntries(zip);for(const entry of entries)entry.entryName=entry.entryName.replace(/\\/g,'/');let prefix='',manifest;
  if(kind==='restore'){const e=entries.find(e=>e.entryName==='backup-manifest.json');if(!e)throw Error('Questo ZIP non è un backup Atlante');manifest=JSON.parse(e.getData().toString('utf8').replace(/^\uFEFF/,''));if(manifest.kind!=='atlante-backup')throw Error('Backup non valido');}
  else{const candidates=entries.filter(e=>/(^|\/)manifest.json$/.test(e.entryName));if(candidates.length!==1)throw Error('Manifest dell’aggiornamento non trovato');prefix=candidates[0].entryName.slice(0,-'manifest.json'.length);manifest=JSON.parse(candidates[0].getData().toString('utf8').replace(/^\uFEFF/,''));}
  if(!Array.isArray(manifest.files)||!manifest.files.length)throw Error('Manifest non valido');
  const id=randomUUID(),directory=join(this.directory,id),payload=join(directory,'payload');mkdirSync(payload,{recursive:true});const paths=new Set();
  try{for(const file of manifest.files){const path=String(file.path).replace(/\\/g,'/');if(paths.has(path.toLowerCase()))throw Error('File duplicato nel manifest');paths.add(path.toLowerCase());
    const allowed=kind==='restore'?backupPath:/^(?:src\/|public\/|scripts\/|installer\/|config\/google-desktop\.json$|package\.json$|package-lock\.json$|start\.cmd$|installa\.bat$|LEGGIMI\.txt$)/;
    if(!allowed.test(path)||path.includes('..')||path.includes(':')||path.startsWith('/'))throw Error('File non consentito: '+path);
    const entry=entries.find(e=>e.entryName===prefix+file.path||e.entryName.replace(/\\/g,'/')===prefix+path);if(!entry)throw Error('File mancante: '+path);const data=entry.getData();if(hash(data)!==String(file.sha256).toLowerCase())throw Error('Checksum non valido: '+path);const target=resolve(payload,path);if(!target.startsWith(resolve(payload)+requireSeparator()))throw Error('Percorso non valido');mkdirSync(join(target,'..'),{recursive:true});writeFileSync(target,data);
   }
   if(kind==='restore'){
    if(!existsSync(join(payload,'data/auth.sqlite'))||!existsSync(join(payload,'data/atlante.sqlite')))throw Error('Database del backup mancanti');
    for(const path of ['data/auth.sqlite','data/atlante.sqlite',...manifest.files.map(f=>f.path.replace(/\\/g,'/')).filter(p=>p.startsWith('data/users/'))]){const db=new DatabaseSync(join(payload,path));try{if(db.prepare('PRAGMA integrity_check').get().integrity_check!=='ok')throw Error('Database del backup danneggiato');if(path==='data/auth.sqlite'){if(!db.prepare('SELECT count(*) n FROM users WHERE admin=1 AND enabled=1 AND deleted=0').get().n)throw Error('Backup senza admin attivo');db.exec('DELETE FROM login_sessions');if(db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='api_tokens'").get())db.exec('DELETE FROM api_tokens');}}finally{db.close();}}
   }else{for(const path of ['package.json','package-lock.json','src/server.mjs','scripts/watchdog.mjs','scripts/run-background.ps1'])if(!existsSync(join(payload,path)))throw Error('Aggiornamento incompleto: '+path);const version=JSON.parse(readFileSync(join(payload,'package.json'),'utf8')).version;if(typeof version!=='string'||version.length>40)throw Error('Versione non valida');manifest.version=version;}
   const stage={id,kind,directory,payload,version:manifest.version,files:manifest.files.length,created:Date.now()};this.stages.set(id,stage);writeFileSync(join(directory,'preview.json'),JSON.stringify(stage));return {id,kind,version:stage.version,files:stage.files};
  }catch(e){rmSync(directory,{recursive:true,force:true});throw e;}
 }
 apply(id){const stage=this.stages.get(id);if(!stage||Date.now()-stage.created>3600000)throw Error('Pacchetto scaduto. Caricalo di nuovo.');if(this.isBusy())throw Error('Attendi il completamento delle richieste prima di procedere');return this.worker(stage);}
 uninstall({keepData=true}={}){if(this.isBusy())throw Error('Attendi il completamento delle richieste prima di procedere');const id=randomUUID(),directory=join(this.directory,id);mkdirSync(directory);return this.worker({id,kind:'uninstall',directory,keepData});}
 worker(stage){
  if(this.running)throw Error('Manutenzione già in corso');this.running=stage.id;
  const job={...stage,root:resolve(this.root),appPid:process.pid,nodePath:process.execPath,port:Number(process.env.PORT||3210)};
  const jobFile=join(stage.directory,'job.json');writeFileSync(jobFile,JSON.stringify(job));
  if(this.launch){
   const ps=join(process.env.SystemRoot||'C:/Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
   const quote=value=>"'"+value.replaceAll("'","''")+"'";
   const args=['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File','"'+join(this.root,'scripts/maintenance-worker.ps1')+'"','-JobFile','"'+jobFile+'"'];
   // Start-Process creates an independent Windows process that survives server shutdown.
   const logDirectory=stage.kind==='uninstall'?tmpdir():stage.directory,logName=stage.kind==='uninstall'?'atlante-uninstall-'+stage.id:'worker';
   const command='$ErrorActionPreference="Stop"; Start-Process -FilePath '+quote(ps)+' -ArgumentList @('+args.map(quote).join(',')+') -WindowStyle Hidden -WorkingDirectory '+quote(tmpdir())+' -RedirectStandardOutput '+quote(join(logDirectory,logName+'.log'))+' -RedirectStandardError '+quote(join(logDirectory,logName+'-error.log'))+' | Out-Null';
   const child=spawn(ps,['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(command,'utf16le').toString('base64')],{cwd:this.root,windowsHide:true,stdio:['ignore','ignore','pipe']});let error='';child.stderr.on('data',b=>error+=b);
   const fail=message=>{this.running=null;if(existsSync(stage.directory))writeFileSync(join(stage.directory,'result.json'),JSON.stringify({id:stage.id,kind:stage.kind,state:'error',message,updated:Date.now()}));};
   child.on('error',e=>fail(e.message));child.on('exit',code=>{if(code)fail('Avvio manutenzione fallito: '+error.slice(-500));});child.unref();
  }
  return {id:stage.id,kind:stage.kind,restarting:true};
 }
}
function requireSeparator(){return process.platform==='win32'?'\\':'/';}
