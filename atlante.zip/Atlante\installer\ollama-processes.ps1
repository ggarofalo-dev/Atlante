function Wait-OllamaInstaller([Diagnostics.Process]$Process, [int]$TimeoutSeconds = 900) {
    # Wait for the setup process itself, never for the desktop app it launches.
    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    $nextMessage = [DateTime]::UtcNow.AddSeconds(15)
    while (-not $Process.WaitForExit(1000)) {
        if ([DateTime]::UtcNow -ge $deadline) { throw 'Installazione Ollama oltre 15 minuti. Controllare eventuali finestre del setup e installation.log prima di ripetere installa.bat.' }
        if ([DateTime]::UtcNow -ge $nextMessage) {
            Write-Host 'Installazione Ollama ancora in corso...'
            $nextMessage = [DateTime]::UtcNow.AddSeconds(15)
        }
    }
    $Process.Refresh()
    if ($Process.ExitCode -ne 0) { throw "Installazione Ollama fallita: codice $($Process.ExitCode)." }
}

function Stop-InstallerOllama([string]$Executable) {
    $directory = [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Executable))
    $session = (Get-Process -Id $PID).SessionId
    $allowedPaths = @([IO.Path]::GetFullPath($Executable), (Join-Path $directory 'ollama app.exe'))
    # Validate the listener before stopping anything; never stop an unrelated service.
    $listeners = @(Get-NetTCPConnection -LocalPort 11434 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
    foreach ($listenerId in $listeners) {
        $listener = Get-CimInstance Win32_Process -Filter "ProcessId=$listenerId"
        if (!$listener -or $listener.Name -ne 'ollama.exe' -or $listener.SessionId -ne $session -or $listener.ExecutablePath -notin $allowedPaths) {
            throw 'La porta 11434 appartiene a un processo diverso da questa installazione Ollama. Nessun processo arrestato.'
        }
    }
    Write-Host 'Chiudo Ollama app e Ollama per applicare la cartella dei modelli...'
    for ($attempt = 0; $attempt -lt 10; $attempt++) {
        $owned = @(Get-CimInstance Win32_Process | Where-Object { $_.SessionId -eq $session -and $_.Name -in @('ollama app.exe','ollama.exe') -and $_.ExecutablePath -in $allowedPaths })
        if (!$owned.Count) { return }
        # Close the desktop app first to prevent it from restarting its server.
        foreach ($name in @('ollama app.exe','ollama.exe')) {
            foreach ($target in @($owned | Where-Object Name -EQ $name)) {
                $current = Get-CimInstance Win32_Process -Filter "ProcessId=$($target.ProcessId)"
                if ($current -and $current.CreationDate -eq $target.CreationDate -and $current.ExecutablePath -eq $target.ExecutablePath) {
                    Stop-Process -Id $target.ProcessId -Force -ErrorAction Stop
                }
            }
        }
        Start-Sleep -Milliseconds 500
    }
    throw 'Ollama continua a riavviarsi: controllare altri servizi di avvio automatico e ripetere installa.bat.'
}
