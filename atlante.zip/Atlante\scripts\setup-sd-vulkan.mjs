﻿import {fileURLToPath} from 'node:url';
import {installVulkan} from '../src/sd-runtime.mjs';
try{await installVulkan(fileURLToPath(new URL('../',import.meta.url)));}catch(error){console.error(error.message);process.exitCode=1;}
