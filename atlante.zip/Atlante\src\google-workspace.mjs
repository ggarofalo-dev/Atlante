import {existsSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
const schema=(properties,required=[])=>({type:'object',properties,required,additionalProperties:false});
const str=description=>({type:'string',description});
const mapped=(name,description,path,properties,required,mapping)=>({name,description,method:'GET',path,inputSchema:schema(properties,required),openapi:true,mapping,body:false});
export const gmailTools=[
 {...mapped('cerca_email','Cerca email personali. Per data e ora usa receivedAfter/receivedBefore in RFC3339 con fuso orario, ad esempio 2026-10-06T14:00:00+02:00. Per un singolo giorno limita anche alla mezzanotte successiva. Restituisce ID da usare con leggi_email. maxResults deve essere un numero intero da 1 a 20, non testo.','/gmail/v1/users/me/messages',{q:str('Ricerca Gmail, ad esempio is:unread o from:indirizzo. Facoltativa se specifichi receivedAfter.'),receivedAfter:{type:'string',pattern:'^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:Z|[+-]\\d{2}:\\d{2})$',description:'Inizio incluso, RFC3339 con fuso orario'},receivedBefore:{type:'string',pattern:'^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:Z|[+-]\\d{2}:\\d{2})$',description:'Fine esclusa, RFC3339 con fuso orario'},maxResults:{type:'integer',minimum:1,maximum:20},pageToken:str('Pagina successiva')},[],[{name:'q',in:'query'},{name:'maxResults',in:'query'},{name:'pageToken',in:'query'}]),googleKind:'gmail_search'},
 {...mapped('leggi_email','Legge un messaggio Gmail: mittente, destinatari, oggetto e testo; non scarica allegati','/gmail/v1/users/me/messages/{id}',{id:str('ID restituito da cerca_email')},['id'],[{name:'id',in:'path'}]),googleKind:'gmail_read'},
 {name:'invia_email',description:'Invia una email di testo al destinatario indicato; richiede conferma con destinatario, oggetto e testo visibili',method:'POST',path:'/gmail/v1/users/me/messages/send',googleKind:'gmail_send',inputSchema:schema({to:{type:'string',pattern:'^[^\\s<>@,;]+@[^\\s<>@,;]+\\.[^\\s<>@,;]+$',maxLength:254},subject:{type:'string',maxLength:500,pattern:'^[^\\r\\n]+$'},text:{type:'string',maxLength:15000}},['to','subject','text'])}
];
export const driveTools=[
 mapped('cerca_file_drive','Cerca file in Google Drive con query Drive, ad esempio trashed = false and name contains \'fattura\'. Restituisce metadati e ID, non contenuti','/drive/v3/files',{q:str('Query Drive; includere trashed = false'),pageSize:{type:'integer',minimum:1,maximum:20},pageToken:str('Pagina successiva'),fields:{type:'string',enum:['nextPageToken,files(id,name,mimeType,modifiedTime,webViewLink,description)']}},['q','fields'],[{name:'q',in:'query'},{name:'pageSize',in:'query'},{name:'pageToken',in:'query'},{name:'fields',in:'query'}]),
 mapped('dettagli_file_drive','Legge i metadati di un file Drive','/drive/v3/files/{fileId}',{fileId:str('ID del file'),fields:{type:'string',enum:['id,name,mimeType,modifiedTime,webViewLink,description,size']}},['fileId','fields'],[{name:'fileId',in:'path'},{name:'fields',in:'query'}]),
 mapped('leggi_documento_drive','Esporta il testo di un documento Google Docs o i dati CSV di un foglio Google Sheets; non supporta PDF, immagini e file binari','/drive/v3/files/{fileId}/export',{fileId:str('ID del documento Google'),mimeType:{type:'string',enum:['text/plain','text/csv']}},['fileId','mimeType'],[{name:'fileId',in:'path'},{name:'mimeType',in:'query'}])
];
export function installGoogleWorkspace(hub,root){
 const file=join(root,'config/google-desktop.json');if(!existsSync(file))return false;
 const client=JSON.parse(readFileSync(file,'utf8').replace(/^\uFEFF/,'')).installed;
 if(!client||!/^\d+-[a-z0-9]+\.apps\.googleusercontent\.com$/.test(client.client_id)||client.token_uri!=='https://oauth2.googleapis.com/token')throw Error('Configurazione Google desktop non valida');
 for(const service of [{id:'atlante-google-gmail',name:'Gmail',url:'https://gmail.googleapis.com',scope:'https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/gmail.send',tools:gmailTools},{id:'atlante-google-drive',name:'Google Drive',url:'https://www.googleapis.com',scope:'https://www.googleapis.com/auth/drive.readonly',tools:driveTools}]){
  if(hub.auth.db.prepare('SELECT 1 FROM integrations WHERE id=?').get(service.id)){const old=hub.row(service.id);const needsSecret=old.oauth?.desktop&&old.oauth.clientId===client.client_id&&client.client_secret&&!old.oauth.secret;const search=old.httpTools.find(t=>t.name==='cerca_email');const upgradeSearch=service.id==='atlante-google-gmail'&&search?.path==='/gmail/v1/users/me/messages'&&!search.googleKind;if(needsSecret||upgradeSearch)hub.save({...old,httpTools:upgradeSearch?old.httpTools.map(t=>t.name==='cerca_email'?gmailTools[0]:t):old.httpTools,oauth:needsSecret?{...old.oauth,clientSecret:client.client_secret,tokenAuthMethod:'post'}:old.oauth});continue;}
  const result=hub.save({name:service.name,type:'http',url:service.url,allUsers:true,users:[],httpTools:service.tools,policies:Object.fromEntries(service.tools.map(t=>[t.name,t.method==='GET'?'read':'confirm'])),oauth:{enabled:true,desktop:true,clientSecret:client.client_secret,tokenAuthMethod:client.client_secret?'post':'none',clientId:client.client_id,authorizationUrl:'https://accounts.google.com/o/oauth2/v2/auth',tokenUrl:client.token_uri,scope:service.scope}});
  hub.auth.db.prepare('UPDATE integrations SET id=? WHERE id=?').run(service.id,result.id);
 }
 return true;
}
export function googlePayload(def,args){
 if(def.googleKind!=='gmail_send')return args;
 // Encode headers and body separately; never expose opaque raw MIME in confirmation.
 if(/[\r\n]/.test(args.to)||/[\r\n]/.test(args.subject))throw Error('Intestazioni email non valide');
 const subject='=?UTF-8?B?'+Buffer.from(args.subject).toString('base64')+'?=';
 const body=Buffer.from(args.text).toString('base64').match(/.{1,76}/g)?.join('\r\n')||'';
 const mime=`To: ${args.to}\r\nSubject: ${subject}\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${body}`;
 return {raw:Buffer.from(mime).toString('base64url')};
}
export function googleQuery(def,args){
 if(def.googleKind!=='gmail_search')return args;
 const result={...args,maxResults:args.maxResults??20},filters=[args.q||'-in:sent -in:drafts'];
 for(const [field,operator]of [['receivedAfter','after'],['receivedBefore','before']])if(args[field]){const date=Date.parse(args[field]);if(!Number.isFinite(date))throw Error('Data email non valida');filters.push(operator+':'+(Math.floor(date/1000)-(field==='receivedAfter'?1:0)));}
 if(args.receivedAfter&&args.receivedBefore&&Date.parse(args.receivedBefore)<=Date.parse(args.receivedAfter))throw Error('La fine del periodo deve essere successiva all’inizio');
 result.q=filters.join(' ');return result;
}
export function gmailSearchPeriod(message='',now=new Date()){
 if(/\b(?:tra|fino|alle)\b/i.test(message))return null;
 const months=['gennaio','febbraio','marzo','aprile','maggio','giugno','luglio','agosto','settembre','ottobre','novembre','dicembre'];
 const match=message.toLowerCase().match(/\b(\d{1,2})\s+(gennaio|febbraio|marzo|aprile|maggio|giugno|luglio|agosto|settembre|ottobre|novembre|dicembre)\s+(\d{4})\b/);
 if(!match&&!/\boggi\b/i.test(message))return null;
 const today=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Rome',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now).filter(p=>p.type!=='literal').map(p=>[p.type,Number(p.value)]));
 const day=match?Number(match[1]):today.day,month=match?months.indexOf(match[2]):today.month-1,year=match?Number(match[3]):today.year,time=message.match(/\bdalle?\s+(\d{1,2})(?:[.:](\d{2}))?/i),hour=time?Number(time[1]):0,minute=time?Number(time[2]||0):0;
 const date=new Date(Date.UTC(year,month,day));if(date.getUTCDate()!==day||hour>23||minute>59)return null;
 const zone=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Rome',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
 function instant(y,m,d,h,min){const target=Date.UTC(y,m,d,h,min);let value=target;for(let i=0;i<3;i++){const p=Object.fromEntries(zone.formatToParts(value).filter(p=>p.type!=='literal').map(p=>[p.type,Number(p.value)]));value+=target-Date.UTC(p.year,p.month-1,p.day,p.hour,p.minute,p.second);}return new Date(value).toISOString().replace('.000Z','Z');}
 const next=new Date(Date.UTC(year,month,day+1));return {receivedAfter:instant(year,month,day,hour,minute),receivedBefore:instant(next.getUTCFullYear(),next.getUTCMonth(),next.getUTCDate(),0,0)};
}
export function googleArguments(def,args,message){
 if(def?.googleKind!=='gmail_search'||!args||typeof args!=='object'||Array.isArray(args))return args;
 const result={...args};for(const key of ['q','receivedAfter','receivedBefore','pageToken'])if(result[key]==='')delete result[key];
 if(typeof result.maxResults==='string'&&/^\d+$/.test(result.maxResults))result.maxResults=Number(result.maxResults);
 if(typeof result.q==='string')result.q=result.q.replace(/\bis:received\b/g,'-in:sent -in:drafts');
 const period=gmailSearchPeriod(message);if(period)Object.assign(result,period);
 if(/\b(?:arrivat[aei]|ricevut[aei]|in arrivo|posta in entrata|inbox)\b/i.test(message||'')){
  const sender=gmailReadRequest(message)?.q.match(/from:"[^"]+"/)?.[0];
  result.q=String(result.q||'').replace(/-?\b(?:in|label):(?:sent|inviat[ae]|drafts|inbox)\b/gi,'').replace(/\bfrom:(?:"[^"]*"|\S+)/gi,'').trim();
  result.q='in:inbox'+(sender?' '+sender:'')+(result.q?' '+result.q:'');
  delete result.pageToken;
 }
 const count=message?.match(/\b(?:ultime|ultimi|prime|primi)\s+(\d+)\b/i);if(count&&Number(count[1])>=1&&Number(count[1])<=20){result.maxResults=Number(count[1]);if(!period){delete result.receivedAfter;delete result.receivedBefore;if(typeof result.q==='string')result.q=result.q.replace(/\b(?:after|before|newer_than|older_than):\S+/g,'').trim();}}
 return result;
}
export function gmailReadRequest(message){
 if((!/\b(?:email|mail|gmail|posta)\b/i.test(message)&&!/\b(?:io dicevo|intendevo|volevo).*\bin arrivo\b/i.test(message))||!/\b(?:controlla|verifica|leggi|mostra|cerca|trova|consulta|elenca|ricevut[aei]|arrivat[aei]|in arrivo)\b/i.test(message)||/\b(?:invia|manda|spedisci)\b/i.test(message))return null;
 const sender=message.match(/\bda\s+([\p{L}\p{N}@._+\- ]+?)(?=\s+(?:oggi|ieri|in data|del giorno|dalle)\b|[?!.,]?$)/iu)?.[1]?.trim();
 const q='-in:sent -in:drafts'+(sender?' from:"'+sender+'"':'');
 return {q,maxResults:20,...gmailSearchPeriod(message)};
}
export function googleResult(def,text){
 if(def.googleKind!=='gmail_read')return text;
 const message=JSON.parse(text),parts=[];
 function walk(part,depth=0){if(!part||depth>15||part.filename)return;if(part.mimeType==='text/plain'&&part.body?.data)parts.push(Buffer.from(part.body.data,'base64url').toString('utf8'));for(const child of part.parts||[])walk(child,depth+1);}
 walk(message.payload);
 return JSON.stringify({id:message.id,threadId:message.threadId,snippet:message.snippet,headers:(message.payload?.headers||[]).filter(h=>['from','to','cc','subject','date'].includes(h.name.toLowerCase())),text:parts.join('\n').slice(0,15000)||message.snippet,attachmentsIncluded:false});
}
export async function gmailSearchDetails(def,text,load){
 if(def.googleKind!=='gmail_search')return text;
 const data=JSON.parse(text);if(!Array.isArray(data.messages)&&data.messages!==undefined)throw Error('Risposta ricerca Gmail non valida');
 const ids=(data.messages||[]).slice(0,20),messages=[];
 for(let offset=0;offset<ids.length;offset+=4){
  const batch=await Promise.all(ids.slice(offset,offset+4).map(async item=>{
   if(typeof item.id!=='string'||!/^[A-Za-z0-9_-]{1,200}$/.test(item.id))throw Error('ID Gmail non valido');
   const mail=await load(item.id),headers=mail.payload?.headers||[],header=name=>headers.find(h=>h.name?.toLowerCase()===name)?.value||'';
   const date=Number(mail.internalDate);return {id:item.id,threadId:mail.threadId||item.threadId,from:header('from').slice(0,160),to:header('to').slice(0,160),subject:(header('subject')||'(senza oggetto)').slice(0,200),date:header('date').slice(0,80),receivedAt:Number.isFinite(date)&&date>0?new Date(date).toISOString():null,snippet:String(mail.snippet||'').slice(0,200)};
  }));messages.push(...batch);
 }
 messages.sort((a,b)=>(Date.parse(b.receivedAt)||0)-(Date.parse(a.receivedAt)||0));
 return JSON.stringify({messages,returned:messages.length,nextPageToken:data.nextPageToken||null,resultSizeEstimate:data.resultSizeEstimate,attachmentsIncluded:false});
}
export function gmailListAnswer(text){
 let data;try{data=JSON.parse(text);}catch{return null;}if(!Array.isArray(data.messages)||!Number.isInteger(data.returned))return null;
 if(!data.messages.length)return 'Non risultano email per i filtri richiesti.';
 const clean=value=>String(value||'').replace(/[\r\n]+/g,' ').replace(/[\\`*_\[\]<>]/g,'').slice(0,500);
 const lines=data.messages.map((mail,index)=>{const date=mail.receivedAt?new Intl.DateTimeFormat('it-IT',{timeZone:'Europe/Rome',dateStyle:'short',timeStyle:'short'}).format(new Date(mail.receivedAt)):mail.date||'Data non disponibile';return `${index+1}. **${clean(mail.subject)}**\n   Da: ${clean(mail.from)||'Mittente non disponibile'} · ${clean(date)}${mail.snippet?'\n   '+clean(mail.snippet):''}`;});
 return 'Ecco le email trovate, dalla più recente:\n\n'+lines.join('\n\n')+(data.nextPageToken?'\n\nSono disponibili altri risultati.':'');
}
