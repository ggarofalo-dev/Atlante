import {audioConfiguration,readAudioSettings} from './audio-settings.mjs';
import {createRequire} from 'node:module';
import {existsSync} from 'node:fs';
import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
const root=fileURLToPath(new URL('../',import.meta.url));
const executable=join(root,'runtime/whisper/Release/whisper-cli.exe');
const defaultModel=()=>audioConfiguration(root,'asr');
export const maxVoiceSeconds=60;
export function voiceAvailable(){try{return existsSync(executable)&&existsSync(defaultModel().path);}catch{return false;}}
export function decodeVoice(data){
 if(typeof data!=='string'||data.length>2600000||!/^(?:data:audio\/wav;base64,)?[A-Za-z0-9+/=]+$/.test(data))throw Error('Audio non valido');
 const bytes=Buffer.from(data.replace(/^data:audio\/wav;base64,/,''),'base64');
 if(bytes.length<44||bytes.toString('ascii',0,4)!=='RIFF'||bytes.toString('ascii',8,12)!=='WAVE'||bytes.toString('ascii',12,16)!=='fmt '||bytes.readUInt32LE(16)!==16||bytes.readUInt16LE(20)!==1||bytes.readUInt16LE(22)!==1||bytes.readUInt32LE(24)!==16000||bytes.readUInt16LE(34)!==16||bytes.toString('ascii',36,40)!=='data'||bytes.readUInt32LE(40)!==bytes.length-44||bytes.readUInt32LE(4)!==bytes.length-8||bytes.readUInt32LE(28)!==32000||bytes.readUInt16LE(32)!==2||(bytes.length-44)%2)throw Error('Serve audio WAV mono PCM 16 bit a 16 kHz');
 const seconds=(bytes.length-44)/32000;if(seconds<.3||seconds>maxVoiceSeconds+.1)throw Error('Registra da 1 a 60 secondi');
 let energy=0;for(let i=44;i<bytes.length;i+=2){const v=bytes.readInt16LE(i)/32768;energy+=v*v;}
 if(Math.sqrt(energy/((bytes.length-44)/2))<.002)throw Error('Non ho sentito voce. Avvicinati al microfono e riprova.');
 return bytes;
}
async function run(exe,args,{signal,timeout=120000,stdin=''}={}){
 signal?.throwIfAborted();
 return await new Promise((resolve,reject)=>{
  const child=spawn(exe,args,{cwd:root,windowsHide:true,shell:false,stdio:['pipe','pipe','pipe']});child.stdin.on('error',()=>{});child.stdin.end(stdin);let error='',output='',failure=null;child.stdout.on('data',chunk=>{output=(output+chunk.toString()).slice(-100000);});
  child.stderr.on('data',chunk=>{error=(error+chunk.toString()).slice(-1000);});
  const stop=()=>{failure=signal?.reason||Error('Operazione vocale annullata');child.kill();};
  signal?.addEventListener('abort',stop,{once:true});
  const timer=setTimeout(()=>{failure=Error('Operazione vocale troppo lenta. Riprova con un messaggio più breve.');child.kill();},timeout);
  const cleanup=()=>{clearTimeout(timer);signal?.removeEventListener('abort',stop);};
  child.once('error',err=>{cleanup();reject(err);});
  child.once('close',code=>{cleanup();failure?reject(failure):code===0?resolve(output):reject(Error('Motore vocale non disponibile: '+error.slice(-300)));});
 });
}
export async function transcribe({audio},signal,override){const config=override?audioConfiguration(root,'asr',override):defaultModel();
 if(!existsSync(executable)||!existsSync(config.path))throw Error('Trascrizione locale non installata');const bytes=decodeVoice(audio);
 const directory=await mkdtemp(join(tmpdir(),'atlante-transcribe-'));
 try{const input=join(directory,'input.wav'),output=join(directory,'result');await writeFile(input,bytes);
  await run(executable,['-m',config.path,'-f',input,'-l',config.language,'-t','4','-ng','-otxt','-of',output,'-nt','-np','-sns','-bo','1','-bs','1'],{signal});
  const text=(await readFile(output+'.txt','utf8')).trim().replace(/\[[^\]]*\]/g,'').trim();
  if(!text||/^(?:\([^)]*\)|musica|silenzio)[.!]?$/i.test(text))throw Error('Non ho riconosciuto parole. Riprova parlando più chiaramente.');
  return {text:text.slice(0,12000),language:config.language,seconds:(bytes.length-44)/32000};
 }finally{await rm(directory,{recursive:true,force:true});}
}
async function windowsSpeechVoices(){if(process.platform!=='win32')return [];const output=await run(join(process.env.SystemRoot||'C:/Windows','System32/WindowsPowerShell/v1.0/powershell.exe'),['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',join(root,'scripts/speak-local.ps1'),'-ListVoices'],{timeout:10000});const result=JSON.parse(output.trim().replace(/^\uFEFF/,''));return Array.isArray(result)?result:[result];}
export async function speechVoices(){const data=readAudioSettings(root),piper=data.records.filter(r=>r.kind==='tts'&&r.format==='onnx'&&r.verified&&r.configLocal&&existsSync(join(root,'models/audio',r.local))&&existsSync(join(root,'models/audio',r.configLocal))).map(r=>({name:'piper:'+r.id,label:'Piper · '+r.file.split('/').pop().replace(/\.onnx$/,''),culture:r.file.split('/').slice(0,2).join('/'),gender:'Neural'}));let windows;try{windows=await windowsSpeechVoices();}catch(error){if(!piper.length)throw error;windows=[];}return [...windows,...piper];}
export async function speak({text,voice='',rate=0,volume=100},signal,override){
 if(typeof text!=='string'||!text.trim()||text.length>6000)throw Error('Testo vocale richiesto (massimo 6000 caratteri)');
 if(!Number.isInteger(rate)||rate<-10||rate>10||!Number.isInteger(volume)||volume<0||volume>100)throw Error('Parametri voce non validi');const selected=override||(voice.startsWith('piper:')?readAudioSettings(root).records.find(r=>r.id===voice.slice(6)):null);if(voice.startsWith('piper:')&&!selected)throw Error('Voce Piper non disponibile');const config=selected?audioConfiguration(root,'tts',selected):voice?null:audioConfiguration(root,'tts');
 const directory=await mkdtemp(join(tmpdir(),'atlante-speak-'));
 try{const input=join(directory,'text.txt'),output=join(directory,'speech.wav');await writeFile(input,text,'utf8');
  if(config){const piper=join(root,'runtime/piper/piper.exe');if(!existsSync(piper))throw Error('Prepara il motore Piper dalla gestione Modelli → Audio.');await run(piper,['--model',config.path,'--config',config.config,'--output_file',output,'--length_scale',String(Math.pow(1.08,-rate)),'--espeak_data',join(root,'runtime/piper/espeak-ng-data'),'--tashkeel_model',join(root,'runtime/piper/libtashkeel_model.ort')],{signal,timeout:120000,stdin:text+'\n'});if(volume!==100){const adjusted=join(directory,'adjusted.wav');await run(createRequire(import.meta.url).resolve('@ffmpeg-installer/win32-x64/ffmpeg.exe'),['-y','-i',output,'-af','volume='+(volume/100),adjusted],{signal});return await readFile(adjusted);}return await readFile(output);}
  const powershell=join(process.env.SystemRoot||'C:/Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
  await run(powershell,['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',join(root,'scripts/speak-local.ps1'),'-InputFile',input,'-OutputFile',output,...(voice?['-VoiceName',voice]:[]),'-Rate',String(rate),'-Volume',String(volume)],{signal,timeout:60000});
  return await readFile(output);
 }finally{await rm(directory,{recursive:true,force:true});}
}

