import {existsSync} from 'node:fs';
import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
const root=fileURLToPath(new URL('../',import.meta.url));
const executable=join(root,'runtime/whisper/Release/whisper-cli.exe');
const model=join(root,'models/ggml-base.bin');
export const maxVoiceSeconds=60;
export function voiceAvailable(){return existsSync(executable)&&existsSync(model);}
export function decodeVoice(data){
 if(typeof data!=='string'||data.length>2600000||!/^(?:data:audio\/wav;base64,)?[A-Za-z0-9+/=]+$/.test(data))throw Error('Audio non valido');
 const bytes=Buffer.from(data.replace(/^data:audio\/wav;base64,/,''),'base64');
 if(bytes.length<44||bytes.toString('ascii',0,4)!=='RIFF'||bytes.toString('ascii',8,12)!=='WAVE'||bytes.toString('ascii',12,16)!=='fmt '||bytes.readUInt32LE(16)!==16||bytes.readUInt16LE(20)!==1||bytes.readUInt16LE(22)!==1||bytes.readUInt32LE(24)!==16000||bytes.readUInt16LE(34)!==16||bytes.toString('ascii',36,40)!=='data'||bytes.readUInt32LE(40)!==bytes.length-44||bytes.readUInt32LE(4)!==bytes.length-8||bytes.readUInt32LE(28)!==32000||bytes.readUInt16LE(32)!==2||(bytes.length-44)%2)throw Error('Serve audio WAV mono PCM 16 bit a 16 kHz');
 const seconds=(bytes.length-44)/32000;if(seconds<.3||seconds>maxVoiceSeconds+.1)throw Error('Registra da 1 a 60 secondi');
 let energy=0;for(let i=44;i<bytes.length;i+=2){const v=bytes.readInt16LE(i)/32768;energy+=v*v;}
 if(Math.sqrt(energy/((bytes.length-44)/2))<.002)throw Error('Non ho sentito voce. Avvicinati al microfono e riprova.');
 return bytes;
}
async function run(exe,args,{signal,timeout=120000}={}){
 signal?.throwIfAborted();
 return await new Promise((resolve,reject)=>{
  const child=spawn(exe,args,{cwd:root,windowsHide:true,shell:false,stdio:['ignore','pipe','pipe']});let error='',output='',failure=null;child.stdout.on('data',chunk=>{output=(output+chunk.toString()).slice(-100000);});
  child.stderr.on('data',chunk=>{error=(error+chunk.toString()).slice(-1000);});
  const stop=()=>{failure=signal?.reason||Error('Operazione vocale annullata');child.kill();};
  signal?.addEventListener('abort',stop,{once:true});
  const timer=setTimeout(()=>{failure=Error('Operazione vocale troppo lenta. Riprova con un messaggio più breve.');child.kill();},timeout);
  const cleanup=()=>{clearTimeout(timer);signal?.removeEventListener('abort',stop);};
  child.once('error',err=>{cleanup();reject(err);});
  child.once('close',code=>{cleanup();failure?reject(failure):code===0?resolve(output):reject(Error('Motore vocale non disponibile: '+error.slice(-300)));});
 });
}
export async function transcribe({audio},signal){
 if(!voiceAvailable())throw Error('Trascrizione locale non installata');const bytes=decodeVoice(audio);
 const directory=await mkdtemp(join(tmpdir(),'atlante-transcribe-'));
 try{const input=join(directory,'input.wav'),output=join(directory,'result');await writeFile(input,bytes);
  await run(executable,['-m',model,'-f',input,'-l','it','-t','4','-ng','-otxt','-of',output,'-nt','-np','-sns','-bo','1','-bs','1'],{signal});
  const text=(await readFile(output+'.txt','utf8')).trim().replace(/\[[^\]]*\]/g,'').trim();
  if(!text||/^(?:\([^)]*\)|musica|silenzio)[.!]?$/i.test(text))throw Error('Non ho riconosciuto parole. Riprova parlando più chiaramente.');
  return {text:text.slice(0,12000),language:'it',seconds:(bytes.length-44)/32000};
 }finally{await rm(directory,{recursive:true,force:true});}
}
export async function speechVoices(){if(process.platform!=='win32')return [];const output=await run(join(process.env.SystemRoot||'C:/Windows','System32/WindowsPowerShell/v1.0/powershell.exe'),['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',join(root,'scripts/speak-local.ps1'),'-ListVoices'],{timeout:10000});const result=JSON.parse(output.trim().replace(/^\uFEFF/,''));return Array.isArray(result)?result:[result];}
export async function speak({text,voice='',rate=0,volume=100},signal){
 if(typeof text!=='string'||!text.trim()||text.length>6000)throw Error('Testo vocale richiesto (massimo 6000 caratteri)');
 const directory=await mkdtemp(join(tmpdir(),'atlante-speak-'));
 try{const input=join(directory,'text.txt'),output=join(directory,'speech.wav');await writeFile(input,text,'utf8');
  const powershell=join(process.env.SystemRoot||'C:/Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
  await run(powershell,['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',join(root,'scripts/speak-local.ps1'),'-InputFile',input,'-OutputFile',output,...(voice?['-VoiceName',voice]:[]),'-Rate',String(rate),'-Volume',String(volume)],{signal,timeout:60000});
  return await readFile(output);
 }finally{await rm(directory,{recursive:true,force:true});}
}
