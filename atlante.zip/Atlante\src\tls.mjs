import 'reflect-metadata';
import * as x509 from '@peculiar/x509';
import {webcrypto,createPrivateKey,X509Certificate,randomBytes} from 'node:crypto';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {hostname,networkInterfaces} from 'node:os';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
export const tlsRoot=fileURLToPath(new URL('../data/tls/',import.meta.url));
x509.cryptoProvider.set(webcrypto);
const algorithm={name:'RSASSA-PKCS1-v1_5',hash:'SHA-256',publicExponent:new Uint8Array([1,0,1]),modulusLength:2048};
const serial=()=> '01'+randomBytes(15).toString('hex');
const keyPem=async key=>createPrivateKey({key:Buffer.from(await webcrypto.subtle.exportKey('pkcs8',key)),format:'der',type:'pkcs8'}).export({format:'pem',type:'pkcs8'});
export async function ensureTls(directory=tlsRoot){
 await mkdir(directory,{recursive:true});
 const caFile=join(directory,'atlante-local-ca.crt'),caKeyFile=join(directory,'ca-key.pem'),certFile=join(directory,'server.crt'),keyFile=join(directory,'server-key.pem');
 let ca,signingKey;
 if(existsSync(caFile)&&existsSync(caKeyFile)){
  ca=new x509.X509Certificate(await readFile(caFile,'utf8'));
  const der=createPrivateKey(await readFile(caKeyFile)).export({format:'der',type:'pkcs8'});
  signingKey=await webcrypto.subtle.importKey('pkcs8',der,algorithm,true,['sign']);
 }else{
  const keys=await webcrypto.subtle.generateKey(algorithm,true,['sign','verify']);signingKey=keys.privateKey;
  ca=await x509.X509CertificateGenerator.createSelfSigned({serialNumber:serial(),name:'CN=Atlante Local CA',keys,signingAlgorithm:algorithm,notBefore:new Date(Date.now()-86400000),notAfter:new Date(Date.now()+5*365*86400000),extensions:[new x509.BasicConstraintsExtension(true,0,true),new x509.KeyUsagesExtension(x509.KeyUsageFlags.keyCertSign|x509.KeyUsageFlags.cRLSign,true),await x509.SubjectKeyIdentifierExtension.create(keys.publicKey)]});
  await writeFile(caKeyFile,await keyPem(signingKey),{mode:0o600});await writeFile(caFile,ca.toString('pem'));
 }
 const addresses=[...new Set(['127.0.0.1',...Object.values(networkInterfaces()).flat().filter(a=>a?.family==='IPv4').map(a=>a.address)])];
 const names=['localhost',hostname().toLowerCase()];
 let renew=!existsSync(certFile)||!existsSync(keyFile);
 if(!renew){const current=new X509Certificate(await readFile(certFile));renew=new Date(current.validTo).getTime()<Date.now()+7*86400000||addresses.some(ip=>!current.checkIP(ip))||names.some(name=>!current.checkHost(name));}
 if(renew){
  const keys=await webcrypto.subtle.generateKey(algorithm,true,['sign','verify']);
  const cert=await x509.X509CertificateGenerator.create({serialNumber:serial(),subject:'CN=Atlante Local',issuer:ca.subject,publicKey:keys.publicKey,signingKey,signingAlgorithm:algorithm,notBefore:new Date(Date.now()-86400000),notAfter:new Date(Date.now()+365*86400000),extensions:[new x509.BasicConstraintsExtension(false,undefined,true),new x509.KeyUsagesExtension(x509.KeyUsageFlags.digitalSignature|x509.KeyUsageFlags.keyEncipherment,true),new x509.ExtendedKeyUsageExtension(['1.3.6.1.5.5.7.3.1']),new x509.SubjectAlternativeNameExtension([...names.map(value=>({type:'dns',value})),...addresses.map(value=>({type:'ip',value}))]),await x509.SubjectKeyIdentifierExtension.create(keys.publicKey),await x509.AuthorityKeyIdentifierExtension.create(ca.publicKey)]});
  await writeFile(keyFile,await keyPem(keys.privateKey),{mode:0o600});await writeFile(certFile,cert.toString('pem'));
 }
 return {key:await readFile(keyFile),cert:await readFile(certFile),ca:await readFile(caFile)};
}
