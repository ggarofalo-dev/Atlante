import {ensureTls,tlsRoot} from '../src/tls.mjs';
import {X509Certificate} from 'node:crypto';
const result=await ensureTls();const ca=new X509Certificate(result.ca);
console.log('Certificato pubblico: '+tlsRoot+'atlante-local-ca.crt');
console.log('Autorità: '+ca.subject);console.log('Impronta SHA256: '+ca.fingerprint256);
