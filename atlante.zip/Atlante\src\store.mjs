import {documentHash} from './document-retrieval.mjs';
import {initializeWorkspace,sessionAssistant} from './workspace.mjs';
import { DatabaseSync } from 'node:sqlite';
import { createHash, randomUUID } from 'node:crypto';
import {initializeConversations} from './conversations.mjs';

export class Store {
  constructor(path) {
    this.db = new DatabaseSync(path);
    this.db.exec(`PRAGMA journal_mode=WAL;
      CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY,title TEXT,url TEXT,license TEXT,kind TEXT,created TEXT,hash TEXT UNIQUE);
      CREATE VIRTUAL TABLE IF NOT EXISTS chunks USING fts5(doc UNINDEXED,body, tokenize='unicode61');
      CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY,session TEXT,role TEXT,content TEXT,created TEXT);`);
    this.db.exec(`CREATE TABLE IF NOT EXISTS source_versions(id INTEGER PRIMARY KEY,doc TEXT,title TEXT,url TEXT,body TEXT,archived TEXT);`);
    this.db.exec('CREATE TABLE IF NOT EXISTS session_titles(session TEXT PRIMARY KEY,title TEXT); CREATE TABLE IF NOT EXISTS message_files(message_id INTEGER PRIMARY KEY,name TEXT,url TEXT);');
    this.db.exec('CREATE TABLE IF NOT EXISTS image_artifacts(url TEXT PRIMARY KEY,name TEXT,prompt TEXT,created TEXT,message_id INTEGER);');
    this.db.exec('CREATE TABLE IF NOT EXISTS session_documents(id INTEGER PRIMARY KEY,session TEXT,name TEXT,text TEXT,created TEXT);');
    this.db.exec('CREATE TABLE IF NOT EXISTS document_texts(doc TEXT PRIMARY KEY,text TEXT);CREATE TABLE IF NOT EXISTS chunk_details(chunk_id INTEGER PRIMARY KEY,page INTEGER);');
    this.db.exec('CREATE TABLE IF NOT EXISTS attachment_embeddings(doc_hash TEXT,chunk_hash TEXT,model TEXT,vector TEXT,PRIMARY KEY(doc_hash,chunk_hash,model));');
    this.db.exec('CREATE TABLE IF NOT EXISTS image_provenance(url TEXT PRIMARY KEY,model TEXT);');
    initializeConversations(this);
    initializeWorkspace(this);
    for(const doc of this.db.prepare("SELECT id FROM documents WHERE kind='document' AND id NOT IN (SELECT doc FROM document_texts)").all()){
      const text=this.document(doc.id).text;this.db.exec('BEGIN');try{this.db.prepare('INSERT INTO document_texts VALUES(?,?)').run(doc.id,text);if(/\[Pagina \d+/.test(text)){this.purgeChunks(doc.id);this.writeChunks(doc.id,text);}this.db.exec('COMMIT');}catch(e){this.db.exec('ROLLBACK');throw e;}
    }
  }
  add({title,text,url='',license='Non specificata',kind='document'}) {
    if(typeof text!=='string'||!text.trim()||text.length>1000000) throw Error('Testo richiesto, massimo 1 milione di caratteri.');
    const hash=createHash('sha256').update(kind+'\0'+text).digest('hex');
    const existing=this.db.prepare('SELECT id FROM documents WHERE hash=?').get(hash);
    if(existing) return {id:existing.id,duplicate:true};
    const id=randomUUID();
    this.db.exec('BEGIN');
    try {
      this.db.prepare('INSERT INTO documents VALUES(?,?,?,?,?,?,?)').run(id,String(title||'Documento').slice(0,300),String(url),String(license),kind,new Date().toISOString(),hash);
      this.db.prepare('INSERT INTO document_texts VALUES(?,?)').run(id,text);
      this.writeChunks(id,text);
      this.db.exec('COMMIT');
    } catch(e) {this.db.exec('ROLLBACK');throw e;}
    return {id,duplicate:false};
  }
  writeChunks(id,text){
      const insert=this.db.prepare('INSERT INTO chunks(doc,body) VALUES(?,?)');
      const markers=[...text.matchAll(/\[Pagina (\d+)(?:[^\]]*)\]\n/g)];
      const segments=markers.length?markers.map((m,i)=>({page:Number(m[1]),text:text.slice(m.index+m[0].length,markers[i+1]?.index??text.length)})):[{page:null,text}];
      for(const segment of segments)for(let i=0;i<segment.text.length;i+=1100){const chunk=insert.run(id,segment.text.slice(i,i+1400));this.db.prepare('INSERT INTO chunk_details VALUES(?,?)').run(Number(chunk.lastInsertRowid),segment.page);}
  }
  search(query,limit=6) {
    const stop=new Set('che cosa come quale quali sono della delle degli nella nelle anche una uno per con del dei gli alla alle nel sul non rispondi frase the and what how'.split(' '));
    const terms=[...new Set(String(query).toLowerCase().match(/[\p{L}\p{N}]{3,}/gu)||[])].filter(t=>!stop.has(t)).slice(0,24);
    if(!terms.length)return [];
    return this.db.prepare(`SELECT d.id,d.title,d.url,d.license,d.kind,c.rowid chunkId,c.body,cd.page,bm25(chunks) score FROM chunks c JOIN documents d ON d.id=c.doc LEFT JOIN chunk_details cd ON cd.chunk_id=c.rowid WHERE chunks MATCH ? ORDER BY score LIMIT ?`).all(terms.map(t=>'"'+t+'"').join(' OR '),limit);
  }
  list(){return this.db.prepare('SELECT id,title,url,license,kind,created FROM documents ORDER BY created DESC').all();}
  sessions(){return this.db.prepare(`SELECT session,MIN(created) created,MAX(created) updated,COUNT(*) count,COALESCE((SELECT title FROM session_titles t WHERE t.session=m.session),(SELECT substr(content,1,100) FROM messages first WHERE first.session=m.session AND role='user' ORDER BY id LIMIT 1)) title FROM messages m GROUP BY session ORDER BY MAX(id) DESC`).all();}
  conversation(session){return this.db.prepare('SELECT id,role,content,created FROM messages WHERE session=? ORDER BY id').all(session).map(message=>({...message,workspace:JSON.parse(this.db.prepare('SELECT json FROM message_workspace WHERE message_id=?').get(message.id)?.json||'null'),assistant:sessionAssistant(this,session),sources:JSON.parse(this.db.prepare('SELECT json FROM message_sources WHERE message_id=?').get(message.id)?.json||'[]'),artifact:this.db.prepare('SELECT a.name,a.url,p.model imageModel FROM image_artifacts a LEFT JOIN image_provenance p ON p.url=a.url WHERE message_id=?').get(message.id)||this.db.prepare('SELECT name,url FROM message_files WHERE message_id=?').get(message.id)||null}));}
  imageResult({artifact,originalArtifact,answer='Immagine creata.',prompt,scenePrompt,session,remember=true}){this.db.exec('BEGIN');try{let userId=null,messageId=null;if(remember){userId=this.message(session,'user',prompt);messageId=this.message(session,'assistant',answer);}const insert=this.db.prepare('INSERT INTO image_artifacts VALUES(?,?,?,?,?)');if(originalArtifact)insert.run(originalArtifact.url,originalArtifact.name,prompt,new Date().toISOString(),userId);if(artifact){insert.run(artifact.url,artifact.name,scenePrompt||prompt,new Date().toISOString(),messageId);if(artifact.imageModel)this.db.prepare('INSERT OR REPLACE INTO image_provenance VALUES(?,?)').run(artifact.url,artifact.imageModel);}this.db.exec('COMMIT');}catch(e){this.db.exec('ROLLBACK');throw e;}}
  sessionImage(session){return this.db.prepare('SELECT a.url,a.name,a.prompt FROM image_artifacts a JOIN messages m ON m.id=a.message_id WHERE m.session=? ORDER BY m.id DESC LIMIT 1').get(session);}
  sessionDocuments(session){return this.db.prepare('SELECT name,text FROM session_documents WHERE session=? ORDER BY id DESC LIMIT 4').all(session);}
  rememberDocuments(session,documents){for(const doc of documents){if(this.db.prepare('SELECT 1 FROM session_documents WHERE session=? AND name=? AND text=?').get(session,doc.name,doc.text))continue;this.db.prepare('INSERT INTO session_documents(session,name,text,created) VALUES(?,?,?,?)').run(session,doc.name,doc.text,new Date().toISOString());}}
  imageMetadata(){return this.db.prepare('SELECT a.*,p.model imageModel,m.session FROM image_artifacts a LEFT JOIN image_provenance p ON p.url=a.url LEFT JOIN messages m ON a.message_id=m.id ORDER BY a.created DESC').all();}
  removeImage(url){this.db.exec('BEGIN');try{this.db.prepare("UPDATE messages SET content=CASE WHEN role='user' THEN content || char(10) || '[Immagine allegata eliminata dalla libreria.]' ELSE 'Immagine eliminata dalla libreria.' END WHERE id IN (SELECT message_id FROM image_artifacts WHERE url=?)").run(url);this.db.prepare('DELETE FROM image_artifacts WHERE url=?').run(url);this.db.prepare('DELETE FROM image_provenance WHERE url=?').run(url);this.db.exec('COMMIT');}catch(e){this.db.exec('ROLLBACK');throw e;}}
  document(id){const doc=this.db.prepare('SELECT id,title,kind FROM documents WHERE id=?').get(id);if(!doc)return null;const chunks=this.db.prepare('SELECT body FROM chunks WHERE doc=? ORDER BY rowid').all(id);let text=this.db.prepare('SELECT text FROM document_texts WHERE doc=?').get(id)?.text||'';if(!text)for(const [i,chunk] of chunks.entries())text+=i?chunk.body.slice(Math.min(300,text.length-i*1100)):chunk.body;const message=doc.kind==='memory'?this.db.prepare("SELECT session FROM messages WHERE role='user' AND content=? ORDER BY id DESC LIMIT 1").get(text):null;return {...doc,text,session:message?.session||null};}
  purgeChunks(id){this.db.prepare('DELETE FROM chunk_details WHERE chunk_id IN (SELECT rowid FROM chunks WHERE doc=?)').run(id);if(this.db.prepare("SELECT 1 FROM sqlite_master WHERE name='embeddings'").get())this.db.prepare('DELETE FROM embeddings WHERE chunk_id IN (SELECT rowid FROM chunks WHERE doc=?)').run(id);this.db.prepare('DELETE FROM chunks WHERE doc=?').run(id);}
  remove(id){this.db.exec('BEGIN');try {const doc=this.db.prepare('SELECT url,kind FROM documents WHERE id=?').get(id);if(doc?.kind==='web')this.db.prepare('DELETE FROM source_versions WHERE doc=? OR url=?').run(id,doc.url);this.purgeChunks(id);this.db.prepare('DELETE FROM document_texts WHERE doc=?').run(id);this.db.prepare('DELETE FROM documents WHERE id=?').run(id);this.db.exec('COMMIT');}catch(e){this.db.exec('ROLLBACK');throw e;}}
  message(session,role,content){return Number(this.db.prepare('INSERT INTO messages(session,role,content,created) VALUES(?,?,?,?)').run(session,role,content,new Date().toISOString()).lastInsertRowid);}
  history(session){return this.db.prepare('SELECT role,content FROM (SELECT id,role,content FROM messages WHERE session=? ORDER BY id DESC LIMIT 10) ORDER BY id').all(session);}
  clearSession(session){this.db.exec('BEGIN');try{this.db.prepare('DELETE FROM message_workspace WHERE message_id IN (SELECT id FROM messages WHERE session=?)').run(session);this.db.prepare('DELETE FROM session_assistants WHERE session=?').run(session);this.db.prepare('DELETE FROM session_datasets WHERE session=?').run(session);this.db.prepare('DELETE FROM datasets WHERE id NOT IN (SELECT dataset FROM session_datasets)').run();this.db.prepare('DELETE FROM message_sources WHERE message_id IN (SELECT id FROM messages WHERE session=?)').run(session);this.db.prepare('DELETE FROM session_projects WHERE session=?').run(session);this.db.prepare('UPDATE image_artifacts SET message_id=NULL WHERE message_id IN (SELECT id FROM messages WHERE session=?)').run(session);this.db.prepare('DELETE FROM message_files WHERE message_id IN (SELECT id FROM messages WHERE session=?)').run(session);this.db.prepare('DELETE FROM session_pins WHERE session=?').run(session);this.db.prepare('DELETE FROM session_titles WHERE session=?').run(session);this.db.prepare('DELETE FROM session_documents WHERE session=?').run(session);this.db.prepare('DELETE FROM messages WHERE session=?').run(session);this.cleanAttachmentIndex();this.db.exec('COMMIT');}catch(e){this.db.exec('ROLLBACK');throw e;}}
  cleanAttachmentIndex(){const used=new Set();for(const doc of this.db.prepare('SELECT name,text FROM session_documents').iterate())used.add(documentHash(doc));for(const row of this.db.prepare('SELECT DISTINCT doc_hash FROM attachment_embeddings').all())if(!used.has(row.doc_hash))this.db.prepare('DELETE FROM attachment_embeddings WHERE doc_hash=?').run(row.doc_hash);}
  close(){this.db.close();}
  refreshWeb(data){
    const old=this.db.prepare("SELECT * FROM documents WHERE url=? AND kind='web' ORDER BY created DESC").all(data.url);
    if(!old.length)return this.add({...data,kind:'web'});
    const hash=createHash('sha256').update('web\0'+data.text).digest('hex');
    if(old.some(d=>d.hash===hash))return {id:old[0].id,duplicate:true};
    const collision=this.db.prepare('SELECT id FROM documents WHERE hash=?').get(hash);
    if(collision)return {id:collision.id,duplicate:true};
    const current=old[0];this.db.exec('BEGIN');
    try{
      for(const doc of old){const body=this.db.prepare('SELECT body FROM chunks WHERE doc=? ORDER BY rowid').all(doc.id).map(c=>c.body).join('\n');this.db.prepare('INSERT INTO source_versions(doc,title,url,body,archived) VALUES(?,?,?,?,?)').run(doc.id,doc.title,doc.url,body,new Date().toISOString());this.purgeChunks(doc.id);if(doc.id!==current.id){this.db.prepare('DELETE FROM documents WHERE id=?').run(doc.id);this.db.prepare('DELETE FROM document_texts WHERE doc=?').run(doc.id);}}
      this.db.prepare('UPDATE documents SET title=?,license=?,created=?,hash=? WHERE id=?').run(data.title,data.license||'Verificare la fonte',new Date().toISOString(),hash,current.id);
      this.db.prepare('INSERT INTO document_texts VALUES(?,?) ON CONFLICT(doc) DO UPDATE SET text=excluded.text').run(current.id,data.text);
      const insert=this.db.prepare('INSERT INTO chunks(doc,body) VALUES(?,?)');for(let i=0;i<data.text.length;i+=1100)insert.run(current.id,data.text.slice(i,i+1400));
      this.db.prepare('DELETE FROM source_versions WHERE url=? AND id NOT IN (SELECT id FROM source_versions WHERE url=? ORDER BY id DESC LIMIT 2)').run(data.url,data.url);
      this.db.exec('COMMIT');return {id:current.id,updated:true,duplicate:false};
    }catch(e){this.db.exec('ROLLBACK');throw e;}
  }
}
