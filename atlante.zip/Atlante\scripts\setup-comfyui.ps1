$ErrorActionPreference = 'Stop'
$workspace = Split-Path -Parent $PSScriptRoot
$destination = Join-Path $workspace 'runtime\comfyui'
$archive = Join-Path $workspace '.cache\ComfyUI-cu126.7z'
New-Item -ItemType Directory -Path $destination -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $workspace '.cache') -Force | Out-Null
$release = Invoke-RestMethod 'https://api.github.com/repos/Comfy-Org/ComfyUI/releases/tags/v0.38.0'
$asset = $release.assets | Where-Object name -EQ 'ComfyUI_windows_portable_nvidia_cu126.7z' | Select-Object -First 1
if (-not $asset) { throw 'Pacchetto ufficiale CUDA 12.6 non trovato. Nessun pacchetto alternativo installato.' }
$expectedHash = 'bd3bd7e3ce0068d8bc58fe46c912c360dd510f9bcfd0c5029d4906e6e6fbc677'
if ($asset.size -ne 1886111296) { throw 'Il pacchetto ufficiale non corrisponde alla versione verificata da Atlante.' }
Write-Output "Download ufficiale ComfyUI: $($asset.name), $([math]::Round($asset.size / 1GB, 2)) GB"
& curl.exe --fail --location --retry 3 --continue-at - --output $archive $asset.browser_download_url
if ($LASTEXITCODE -ne 0) { throw 'Download interrotto: riesegui lo script per riprenderlo.' }
if ((Get-Item -LiteralPath $archive).Length -ne $asset.size) { throw 'Dimensione download non valida.' }
$digest = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
if ($digest -ne $expectedHash) { throw 'Checksum download non valido.' }
# Refuse archives that can escape the intended runtime directory.
$entries = & tar.exe -tf $archive
if ($LASTEXITCODE -ne 0) { throw 'Archivio non leggibile dal tar di Windows.' }
foreach ($entry in $entries) { if ($entry -match '(^[/\\]|(^|[/\\])\.\.([/\\]|$)|:)') { throw 'Percorso archivio non sicuro.' } }
& tar.exe -xf $archive -C $destination
if ($LASTEXITCODE -ne 0) { throw 'Estrazione ComfyUI fallita.' }
$portable = Join-Path $destination 'ComfyUI_windows_portable'
if (-not (Test-Path -LiteralPath (Join-Path $portable 'python_embeded\python.exe'))) { throw 'Python portatile non trovato.' }
@{asset=$asset.name;source=$asset.browser_download_url;sha256=$digest;size=$asset.size;installed=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $destination 'installation.json') -Encoding UTF8
# Share the existing checkpoint; no model downloads or external inference.
$modelDirectory = (Join-Path $workspace 'models').Replace('\','/')
"atlante:`n  base_path: $modelDirectory`n  checkpoints: .`n" | Set-Content -LiteralPath (Join-Path $portable 'ComfyUI\extra_model_paths.yaml') -Encoding UTF8
Write-Output "Installato in $portable. Avvio: scripts\start-comfyui.ps1"
