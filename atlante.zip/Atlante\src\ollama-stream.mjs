import {ollamaBase} from './ollama-config.mjs';
export async function streamChat(body,signal,onDelta,request=fetch){
 const response=await request(ollamaBase+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...body,stream:true}),signal:signal?AbortSignal.any([signal,AbortSignal.timeout(600000)]):AbortSignal.timeout(600000)});
 if(!response.ok)throw Error('Ollama: '+(await response.text()).slice(0,300));
 const decoder=new TextDecoder();let pending='',text='',last=null;
 const consume=line=>{if(!line.trim())return;const chunk=JSON.parse(line);if(chunk.error)throw Error(chunk.error);if(chunk.message?.content){text+=chunk.message.content;onDelta(chunk.message.content);}if(chunk.done)last=chunk;};
 for await(const bytes of response.body){pending+=decoder.decode(bytes,{stream:true});let index;while((index=pending.indexOf('\n'))>=0){consume(pending.slice(0,index));pending=pending.slice(index+1);}if(pending.length>1024*1024)throw Error('Risposta Ollama non valida');}
 consume(pending+decoder.decode());if(!last)throw Error('Risposta interrotta prima del completamento');return {...last,message:{role:'assistant',content:text}};
}
