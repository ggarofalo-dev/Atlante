import {createHash} from 'node:crypto';
const repoPattern=/^[\w.-]+\/[\w.-]+$/;
export function videoRepository(repo){if(typeof repo!=='string'||!repoPattern.test(repo)||repo.includes('..'))throw Error('Repository non valido: usa autore/nome su Hugging Face.');return repo;}
export function videoDefinition(input){
 if(!input||typeof input.name!=='string'||!input.name.trim()||input.name.length>160||!Array.isArray(input.modes)||!input.modes.length||input.modes.some(m=>!['text','image'].includes(m)))throw Error('Nome e modalità del pacchetto video non validi.');
 if(!Array.isArray(input.components)||input.components.length<3||input.components.length>5)throw Error('Il pacchetto richiede modello, encoder e VAE.');
 const components=input.components.map(c=>{videoRepository(c.repo);if(!['model','highModel','encoder','vae','clipVision'].includes(c.key)||typeof c.file!=='string'||c.file.length>500||c.file.includes('..')||c.file.includes('\\')||c.file.startsWith('/')||!/\.(safetensors|gguf)$/i.test(c.file))throw Error('Componente video non valido.');return {key:c.key,repo:c.repo,file:c.file};});
 if(new Set(components.map(c=>c.key)).size!==components.length||['model','encoder','vae'].some(key=>!components.some(c=>c.key===key)))throw Error('Componenti video mancanti o duplicati.');
 const id='custom-'+createHash('sha256').update(JSON.stringify({components,modes:input.modes})).digest('hex').slice(0,24);
 return {id,name:input.name.trim(),modes:[...new Set(input.modes)],components,custom:true,ramGB:null,vramGB:null};
}
export async function videoRepositoryInfo(hub,repo,signal){
 videoRepository(repo);const info=await hub.json('https://huggingface.co/api/models/'+repo+'?blobs=true',signal);if(!/^[a-f0-9]{40,64}$/.test(info.sha||''))throw Error('Revisione del repository non valida.');
 const files=(info.siblings||[]).filter(f=>/\.(safetensors|gguf)$/i.test(f.rfilename||'')).map(f=>{const hash=f.lfs?.sha256,bytes=f.lfs?.size||f.size;return {name:f.rfilename,hash,bytes:bytes||0,downloadable:(!info.gated||!!hub.token)&&!info.private&&/^[a-f0-9]{64}$/.test(hash||'')&&Number.isSafeInteger(bytes)&&bytes>0};});
 return {id:repo,revision:info.sha,license:info.cardData?.license||info.tags?.find(t=>t.startsWith('license:'))?.slice(8)||'Consulta la scheda originale',url:'https://huggingface.co/'+repo,pipeline:info.pipeline_tag||'',files};
}
export async function searchVideoCatalog(hub,{query='',cursor='',sort='downloads',pipelines=['text-to-video','image-to-video']}={}){
 if(typeof query!=='string'||query.length>150||!['downloads','lastModified'].includes(sort))throw Error('Ricerca video non valida.');
 const base='https://huggingface.co/api/models';let targets;
 if(cursor){const url=new URL(cursor);if(url.origin!=='https://huggingface.co'||url.pathname!=='/api/models'||url.username||url.password||cursor.length>8000)throw Error('Pagina del catalogo non valida.');targets=[url.href];}
 else targets=query?[base+'?'+new URLSearchParams({search:query,sort,direction:'-1',limit:'60',full:'true'})]:pipelines.map(filter=>base+'?'+new URLSearchParams({filter,sort,direction:'-1',limit:'30',full:'true'}));
 const pages=await Promise.all(targets.map(async url=>{const response=await hub.request(url,{headers:hub.token?{Authorization:'Bearer '+hub.token}:{},signal:AbortSignal.timeout(20000),redirect:'error'});if(!response.ok)throw Error('Catalogo video non disponibile: HTTP '+response.status);const data=await response.json();if(!Array.isArray(data))throw Error('Risposta catalogo non valida.');return {models:data.filter(m=>repoPattern.test(m.id)&&!m.id.includes('..')).map(m=>({id:m.id,pipeline:m.pipeline_tag||'',downloads:m.downloads||0,gated:!!m.gated,url:'https://huggingface.co/'+m.id})),next:response.headers.get('link')?.match(/<([^>]+)>;\s*rel="next"/)?.[1]||''};}));
 return {source:'Hugging Face',models:[...new Map(pages.flatMap(p=>p.models).map(m=>[m.id,m])).values()],next:pages.map(p=>p.next).filter(Boolean),checkedAt:new Date().toISOString()};
}
