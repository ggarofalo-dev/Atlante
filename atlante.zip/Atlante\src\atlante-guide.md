# Come funziona Atlante

Manuale d'uso e riferimento tecnico per Atlante 0.7.1. Questa guida descrive l'applicazione distribuita; disponibilità e prestazioni dipendono dai componenti installati, dai modelli, dall'hardware e dai permessi dell'account. Le etichette qui riportate sono quelle dell'interfaccia italiana: alcune finestre mantengono un titolo diverso dalla voce del menu.

## 1. Che cos'è Atlante e chi lo ha scritto

Atlante è stato scritto da Gianluca Garofalo. Atlante è uno studio di intelligenza artificiale con un server installato sul PC e un'interfaccia web, utilizzabile dal browser del PC e da dispositivi della stessa rete. Riunisce chat con modelli linguistici, memoria, documenti e biblioteca, ricerca Internet con fonti, immagini, voce, analisi di tabelle, assistenti personalizzati, strumenti esterni e collaborazione fra utenti. Non è un singolo modello AI: coordina software e modelli diversi. Ollama, ComfyUI, Stable Diffusion, Whisper e gli altri componenti hanno i propri autori e licenze; l'attribuzione di Atlante a Gianluca Garofalo non attribuisce a lui la creazione di questi componenti.

Conversazione, visione, OCR, voce e immagini possono essere elaborati sul PC server. Ricerca web, download e connessioni esterne usano Internet quando richiesti o abilitati. È quindi possibile lavorare offline dopo aver installato i componenti necessari, ma le funzioni online non funzionano senza rete. La memoria è recupero di informazioni salvate, non addestramento del modello. La qualità non è garantita: un modello può fraintendere istruzioni, fonti o immagini.

## 2. Primo accesso e navigazione

Avvia il collegamento Atlante sul desktop oppure start.cmd nella cartella del progetto. Sul PC apri http://localhost:3210 o http://127.0.0.1:3210. Accedi con l'account Atlante; una nuova installazione prevede admin / admin123. Cambia la password dal menu con il nome utente e crea gli account necessari. Il nome utente rimane in basso nel menu laterale.

Il pulsante a tre linee apre o chiude il menu. Le sezioni Conversazioni, Il tuo spazio e Amministrazione si aprono cliccando il titolo; l'apertura di una richiude le altre. Amministrazione è visibile solo agli amministratori. Su desktop trascina il bordo destro del menu per cambiarne la larghezza; doppio clic ripristina il valore iniziale. Con il bordo selezionato, frecce, Home/End ed Enter regolano o ripristinano la larghezza. Su mobile il menu è adattivo.

Le finestre modali si chiudono con la X in alto a destra o cliccando sullo sfondo esterno; Escape può chiudere la finestra. Se ci sono modifiche non salvate in un documento, la richiesta di conferma rimane valida. Chiudere una finestra non equivale necessariamente ad annullare un'attività già avviata: per fermare una generazione o un download usa il relativo Interrompi o Annulla.

## 3. Chat: scrivere, rispondere e gestire le conversazioni

Conversazioni → Nuova conversazione apre una chat vuota. Scrivi nel campo del messaggio e premi la freccia Invia messaggio. I suggerimenti Sviluppa un'idea, Riassumi una pagina e Crea un documento inseriscono una bozza da completare. La risposta arriva progressivamente. Interrompi nella barra ferma la richiesta anche se è in coda; non cancella gli effetti di strumenti esterni già eseguiti.

Il pulsante Opzioni della conversazione, con l'icona dei cursori, apre i controlli:
- Modello chat sceglie un modello Ollama installato per la risposta; Assistente sceglie Generale o un assistente personale/condiviso. La scelta dell'assistente può impostare il suo modello.
- Modello immagini sceglie il modello visivo per questa conversazione; Predefinito usa il default immagini. Non confondere il modello che genera immagini con quello che le interpreta.
- Memorizza, inizialmente attivo, salva il nuovo scambio nella cronologia e ne consente il recupero. Disattivalo prima di inviare per una chat senza salvataggio del nuovo scambio. I file prodotti possono comunque essere salvati.
- Approfondisci sul web e Segui link sono inizialmente attivi. Approfondisci richiede ricerca online dopo il recupero locale; non esclude la memoria. Segui link riguarda la lettura delle pagine collegate a una URL aperta.
- Leggi le risposte ai messaggi vocali abilita la lettura automatica delle relative risposte.
- Allega immagini come testo (OCR), da attivare prima del caricamento, trasforma l'immagine in testo allegato anziché usarla solo come immagine da interpretare.
- Risultato sceglie Automatico, Word (.docx), Excel (.xlsx), PowerPoint (.pptx), PDF o Testo (.txt).

Le risposte possono contenere Markdown, tabelle e codice. Copia codice nei blocchi copia il testo del blocco. Modifica sotto un messaggio permette di cambiarne la richiesta; Rigenera chiede una nuova risposta: queste azioni creano una nuova versione della conversazione e conservano l'originale. Ascolta legge una risposta. Salva come documento crea un documento personale dalla risposta; Esporta risposta apre i pulsanti DOCX, XLSX, PPTX, PDF e TXT per scaricarla. Apri fonte apre la pagina citata. I link ai file scaricano l'artefatto generato.

Nel menu laterale Cerca una conversazione cerca nel testo delle chat; il filtro progetto restringe l'elenco. Il menu a tre puntini della chat contiene Rinomina (cambia titolo), Fissa (porta in cima; ripetilo per togliere il fissaggio), Condividi (gestisce accessi), Elimina (rimuove la conversazione dopo conferma) e Sposta in un progetto. Per spostarla scegli un progetto e Salva spostamento; Nessun progetto rimuove l'assegnazione. Crea progetto apre la creazione e poi torna allo spostamento. Annulla abbandona lo spostamento.

Importa chat, sotto Nuova conversazione, legge l'esportazione JSON. Esporta chat nel menu del nome utente salva le conversazioni in JSON con testo, date e fonti, ma non incorpora gli allegati. Il backup completo serve per conservare anche file e account. Eliminare una chat elimina il suo contesto documentale; le immagini possono restare nella galleria.

## 4. Memoria, biblioteca e fonti

Atlante recupera prima informazioni disponibili nella memoria dell'utente, nella biblioteca condivisa e nel contesto consentito di allegati e assistenti. Cerca parole nel testo con SQLite FTS5/BM25 e, quando disponibile, usa vettori semantici e un riordino locale dei passaggi. Inserisce nel contesto del modello estratti pertinenti, non necessariamente l'intero archivio. Memorizzare un'informazione non modifica i pesi di Ollama e non la rende vera. Domande salvate e risposte AI non sono automaticamente fonti verificate.

Il tuo spazio → Biblioteca condivisa apre il catalogo permanente dei documenti condivisi. Gestione riservata agli amministratori e agli utenti con Abilita gestione biblioteca. Scegli il file nel selettore e premi Importa conoscenza. Apri il titolo per leggere l'anteprima; quando il contenuto è associato a una chat, l'apertura può riportare alla conversazione. Elimina rimuove il documento, senza cancellare separatamente le citazioni già conservate nelle chat: nell'interfaccia attuale questa azione non chiede una conferma.

La biblioteca importa PDF, DOCX, XLSX, PNG/JPG/WebP, TXT, MD, CSV, TSV, JSON e JSONL, fino a 10 MB per file. JSON/JSONL possono contenere oggetti con title e text; i duplicati di contenuto vengono ignorati. L'estrazione documentale arriva fino a 300 pagine PDF e 1.000.000 di caratteri. Scansioni e immagini usano OCR italiano/inglese: fino a 20 pagine OCR e circa tre minuti per documento. PDF misti sono gestiti automaticamente; qualità scarsa, manoscritti e tabelle complesse possono produrre errori.

Attiva ricerca semantica scarica EmbeddingGemma e indicizza la biblioteca localmente. Aggiorna indice indicizza i passaggi mancanti dopo importazioni o aggiornamenti. Interrompi indicizzazione annulla il lavoro corrente. Il contatore mostra quanti passaggi sono indicizzati; la ricerca testuale resta disponibile se la semantica non funziona. Dopo un aggiornamento del manuale, Aggiorna indice può indicizzarne i nuovi passaggi. L'indice condiviso non include le memorie private degli altri utenti.

Questa guida Come funziona Atlante è inclusa nel pacchetto e inserita alla prima inizializzazione della biblioteca. Puoi consultarla offline. Gli avvii successivi non creano copie; se la elimini non viene reinserita a ogni avvio. La revisione del manuale introduce un aggiornamento della guida già presente senza cambiare il suo identificativo.

### Ricerca Internet e citazioni

Per domande fattuali Atlante può approfondire online anche quando ha riscontri locali. Per altre domande valuta se le conoscenze disponibili bastano. La query automatica usa la domanda corrente, non invia automaticamente il testo dei documenti o dell'intera memoria al motore di ricerca. Le opzioni e i permessi dell'assistente influenzano l'accesso web; una richiesta esplicita «senza Internet» esclude il web. Togliere Approfondisci sul web rimuove la forzatura, ma non è un interruttore generale che vieta ogni ricerca automatica. Per richiedere solo dati locali scrivi «rispondi senza Internet usando la memoria e la biblioteca».

La ricerca usa DuckDuckGo e legge fino a tre risultati pubblici quando possibile. La risposta combina fonti locali e web e deve segnalare eventuali contrasti. Fonti consultate contiene riferimenti numerati e link recuperati; un estratto del motore non equivale alla lettura completa della pagina. Leggi passaggio apre il testo utilizzato di una fonte documentale; il numero di pagina appare quando è disponibile, senza inventarlo. Controlla sempre il contenuto originale per risolvere dubbi o contrasti.

Incolla una URL e chiedi di riassumerla: il server scarica il testo. Segui link può aggiungere fino a tre pagine pertinenti della stessa origine, a un livello di profondità. Non è navigazione con login o browser JavaScript; siti protetti, anti-bot o con testo caricato dinamicamente possono essere illeggibili. Non interpretare gli estratti selezionati come lettura integrale di un sito lungo. Se il recupero fallisce Atlante segnala il problema; fonti locali sufficienti possono sostenere una risposta con dichiarazione del mancato approfondimento.

Le pagine e le memorie salvate sono dell'utente: non entrano automaticamente nella biblioteca condivisa. Anche gli allegati della chat e i documenti di un assistente seguono archivi e permessi propri. Per rendere un testo conoscenza condivisa usa l'importazione della biblioteca, non la sola spunta Memorizza.

## 5. Allegati e creazione di file

Il pulsante + accanto al messaggio apre Allega immagini o documenti. Seleziona fino a quattro documenti PDF, DOCX, XLSX, TXT, MD, CSV, TSV, JSON o JSONL, massimo 10 MB ciascuno, e poi scrivi la domanda. Puoi rimuovere un allegato dalla bozza prima di inviare. Le domande successive della stessa chat possono usare i documenti già allegati se Memorizza è attivo. Senza memorizzazione il contesto rimane nella scheda aperta e si perde aprendo una nuova conversazione o chiudendo la pagina.

Atlante recupera passaggi dall'intero testo estratto, anche nelle pagine finali; nel contesto entrano estratti selezionati, fino a 24.000 caratteri. Per sintesi lunghe può usare passaggi distribuiti senza aver letto integralmente tutto. Una sola immagine PNG/JPEG/WebP per messaggio, massimo 10 MB e 25 milioni di pixel; invia documenti e immagini in messaggi separati. Per interpretare una foto serve il modello visivo locale, normalmente Gemma 3 4B. Per trascrivere un'immagine abilita l'OCR oppure chiedi «Trascrivi il testo».

Per creare un file scegli Risultato oppure chiedi un documento esplicitamente, descrivendo contenuto, struttura e destinatario. Il modello prepara dati strutturati e il server produce DOCX, XLSX, PPTX, PDF o TXT da scaricare. L'esportazione di una risposta già presente può evitare una nuova inferenza. I layout sono essenziali; verifica testo e numeri. La generazione Office non esegue macro e non equivale alla modifica diretta dell'impaginazione di un file Office caricato.

## 6. Documenti personali e versioni

Il tuo spazio → Documenti apre Documenti personali. Nuovo documento apre una bozza con Titolo e Testo. Importa testo o Word carica TXT, MD o DOCX e recupera il testo, senza conservare l'impaginazione Word. Limite testo 100.000 caratteri; modifiche AI fino a 30.000.

Apri carica un documento esistente. Salva versione conserva titolo e testo come nuova versione. Anteprima mostra il testo formattato. Usa in chat allega la bozza corrente alla conversazione. Seleziona Word/PDF/Testo nel formato e premi Esporta per scaricare. Versione sceglie una versione precedente; Recupera questa versione la copia nella bozza, poi Salva versione crea una nuova versione senza distruggere la cronologia.

Nel campo Chiedi una modifica all'AI descrivi il cambiamento e premi Proponi modifica. Puoi controllare e modificare il testo proposto. Applica alla bozza lo trasferisce nella bozza ma non lo salva; premi Salva versione. Scarta proposta la abbandona. Annulla durante l'elaborazione interrompe la richiesta. Elimina nell'elenco cancella documento e versioni dopo conferma. La chiusura con modifiche non salvate richiede conferma; conflitti fra versioni vengono rilevati.

## 7. Assistenti e progetti

Il tuo spazio → Assistenti apre Assistenti personali. Nuovo assistente azzera il modulo. Compila Nome, Modello e Istruzioni; scegli Consenti web e Consenti immagini secondo le funzioni ammesse. Documenti personali aggiunge fino a quattro PDF, DOCX, TXT o MD, massimo 500.000 caratteri complessivi. Rimuovi toglie un documento dall'assistente. Salva assistente conserva e seleziona l'assistente nella chat. Modifica cambia la configurazione; Elimina rimuove l'assistente, non le conversazioni. Selezionalo da Opzioni → Assistente per usarlo; Generale torna alla chat ordinaria. Gli assistenti sono privati finché vengono condivisi.

Il tuo spazio → Progetti organizza conversazioni con istruzioni comuni. Inserisci Nome e Istruzioni per le conversazioni, poi Salva progetto. Modifica cambia nome e istruzioni; Elimina rimuove il progetto e conserva le chat. Assegna una chat con il suo menu → Sposta in un progetto. Il filtro nel menu mostra le chat del progetto. Le istruzioni del progetto e dell'assistente si aggiungono alle impostazioni generali; non installano software né addestrano modelli.

## 8. Immagini: galleria, chat e Studio immagini

Nella chat chiedi «Crea un'immagine di…» con una descrizione concreta. Il server instrada la richiesta al motore immagini; il modello chat può aiutare a preparare il prompt. Per cambiare una foto allegala o usa un'immagine della galleria. Comandi Ruota di 90 gradi, Specchia, Bianco e nero e Ridimensiona a 800x600 usano trasformazioni locali. Modifiche di contenuto o colori usano AI img2img e possono cambiare altri dettagli. In una chat memorizzata «fai il tavolo nero e la piscina azzurra» può riutilizzare l'ultima immagine e la scena della stessa conversazione. Per un ritocco preciso usa una maschera.

Il tuo spazio → Immagini apre la Libreria immagini personale. Clicca una miniatura per ingrandirla. Il cestino piccolo in alto a destra elimina l'immagine dopo conferma. Scarica immagine salva il PNG; Usa in chat allega l'immagine alla bozza; Apri conversazione torna alla chat di origine quando disponibile. L'eliminazione dalla galleria non è un comando per cancellare tutte le chat.

Crea o modifica immagini apre Studio immagini. Descrizione è il prompt; Cosa evitare è il prompt negativo. Larghezza e Altezza vanno da 256 a 2048, multipli di 64: dimensioni maggiori richiedono più memoria. Passaggi regola le iterazioni; CFG l'aderenza alla descrizione; Seed controlla il punto di partenza casuale senza garantire risultati identici fra motori/versioni; Sampler e Scheduler selezionano l'algoritmo e la progressione del rumore. Forza trasformazione, da 0,1 a 1, governa quanto può cambiare l'immagine iniziale.

Carica Immagine di partenza (massimo 5 MB nello Studio) per img2img. Con ComfyUI abilita Modifica soltanto le aree dipinte, regola Dimensione pennello e dipingi sul canvas le zone da cambiare. Cancella maschera azzera la pittura, non elimina la foto. Genera immagine accoda il lavoro; Interrompi lo annulla. Scarica immagine scarica il risultato. Le aree non dipinte vengono conservate rispetto alla foto ridimensionata alle dimensioni scelte; un modello generico non dà la stessa qualità di un modello specializzato in inpainting.

Gli amministratori hanno Impostazioni del motore: Motore sceglie Stable Diffusion locale o ComfyUI locale; Indirizzo ComfyUI deve essere sullo stesso PC, normalmente http://127.0.0.1:8188. Avvia ComfyUI locale avvia il runtime installato. Verifica e carica modelli verifica la connessione e popola checkpoint, sampler e scheduler. Checkpoint ComfyUI e Modello Stable Diffusion scelgono i pesi. Salva impostazioni e parametri conserva motore e valori predefiniti.

Usa workflow importati abilita grafi personalizzati; Tipo workflow distingue Generazione, Trasformazione e Ritocco con maschera. Importa workflow API JSON legge un file massimo 150 KB; Workflow API permette di vederlo/modificarlo. Serve il formato API di ComfyUI, non il JSON del canvas. Variabili ammesse: {{prompt}}, {{negative}}, {{checkpoint}}, {{width}}, {{height}}, {{steps}}, {{cfg}}, {{seed}}, {{strength}}, {{sampler}}, {{scheduler}}, {{image}}, {{mask}}. Sono supportati nodi standard locali come CheckpointLoaderSimple, CLIPTextEncode, KSampler, EmptyLatentImage, VAEEncode, VAEEncodeForInpaint, VAEDecode, LoadImage, ImageToMask, SetLatentNoiseMask e SaveImage; non workflow cloud o nodi arbitrari.

## 9. Voce e dispositivi

Il microfono Registra messaggio vocale registra fino a 60 secondi; premilo di nuovo per terminare. Whisper trascrive sul PC, poi controlla il testo e premi Invia. Annulla interrompe la registrazione. Le risposte vocali vengono lette se l'opzione è attiva; Ferma lettura interrompe la riproduzione. Ascolta su una risposta richiede la sintesi con la voce Windows del server.

L'icona cuffie Avvia conversazione vocale apre una sessione a turni: il browser rileva una pausa di circa 1,4 secondi, invia l'audio per trascrizione, invia il messaggio, riproduce la risposta e torna ad ascoltare. Interrompi e parla ferma la lettura e riapre l'ascolto; Termina conversazione rilascia il microfono. Prima di iniziare invia o rimuovi bozza e allegati. Durante elaborazione/lettura il microfono è disabilitato; il cambio di scheda/app o un errore può terminare la sessione. Su telefoni può essere necessario premere play.

Nome utente → Collega un dispositivo mostra indirizzi e QR code. Scegli la rete se ne compaiono più di una; Copia indirizzo copia la URL. PC e dispositivo devono essere sulla stessa rete, PC acceso, Atlante avviato, rete Windows privata e firewall configurato. Non è necessario aprire porte sul router.

Per il microfono sul PC va bene localhost; sugli altri dispositivi usa HTTPS porta 3212 e installa il certificato pubblico locale tramite la guida /voice/setup. La guida propone i passaggi Android, iOS e Windows. Concedi il permesso microfono al sito. La CA e le chiavi private sono in data/tls sul server; al riavvio il certificato server può aggiornare gli indirizzi mantenendo la CA. Il browser del telefono registra l'audio, ma Whisper e la voce sintetizzata lavorano sul PC server.

## 10. Analisi dati

Il tuo spazio → Analisi dati apre Analisi Excel e CSV. Carica XLSX, CSV o TSV con intestazioni nella prima riga. Foglio seleziona la tabella; Raggruppa per sceglie la categoria; Colonna il valore; Calcolo Somma, Media, Minimo, Massimo o Conteggio. Per conteggiare le righe puoi lasciare la colonna vuota. Filtra colonna, Condizione (Uguale, Contiene, Maggiore di, Minore di) e Valore definiscono un filtro opzionale.

Calcola e mostra grafico esegue aggregazioni sul foglio completo selezionato, non soltanto sugli estratti che vede il modello. Usa nella chat allega il dataset alla conversazione. Nella risposta, Valore del grafico cambia metrica; Scarica grafico esporta il grafico e Esporta risultati in Excel esporta la tabella calcolata. Apri documento modificabile, quando appare su un risultato documentale, apre la bozza nell'editor Documenti. Controlla avvisi su valori non numerici, separatori e righe: una richiesta ambigua può essere interpretata male anche quando il calcolo eseguito è deterministico.

## 11. Condivisioni e utenti

Il tuo spazio → Condivisioni apre Condivisione e collaborazione. I contenuti sono privati fino alla condivisione. Contenuto da condividere seleziona chat, assistente, documento personale o progetto. Per ogni utente/gruppo scegli Nessun accesso, Può leggere o Può modificare, poi Salva accessi. Solo il proprietario gestisce gli accessi. Revoca tutti gli accessi li rimuove. Apri mostra un contenuto proprio o ricevuto; Aggiorna contenuto ricarica l'ultima versione. Non è modifica simultanea in tempo reale.

Con permesso di modifica, Titolo o nome e Testo o istruzioni con Salva modifiche aggiornano il documento/assistente/progetto. Invia nella chat condivisa continua una chat; Interrompi annulla la richiesta. Un progetto condiviso comprende anche le nuove chat assegnate; Nuova conversazione condivisa ne crea una e Apri conversazione apre una chat del progetto. Usa nella mia chat seleziona un assistente condiviso per una propria conversazione. La memoria privata del proprietario non viene aggiunta automaticamente alle risposte condivise. I conflitti di versione richiedono di ricaricare prima di salvare.

Amministrazione → Utenti e permessi apre Utenti. Nuovo utente richiede username e password; Amministratore assegna i privilegi amministrativi, Abilita gestione biblioteca permette l'importazione/gestione condivisa, Account attivo permette l'accesso. Salva utente applica; Annulla abbandona l'editor. In modifica, password vuota conserva quella attuale. Le azioni dell'elenco permettono di modificare o eliminare gli account secondo le conferme mostrate. Ogni account ha cronologia, immagini, documenti e credenziali personali.

Nella sezione Gruppi di Condivisioni, riservata agli admin, Nuovo gruppo prepara il modulo; Nome gruppo e caselle dei membri definiscono il gruppo; Salva gruppo applica. Modifica gruppo cambia membri/nome; Elimina gruppo rimuove gruppo e accessi associati.

## 12. Strumenti esterni, MCP, API e account Google

Il tuo spazio → Strumenti esterni permette a ciascun utente di collegare/scollegare i propri account sulle connessioni ammesse. Usa il comando di collegamento, accedi nel browser del fornitore e autorizza; Scollega revoca il collegamento locale. Le connessioni abilitate sono disponibili nelle chat senza selezionarle a ogni messaggio. Serve un modello Ollama compatibile con strumenti, ad esempio Llama 3.2. La presenza di un connettore non significa che l'account sia già collegato.

Per Google Calendar, Gmail e Google Drive il pacchetto può includere la registrazione dell'applicazione desktop. Ogni utente collega il proprio account Google con consenso personale; non deve procurarsi Client ID o secret. Il primo collegamento desktop va effettuato dal PC Atlante: OAuth PKCE ritorna a un listener HTTP su loopback con porta temporanea. Poi l'account può essere usato dalle chat su altri dispositivi. Calendar può leggere eventi e proporne la creazione con conferma; Gmail/Drive richiedono i rispettivi consensi. Se il progetto Google è in test, l'email deve essere fra gli utenti di prova. Registrazione OAuth/verifica pubblica spettano al distributore; se manca la configurazione nel pacchetto il connettore non è pronto.

Amministrazione → Connessioni esterne configura i servizi. Nuova connessione azzera l'editor; Nome e Tipo scelgono MCP Streamable HTTP o API HTTP; Indirizzo del servizio indica l'endpoint. Header credenziale sceglie Authorization o X-API-Key; Token o API key salva la credenziale; Rimuovi credenziale salvata la cancella. Connessione attiva abilita il servizio; Disponibile per tutti gli utenti include utenti futuri, ciascuno con il proprio account. Definizioni strumenti API contiene gli schemi JSON per un'API HTTP.

Configurazione guidata propone MCP/API personalizzata, Google Calendar o Calendario Microsoft. Importa specifica OpenAPI JSON genera definizioni dalla specifica. Per OAuth personalizzato configura Client ID, eventuale Client secret, metodo di autenticazione client, indirizzo autorizzazione/token e scope. Non confondere la configurazione dell'app del distributore con il login personale.

Salva connessione conserva la configurazione. Verifica e scopri strumenti interroga il servizio; Annulla verifica interrompe la prova. Abilita gli strumenti necessari, assegna utenti e stabilisci quali operazioni richiedono conferma: strumenti nuovi sono disabilitati. Modifica riapre una connessione; Elimina la rimuove. Prima di una scrittura soggetta ad approvazione, Conferma operazione esegue l'azione descritta e Annulla la rifiuta. Se un'operazione comunica un esito incerto, controlla il servizio prima di ripeterla per evitare duplicati. MCP stdio non è incluso.

## 13. Prompt salvati e programmati

Il tuo spazio → Prompt programmati apre Prompt salvati e programmati. Nuovo prompt richiede Titolo, Prompt e Modello. Cerca sul web a ogni esecuzione forza il web per quel prompt; questa casella è distinta dalle opzioni della chat. Quando eseguire offre Solo salvataggio, Ogni giorno, Giorni della settimana o Una volta. Inserisci Ora, giorni o Data secondo la modalità; Programmazione attiva abilita il calendario. Salva prompt conserva; Annulla abbandona l'editor.

Esegui ora accoda una nuova esecuzione; Modifica cambia la definizione; Sospendi/Attiva cambia la programmazione; Elimina rimuove prompt e calendario senza eliminare le chat prodotte. Esecuzioni recenti mostra esiti ed errori; Apri conversazione porta al risultato. Ogni esecuzione produce una conversazione separata con data e fonti.

Gli orari seguono Europe/Rome e l'ora legale. PC acceso, sessione Windows aperta e server attivo sono necessari, anche senza browser. Esecuzioni perse durante spegnimento/sospensione vengono saltate, non recuperate all'avvio; se il server è attivo ma occupato vengono accodate. Ora inesistente in primavera saltata, ora ripetuta in autunno eseguita una sola volta. Non è un servizio che accende il PC né una ricerca autonoma continua.

## 14. Codeg: lavorare sul codice del PC server

Il tuo spazio → Codeg è disponibile agli amministratori. Sessione sceglie una cronologia o Nuova sessione; Cartella del progetto sul server deve essere un percorso assoluto esistente; Modello Ollama sceglie un modello installato. Apri progetto prepara la sessione. Scrivi il lavoro in Richiesta e premi Invia a Codeg. Il modello propone azioni JSON, quindi non è obbligatorio il tool calling nativo. Lettura, elenco e ricerca dei file possono essere automatici.

Operazione da approvare mostra una modifica con testo precedente/proposto o il comando esatto. Approva ed esegui applica quella proposta; Rifiuta la abbandona. Autorizza e non chiedere più in questa sessione memorizza separatamente approvazione per file o comandi; Revoca autorizzazioni automatiche rimuove queste scelte. La cronologia conserva le operazioni. Annulla modifica, quando disponibile su una modifica applicata, ripristina il contenuto precedente soltanto se il file non è cambiato dopo. Interrompi ferma il lavoro e i processi, senza annullare effetti già avvenuti.

Operazioni sui file limitate al progetto: niente traversal, junction o link simbolici; esclusi credenziali, database, .git, dipendenze e dati/modelli di Atlante. File UTF-8 fino a 150 KB, massimo 12 passaggi per richiesta, proposte con scadenza di 30 minuti. I comandi PowerShell hanno limite 120 secondi e output 30.000 caratteri ma girano con i permessi del server, senza sandbox di sistema, e possono agire fuori dal progetto. Non presumere che siano innocui. Questa funzione non fornisce integrazione Git o comandi autonomi senza approvazione/autorizzazione ricordata.

## 15. Modelli AI e configurazione dell'hardware

Amministrazione → Configurazione Atlante riapre la procedura guidata del primo accesso admin. Il tuo PC mostra CPU, RAM, GPU, spazio e componenti. Controlla di nuovo aggiorna il rilevamento. Per Immagini scegli Automatica, Processore o Scheda video e Prepara automaticamente: il sistema installa/configura il runtime necessario e verifica con una prova reale. Interrompi annulla la preparazione. La presenza della GPU non garantisce compatibilità o sufficiente memoria; Automatica può ripiegare su CPU. L'accelerazione può richiedere diversi GB aggiuntivi.

Gestisci modelli apre la schermata unificata. Nella procedura sono disponibili anche selezione Modello, Scarica modello, Esegui prova, Indietro, Cambia modello e Salva e apri la chat. Esegui prova mostra risposta, tempi e accelerazione effettiva; Salva e apri la chat conserva il modello verificato. La X chiude la procedura e si può riaprire più tardi.

Amministrazione → Modelli AI apre Modelli, con chat, visione, immagini e componenti avanzati. Cerca filtra; Mostra seleziona Tutti, Installati o Da aggiornare; Funzione seleziona Chat e visione, Generazione immagini o Componenti avanzati. Aggiorna elenco rilegge disponibilità, non aggiorna tutti i pesi. Mostra altri modelli espande l'elenco. Schede riportano descrizione, dimensioni, eventuali punteggi pubblicati con fonte e stima hardware: non sono una garanzia di velocità o qualità sul tuo PC.

Scarica installa i pesi scelti; Aggiorna scarica la versione disponibile per quel modello; Elimina libera il relativo spazio dopo conferma; Imposta come default sceglie il predefinito del tipo appropriato. Chat e immagini hanno default separati. Versioni e dimensioni mostra varianti; Controlla disponibilità controlla la variante; Annulla interrompe l'operazione. I modelli sono condivisi come software fra utenti, non come cronologia. Non vengono tutti scaricati o sostituiti automaticamente dal catalogo.

Trova altri modelli e novità cerca nei cataloghi: Catalogo Ollama e Aggiungi alla griglia portano un modello di chat nella schermata; Catalogo immagini, Cerca immagini, Ordine e Mostra altri risultati esplorano Hugging Face. Apri scheda/Scheda e aggiornamenti mostra repository e file; scegli File modello, leggi e accetta la licenza e usa Scarica file selezionato. Controlla aggiornamenti dei modelli installati confronta le versioni; Usa modello attiva un checkpoint compatibile dopo prova. Checkpoint completi SD 1.5, SDXL e FLUX.1 possono essere usati secondo supporto del runtime; file di singoli componenti e architetture diverse possono richiedere workflow dedicati.

Avanzate → Accesso al catalogo accetta un Token Hugging Face facoltativo per repository riservati; Salva accesso lo conserva cifrato, Rimuovi accesso lo elimina. Accetta anche le condizioni del modello sul sito del fornitore quando richieste. Lo ZIP di Atlante non contiene tutti i pesi; nessuna spunta rende un modello non installato subito utilizzabile.

## 16. Risposte, voce, account e accesso API

Amministrazione → Risposte e voce regola valori generali per gli utenti. Temperatura 0–2 governa variabilità, non accuratezza; Lunghezza Breve/Standard/Estesa orienta l'estensione; Preset sceglie Equilibrato, Sintetico, Approfondito, Tecnico, Creativo o preset personali. Istruzioni aggiuntive aggiunge indicazioni generali. Nome del nuovo preset e Crea preset dalle istruzioni salvano un preset; Elimina preset personale rimuove un preset creato. Voce sceglie fra voci Windows del server, Automatica cerca l'italiano; Velocità da −10 a 10 e Volume 0–100 regolano la sintesi.

Salva impostazioni applica i valori alle risposte successive senza riavvio. Ascolta voce salvata prova i valori effettivamente salvati. Ripristina valori iniziali prepara i default: salva per applicarli. Assistenti/progetti mantengono istruzioni proprie; i passaggi interni di analisi/ricerca possono usare parametri distinti. Le impostazioni persistono in data/response-settings.json.

Nome utente → Cambia password richiede Password attuale, Nuova password di almeno otto caratteri e Ripeti nuova password. Salva password aggiorna e richiede nuovo login sui dispositivi. Esci chiude la sessione web.

Nome utente → Accesso API permette l'uso da altre applicazioni. Genera token crea una chiave personale; Copia token la copia; Rinnova token sostituisce la chiave invalidando la vecchia; Revoca token la disattiva. Una chiave attiva per utente, senza scadenza automatica; logout non la revoca, cambio password/disabilitazione/eliminazione account sì. I token preesistenti non recuperabili richiedono rinnovo. Sono credenziali private, cifrate per il recupero e conservate anche come hash per autenticazione.

Invia POST /api/chat con Authorization: Bearer IL_TUO_TOKEN e Content-Type: application/json; corpo di esempio {"message":"Come uso la biblioteca di Atlante?","session":"aiuto-atlante","remember":true}. Riusa session per continuare; remember:false evita salvataggio del nuovo scambio; model e assistant sono facoltativi. Il browser normalmente usa cookie di sessione; la gestione dei token richiede login web. Da altri dispositivi preferisci HTTPS con certificato locale. Ripristino/backup rimuovono token API e sessioni: genera nuove chiavi dopo il ripristino.

## 17. Diagnostica, backup, aggiornamenti e disinstallazione

Amministrazione → Diagnostica controlla server, salvataggio e componenti. Ripeti controlli rilegge lo stato; Esegui prove prova modello, voce, OCR e avvio motore immagini, in coda alle altre richieste. Scarica rapporto esporta JSON dello stato senza conversazioni/documenti. Avvia Ollama avvia il servizio locale; Libera memoria scarica dalla RAM/VRAM i modelli attivi; Apri Modelli apre la gestione; Guida voce e HTTPS apre le istruzioni per il certificato; Come risolvere mostra i suggerimenti. Annulla operazione annulla un lavoro. Liberare memoria rende più lento il primo caricamento successivo. Il controllo ordinario immagini non equivale a una generazione completa.

Amministrazione → Backup e manutenzione apre Manutenzione. Scarica backup produce ZIP coerente di account, database, file e certificati, senza modelli. Contiene dati privati e credenziali: conservalo protetto. Per Ripristina backup o Aggiorna Atlante scegli la modalità, carica ZIP (massimo 256 MB), premi Controlla pacchetto e leggi il riepilogo. Conferma e riavvia applica soltanto dopo la verifica. Le richieste in corso devono terminare.

Un aggiornamento usa lo ZIP di distribuzione con manifest/checksum, verifica le dipendenze prima dell'arresto, conserva la versione precedente e tenta il ripristino se la nuova non risponde. La pagina si ricarica dopo il riavvio. Un ripristino sostituisce i dati e richiede le credenziali contenute nel backup; vecchie sessioni sono revocate. Copie di recupero rimangono sotto .maintenance.

Per rimuovere l'app scegli Conserva una copia dei dati fuori dalla cartella di Atlante se desiderato, scrivi DISINSTALLA e premi Disinstalla Atlante. Rimuove app, collegamenti e regola firewall dell'installer; lascia Ollama e componenti di sistema condivisi. Non usarlo per risolvere un semplice modello mancante. Prima di interventi importanti scarica un backup.

## 18. Architettura e software coinvolti

Il browser esegue HTML, CSS e JavaScript di public/: app.js coordina chat/allegati/galleria; sidebar.js il menu; i moduli workspace, collaboration, integrations, models, image-studio, voice, prompts, maintenance e setup gestiscono le relative funzioni. markdown-it formatta il testo, DOMPurify sanifica l'HTML e highlight.js evidenzia il codice. La web manifest e le icone consentono un collegamento web sui dispositivi; il PC server deve comunque restare attivo.

Node.js 24 o superiore esegue src/server.mjs: serve interfaccia e API, autentica, controlla permessi, orchestra le richieste e gestisce artefatti. src/engine.mjs costruisce il contesto e interroga il modello; request-queue serializza i lavori AI alternando utenti e permettendo cancellazione. profiles/auth separano account; store usa node:sqlite con database SQLite, FTS5 e transazioni. knowledge/document-retrieval recuperano e riordinano passaggi; automatic-web/live-web/browser gestiscono fonti Internet. Workspace, collaboration, scheduler, integrations, OAuth, Codeg e maintenance sono moduli server dedicati.

Ollama gestisce download, caricamento e inferenza dei modelli. Llama 3.2 è una scelta iniziale per chat e preparazione di richieste visive; Gemma 3 4B è il modello di visione iniziale; EmbeddingGemma serve alla ricerca semantica. Sono modelli distinti, non funzioni interne dello stesso peso. ATLANTE_OLLAMA_URL può configurare un endpoint Ollama differente dal default locale: in questo caso il testo inviato al modello passa a quel server. Il browser non chiama direttamente Ollama.

Stable Diffusion è la famiglia di modelli immagini. stable-diffusion.cpp fornisce sd-cli.exe, eseguito come processo locale, con file safetensors e backend CPU/GPU supportato. ComfyUI è il motore alternativo basato su Python e PyTorch, con grafo di nodi per generazione, img2img e maschere; il pacchetto portatile può includere Python embedded e runtime CUDA per NVIDIA. La configurazione automatica prova l'accelerazione e sceglie il percorso compatibile. I pesi SD 1.5 di base sono distinti dal programma che li esegue. sharp/libvips elabora PNG/JPEG/WebP e compone le aree non dipinte dei ritocchi.

whisper.cpp e il modello Whisper base trascrivono audio in italiano tramite whisper-cli.exe, normalmente su CPU. Il browser usa MediaRecorder/Web Audio per cattura e rilevamento pausa. PowerShell e System.Speech di Windows sintetizzano la risposta con le voci installate. Tesseract.js usa Tesseract WASM e tessdata_fast italiano/inglese per OCR; PDF.js legge/rende PDF e @napi-rs/canvas permette rendering delle pagine per OCR.

Mammoth estrae testo da DOCX; ExcelJS legge/scrive XLSX e tabelle; docx crea Word; PptxGenJS crea PowerPoint; PDFKit crea PDF; markdown-it/cheerio aiutano a interpretare testo e pagine. adm-zip gestisce archivi; qrcode crea QR; @peculiar/x509 supporta certificati HTTPS locali; ipaddr.js aiuta i controlli degli indirizzi. @modelcontextprotocol/sdk implementa MCP Streamable HTTP; AJV valida schemi degli strumenti; OAuth/OAuth PKCE autorizzano account esterni. npm installa le dipendenze definite in package-lock.json. Playwright è usato nello sviluppo per verifiche browser, non richiesto come motore della chat.

PowerShell, script .cmd/.bat, utilità Windows e supervisore Node gestiscono installazione e avvio. Visual C++ Redistributable e componenti vocali Windows sono requisiti di alcuni runtime. HTTPS usa una CA locale e certificati generati sul PC. DuckDuckGo è il motore pubblico di ricerca; Hugging Face, Ollama e siti ufficiali ospitano cataloghi/download. Google/Microsoft o servizi MCP/API sono esterni: solo le connessioni configurate sono disponibili.

### Comunicazioni fra componenti

Browser → Atlante: HTTP porta 3210 o HTTPS porta 3212; API /api/... scambiano JSON, upload e file. La chat progressiva usa una risposta HTTP in streaming; altri lavori usano un ID e interrogazioni periodiche a /api/jobs/... per stato e risultato. Non presumere collaborazione con aggiornamento simultaneo: si ricarica con Aggiorna contenuto.

Atlante → Ollama: richieste HTTP/JSON al default http://127.0.0.1:11434, inclusi chat in streaming, elenco/dettagli dei modelli, download e embeddings. Ollama usa RAM/VRAM e GPU quando supportata. Atlante può liberare i modelli per lasciare memoria alle immagini. Un endpoint Ollama configurato remoto cambia questa separazione locale.

Atlante → ComfyUI: HTTP locale normalmente 127.0.0.1:8188. Carica la foto con /upload/image, invia il workflow a /prompt, interroga /history per il risultato e scarica l'immagine da /view. Cancellazione tramite coda/interruzione; liberazione memoria a fine lavoro quando possibile. Gli endpoint remoti ComfyUI e redirect sono rifiutati. Atlante → sd-cli, whisper-cli e sintesi Windows: processi locali con argomenti e file temporanei/output; non un'API cloud. Atlante → SQLite: accesso diretto ai file locali, non un server database separato.

Atlante → siti web: richieste HTTP(S) server-side per ricerca e pagine pubbliche, con blocchi per indirizzi privati nel lettore web. Atlante → MCP: protocollo MCP su Streamable HTTP; → API HTTP: chiamate definite dai relativi schemi, con credenziali/permessi. OAuth usa browser del fornitore e scambio token; OAuth desktop PKCE ritorna sul loopback del PC. I token personali sono separati per utente e conservati cifrati quando previsto. Il supervisore locale usa porta 3211 e controlla il server circa ogni 20 secondi.

### Dove sono i dati

data/atlante.sqlite conserva il database principale e biblioteca condivisa; utenti aggiuntivi usano database personali sotto data/users. data/artifacts e le cartelle associate contengono file e immagini; data/image-jobs i log immagini; data/service log e stato del supervisore; data/tls certificati e chiavi. data contiene anche impostazioni, account e credenziali protette dove previsto. Conversazioni/documenti sono in chiaro nel database locale: cifrare token non cifra l'intero archivio. models e runtime contengono pesi/programmi, node_modules le dipendenze. Lo ZIP distribuito include codice, interfaccia, installer e configurazione pubblica necessaria, non database privati, token, certificati personali o tutti i runtime/pesi.

## 19. Installazione e configurazione, passo per passo

1. Prepara Windows 10/11 x64 Intel/AMD, Internet, spazio disco e RAM. Consigliati almeno 16 GB RAM e 20 GB liberi; immagini accelerate almeno 30 GB e possibili download aggiuntivi. CPU funziona ma lentamente. Il pacchetto Windows non è l'installer per Windows ARM64.
2. Scarica atlante.zip dalla pagina del progetto, estrai l'intero ZIP e apri la cartella Atlante. Non eseguire installa.bat dentro l'archivio senza estrarlo. Fai doppio clic su installa.bat.
3. Leggi le condizioni di utilizzo, seleziona accettazione e premi Installa. Rifiuta ed esci, Escape o chiusura annullano prima di download e modifiche di sistema. Le condizioni vengono richieste anche ripetendo l'installer.
4. L'installer verifica manifest e hash del pacchetto, prepara %LOCALAPPDATA%\Atlante, copia codice e configurazione senza cancellare i dati personali di una reinstallazione. Una diversa installazione sulla porta 3210 va arrestata prima.
5. Riutilizza Node.js compatibile o scarica il runtime Node 24 portatile. npm ci installa le dipendenze bloccate; viene verificata la presenza dei moduli necessari. Scarica e verifica la firma dell'installer Ollama se Ollama manca, lo avvia su 127.0.0.1:11434 e installa llama3.2:latest e gemma3:4b se assenti.
6. Installa modelli OCR, whisper.cpp e Whisper base; prepara stable-diffusion.cpp CPU e sd15.safetensors con controlli di integrità. Alcuni download usano hash SHA256, altri firma digitale del fornitore. Sono diversi GB; non spegnere il PC durante il lavoro.
7. Consenti la richiesta Windows per la configurazione di firewall, Visual C++ e voce italiana. La parte che richiede amministratore è separata dall'uso ordinario. L'installer verifica la voce nell'account effettivo e controlla l'avvio del motore immagini.
8. La preparazione automatica immagini rileva l'hardware, configura CPU/GPU e, quando opportuno, prepara ComfyUI portatile e prova il percorso scelto. Non è necessario installare manualmente ComfyUI per il percorso guidato. CPU resta un possibile ripiego. Non dedurre che una GPU rilevata sia stata verificata senza leggere il risultato.
9. Genera HTTPS locale, crea collegamento desktop e avvio automatico nella cartella Startup dell'utente Windows, avvia il supervisore e aspetta la salute del server. Apri Atlante, accedi come admin, cambia password, completa Configurazione Atlante e scegli/prova i modelli.
10. Crea utenti e permessi; attiva eventualmente la ricerca semantica; configura connessioni esterne e fai collegare gli account ai rispettivi utenti. Usa Collega un dispositivo e la guida HTTPS per telefoni. Prova chat, voce, OCR e immagini da Diagnostica. Crea un backup quando la configurazione è pronta.

Se un download si interrompe, esegui di nuovo installa.bat: può riprendere file parziali quando il server lo consente e conserva componenti verificati. Leggi %LOCALAPPDATA%\Atlante\installation.log per errori; runtime contiene log delle prove e data/service/supervisor.log problemi di avvio. In caso di voce assente può servire riavviare Windows e ripetere. Non cancellare data per riparare un download.

L'avvio automatico del pacchetto usa il collegamento Atlante nella cartella aperta con Win+R → shell:startup. Il progetto dispone anche di script install-autostart/remove-autostart per un'attività Windows: è un metodo alternativo, non requisito per tutti gli utenti. Il supervisore riavvia server/Ollama quando necessario. Serve PC acceso e sessione Windows aperta; sospensione o logout interrompono l'operatività, e non vengono cambiate automaticamente le impostazioni energetiche.

Per sviluppo/manuale: Node.js >=24, npm ci, Ollama e i runtime/modelli necessari, poi start.cmd oppure npm start. npm ci da solo non installa tutti i pesi e motori. Gli script setup-ocr.mjs, setup-voice.ps1, setup-comfyui.ps1 e setup-https.mjs nel progetto preparano i componenti corrispondenti; nel pacchetto usa prima la procedura installer e Configurazione Atlante. Le variabili avanzate come ATLANTE_OLLAMA_URL, ATLANTE_GPU e ATLANTE_SD_BACKEND cambiano indirizzo/accelerazione e richiedono conoscere il runtime; evita di copiarne valori hardware da un altro PC senza verifica.

## 20. Assistenza: riconoscere il problema e guidare l'utente

Per rispondere a richieste di aiuto usa questo manuale come fonte dell'applicazione. Indica il percorso del menu, il pulsante preciso, il dato da inserire e il risultato atteso. Distingui utente/admin e PC server/telefono. Non inventare pulsanti, modelli installati, connessioni o risultati di prove; chiedi testo dell'errore, schermata/funzione interessata e dispositivo se mancano elementi. Non chiedere password, token o secret. Per problemi di una dipendenza non documentati consulta la documentazione ufficiale, distinguendola dal comportamento di Atlante. Non promettere lettura completa di file, aggiornamento dei pesi o salvataggio se non è avvenuto.

- Atlante non si apre: controlla PC acceso, collegamento, http://localhost:3210 sul server; poi log supervisore. Se funziona sul PC ma non sul telefono, controlla stessa rete, IP corretto, rete Windows privata/firewall; usa Collega un dispositivo. Non esporre le porte sul router come prima soluzione.
- Ollama non risponde o non ci sono modelli: Diagnostica → Ripeti controlli; avvia Ollama dal comando disponibile, verifica endpoint; Modelli AI → scarica un modello chat e Imposta come default. Se manca il programma, ripeti installer. Se memoria insufficiente, libera modelli/programmi o scegli un modello più leggero.
- Biblioteca/Amministrazione non visibile: verifica account e permessi con l'admin. Per importare cerca Biblioteca condivisa, non Documenti personali. Per contesto della singola chat usa +; per documenti dell'assistente usa il suo editor.
- Documento non risponde bene: controlla anteprima/testo OCR, formato e limiti; specifica domanda e pagine; documenti grandi possono richiedere parti separate. Leggi passaggio mostra cosa è stato recuperato. Attiva ricerca semantica o Aggiorna indice; il modello non legge sempre tutto né apprende automaticamente dai file.
- Risposta senza fonti adeguate o web indisponibile: verifica connessione e permesso web; distingui snippet da pagina; prova URL pubblica. Per solo locale chiedi senza Internet. Per una domanda su Atlante usa questa guida e non assumere che un sito di un prodotto omonimo descriva questa app.
- Microfono non disponibile: consenti permesso nel browser, usa localhost sul PC o HTTPS/certificato sul telefono; verifica che non sia in uso da altra app. Trascrizione assente: Diagnostica → prove voce, verifica Whisper/modello. Lettura assente: controlla opzione lettura, volume, voce salvata e Ascolta voce salvata.
- Immagini non generate: verifica modello scaricato e default immagini; Configurazione Atlante → Prepara automaticamente; nello Studio verifica motore/connessione/checkpoint. Riduci dimensioni e controlla RAM/VRAM. Per maschera serve ComfyUI, foto caricata e area dipinta. Per preservare dettagli usa maschera, non una generica modifica img2img.
- Connessione esterna rifiutata: verifica che servizio/strumenti siano abilitati e utente autorizzato, account collegato, modello compatibile. OAuth Google in test richiede email autorizzata dal distributore. Un esito incerto dopo una scrittura richiede controllo sul servizio prima di riprovare.
- Prompt non partito: controlla Programmazione attiva, orario Europe/Rome e PC/server accesi; leggi Esecuzioni recenti. Esecuzioni perse non vengono recuperate. Modello eliminato o web non disponibile può causare errore.
- Bozza/proposta AI non salvata: Applica alla bozza non è Salva versione; salva prima di uscire. Per conflitto ricarica contenuto e verifica le modifiche. Per aggiornamenti/ripristino prima controlla pacchetto e attendi fine richieste.
- Codeg non modifica: controlla percorso assoluto sul server, modello e proposta in attesa; approva consapevolmente. I percorsi protetti o file fuori progetto sono rifiutati; non aggirare il controllo copiando credenziali nel progetto.

Per un intervento che potrebbe modificare o sostituire dati, usa prima Backup e manutenzione → Scarica backup. Per la diagnosi preferisci il rapporto di Diagnostica e messaggi d'errore senza contenuti privati. La guida descrive funzioni disponibili, non prova lo stato corrente della macchina: quando necessario fai eseguire il controllo corrispondente all'utente.
