$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'prerequisites.ps1')
if (!(Test-AtlanteItalianVoice)) { exit 1 }
