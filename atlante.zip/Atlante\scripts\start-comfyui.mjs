import {spawn} from 'node:child_process';
import {existsSync,mkdirSync,openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url)),portable=join(root,'runtime/comfyui/ComfyUI_windows_portable'),python=join(portable,'python_embeded/python.exe'),logs=join(root,'data/comfyui');
if(!existsSync(python))throw Error('Installa ComfyUI con scripts/setup-comfyui.ps1');
try{const r=await fetch('http://127.0.0.1:8188/system_stats',{signal:AbortSignal.timeout(2000)});if(r.ok){console.log('ComfyUI già attivo');process.exit(0);}}catch{}
try{const state=JSON.parse(readFileSync(join(logs,'process.json'),'utf8'));process.kill(state.pid,0);console.log('ComfyUI già avviato, inizializzazione in corso');process.exit(0);}catch{}
mkdirSync(logs,{recursive:true});const out=openSync(join(logs,'stdout.log'),'a'),err=openSync(join(logs,'stderr.log'),'a');
const child=spawn(python,['-s','ComfyUI/main.py','--windows-standalone-build','--listen','127.0.0.1','--port','8188','--lowvram','--disable-dynamic-vram','--disable-api-nodes','--disable-all-custom-nodes','--disable-auto-launch'],{cwd:portable,env:{...process.env,HF_HUB_OFFLINE:'1',TRANSFORMERS_OFFLINE:'1',HF_HUB_DISABLE_TELEMETRY:'1'},windowsHide:true,detached:true,stdio:['ignore',out,err]});
await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject);});writeFileSync(join(logs,'process.json'),JSON.stringify({pid:child.pid,started:new Date().toISOString()}));child.unref();closeSync(out);closeSync(err);console.log('ComfyUI avviato, PID '+child.pid+' · http://127.0.0.1:8188');
