const md=window.markdownit({html:false,linkify:true,breaks:true,highlight(code,language){if(language&&window.hljs.getLanguage(language))return window.hljs.highlight(code,{language}).value;return '';}});
export function renderMessage(element,text){
 element.dataset.raw=text;let content=element.querySelector(':scope > .message-content');if(!content){content=document.createElement('div');content.className='message-content';element.prepend(content);}
 content.innerHTML=window.DOMPurify.sanitize(md.render(text),{FORBID_TAGS:['img','iframe','style','script','form','input','button'],FORBID_ATTR:['style']});
 for(const link of content.querySelectorAll('a')){link.target='_blank';link.rel='noopener noreferrer';}
 for(const pre of content.querySelectorAll('pre')){const copy=document.createElement('button');copy.type='button';copy.className='code-copy';copy.textContent='Copia codice';copy.onclick=async()=>{try{await navigator.clipboard.writeText(pre.querySelector('code').textContent);copy.textContent='Copiato';}catch{copy.textContent='Seleziona il codice per copiarlo';}};pre.prepend(copy);}
}
export async function queuedChat(input,{onState,onDelta,onJob}={}){
 const response=await fetch('/api/jobs/submit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(input)}),data=await response.json();if(!response.ok)throw Error(data.error);onJob?.(data.id);
 const stream=await fetch('/api/jobs/'+data.id+'/events');if(!stream.ok){const error=await stream.json();throw Error(error.error);}
 let pending='',result=null,failure=null;const decoder=new TextDecoder();
 function event(block){const line=block.split('\n').find(s=>s.startsWith('data: '));if(!line)return;const item=JSON.parse(line.slice(6));if(item.kind==='state')onState?.(item);if(item.kind==='delta')onDelta?.(item.text);if(item.kind==='done')result=item.result;if(item.kind==='error'||item.kind==='cancelled')failure=Object.assign(Error(item.error||'Richiesta interrotta'),{cancelled:item.kind==='cancelled',partial:item.text});}
 for await(const chunk of stream.body){pending+=decoder.decode(chunk,{stream:true});let index;while((index=pending.indexOf('\n\n'))>=0){event(pending.slice(0,index));pending=pending.slice(index+2);}}
 if(failure)throw failure;if(!result)throw Error('Connessione interrotta. La richiesta potrebbe essere ancora in corso: riapri la conversazione.');return result;
}
export function messageActionBar(element){let actions=element.querySelector(':scope > .message-actions');if(!actions){actions=document.createElement('div');actions.className='message-actions';actions.setAttribute('role','group');actions.setAttribute('aria-label','Azioni del messaggio');element.append(actions);}return actions;}
export function messageActions(element,{id,role,session,onEdit}){
 if(!id)return;const actions=messageActionBar(element);
 const action=document.createElement('button');action.type='button';action.textContent=role==='user'?'Modifica':'Rigenera';action.title='Crea una nuova versione conservando la conversazione originale';action.onclick=()=>{let text;if(role==='user'){text=prompt('Modifica il messaggio. Verrà creata una nuova versione della conversazione.',element.dataset.raw);if(!text?.trim())return;}onEdit({session,edit:{id,text,regenerate:role==='assistant'}});};actions.append(action);
}
export function renderSources(element,sources){
 const cited=new Set([...element.textContent.matchAll(/\[(\d+)\]/g)].map(m=>Number(m[1])));sources=(sources||[]).map((s,i)=>({...s,citationIndex:s.citationIndex||i+1})).filter(s=>s.kind!=='memory'&&cited.has(s.citationIndex));if(!sources.length)return;const box=document.createElement('div');box.className='sources';for(const [index,source]of sources.entries()){const row=document.createElement('div');row.textContent=`[${source.citationIndex}] ${source.title}${source.page?' · pagina '+source.page:''}`;if(['document','attachment'].includes(source.kind)&&source.id){const button=document.createElement('button');button.type='button';button.textContent='Leggi passaggio';button.onclick=()=>{const dialog=document.getElementById('document-dialog');document.getElementById('document-title').textContent=source.title+(source.page?' · pagina '+source.page:'');document.getElementById('document-content').textContent=source.body||'Passaggio non disponibile';dialog.showModal();};row.append(' ',button);}else if(/^https?:\/\//.test(source.url)){const link=document.createElement('a');link.href=source.url;link.textContent=' Apri fonte';link.target='_blank';link.rel='noopener noreferrer';row.append(link);}box.append(row);}element.append(box);
}
