import {createServer} from 'node:http';
export async function startDesktopOAuth(accounts,id,user,origin,sessionToken){
 const home=new URL(origin);if(!['localhost','127.0.0.1','[::1]'].includes(home.hostname))throw Error('Collega Google dal browser sul PC dove è installato Atlante, poi usa il calendario anche dagli altri dispositivi.');
 if(!sessionToken)throw Error('Accedi alla pagina web per collegare Google');
 let flow,timer;const close=()=>{clearTimeout(timer);server.close();};
 const server=createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('Referrer-Policy','no-referrer');
  const address=new URL(req.url,'http://127.0.0.1');
  if(req.method!=='GET'||address.pathname!=='/'||address.searchParams.get('state')!==flow?.state){res.writeHead(400);res.end('Richiesta non valida');return;}
  let ok=false,error='callback_failed';try{await accounts.callback(flow.state,address.searchParams.get('code'),flow.nonce);ok=true;}catch(e){error=e.oauthCode||'callback_failed';}
  res.writeHead(303,{Location:origin+'/?account='+(ok?'connected':'failed&accountError='+encodeURIComponent(error))});res.end();close();
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});server.unref();
 try{const redirect='http://127.0.0.1:'+server.address().port+'/';flow=accounts.start(id,user,origin,sessionToken,redirect);flow.state=new URL(flow.url).searchParams.get('state');accounts.pending.get(flow.state).close=close;timer=setTimeout(()=>{accounts.pending.delete(flow.state);close();},600000);timer.unref();return flow;}catch(e){close();throw e;}
}
