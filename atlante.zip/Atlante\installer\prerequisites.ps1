function Test-AtlanteNode([string]$Executable) {
    if (!$Executable -or !(Test-Path -LiteralPath $Executable -PathType Leaf)) { return $false }
    $npm = Join-Path (Split-Path -Parent $Executable) 'node_modules\npm\bin\npm-cli.js'
    if (!(Test-Path -LiteralPath $npm -PathType Leaf)) { return $false }
    try {
        $info = & $Executable -p 'JSON.stringify({version:process.versions.node,arch:process.arch})' 2>$null
        if ($LASTEXITCODE -ne 0) { return $false }
        $info = $info | ConvertFrom-Json
        return $info.arch -eq 'x64' -and [version]$info.version -ge [version]'24.0.0'
    } catch { return $false }
}

function Find-AtlanteNode([string]$Root) {
    $candidates = @()
    $saved = Join-Path $Root 'runtime\install.json'
    if (Test-Path -LiteralPath $saved) {
        try { $candidates += (Get-Content -LiteralPath $saved -Raw | ConvertFrom-Json).nodePath } catch {}
    }
    $candidates += @(Get-Command node.exe -All -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source)
    foreach ($key in @('HKCU:\SOFTWARE\Node.js','HKLM:\SOFTWARE\Node.js')) {
        $installation = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($installation.InstallPath) { $candidates += Join-Path $installation.InstallPath 'node.exe' }
    }
    foreach ($directory in @($env:ProgramFiles,$env:LOCALAPPDATA)) {
        if ($directory) { $candidates += Join-Path $directory 'nodejs\node.exe' }
    }
    $candidates += @(Get-ChildItem -LiteralPath (Join-Path $Root 'runtime') -Directory -Filter 'node-*-win-x64' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | ForEach-Object { Join-Path $_.FullName 'node.exe' })
    foreach ($candidate in @($candidates | Where-Object { $_ } | Select-Object -Unique)) {
        if (Test-AtlanteNode $candidate) { return $candidate }
    }
    return $null
}

function Test-AtlanteVisualCpp {
    $runtime = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' -ErrorAction SilentlyContinue
    try { return $runtime.Installed -eq 1 -and [version]$runtime.Version.TrimStart('v') -ge [version]'14.42.0' } catch { return $false }
}

function Test-AtlanteItalianVoice {
    Add-Type -AssemblyName System.Speech
    $speech = New-Object System.Speech.Synthesis.SpeechSynthesizer
    try { return [bool]($speech.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -like 'it-*' }) }
    finally { $speech.Dispose() }
}
