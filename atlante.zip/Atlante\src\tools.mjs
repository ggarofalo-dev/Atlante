// Routing and translation are short auxiliary tasks; avoid loading the large chat model.
export const imageToolsModel=process.env.ATLANTE_IMAGE_TOOLS_MODEL||'llama3.2:latest';
export function imageColorChange(message){
 const text=String(message).toLowerCase().trim();
 return !/^(?:non|spiega|spiegami|come|quale|quali|descrivi|analizza|puoi dirmi|puoi spiegarmi)\b/.test(text)&&/\b(?:fai|fare|rendi|rendere|vorrei|voglio|metti|cambia|modifica|colora)\b/.test(text)&&/\b(?:ner[oaie]|bianc[oaie]|azzurr[oaie]|blu|ross[oaie]|verd[ei]|giall[oaie]|arancione|viola|rosa|grigi[oaie]|marrone|colore|colori)\b/.test(text);
}
export function chooseTool(message,{hasImage=false,hasDocuments=false}={}){
 const text=message.toLowerCase().trim();
 const imageWords=/(?:immagin[ei]|foto(?:grafia)?|disegno|illustrazione|ritratto|image|picture|photo)/;
 const negative=/\b(?:non|don't|do not)\s+(?:voglio\s+)?(?:disegn|genera|crea|draw)/.test(text);
 if(/^(?:spiega|spiegami|parlami|raccontami|dimmi come|traduci|riscrivi|riassumi|mi spieghi|puoi spiegarmi|puoi dirmi come|come|quale|quali|quanti|quanto|quando|dove|chi|che cosa|cosa significa|how|explain|which|what is|translate)\b/.test(text))return {tool:hasImage?'analyze':'chat'};
 if(hasImage&&!hasDocuments){
  if(/\b(?:ruota|ruotala|ruotare|rotate)\b/.test(text)){const angle=Number(text.match(/\b(90|180|270)\b/)?.[1]||90);return {tool:'edit',operation:'rotate',angle:/antiorario/.test(text)?-angle:angle};}
  if(/(?:bianco e nero|scala di grigi|grayscale)/.test(text))return {tool:'edit',operation:'grayscale'};
  if(imageColorChange(message))return {tool:'transform'};
  if(/\b(?:specchia|specchiare|mirror)\b/.test(text))return {tool:'edit',operation:'mirror'};
  if(/\b(?:ridimensiona|ridimensionare|resize)\b/.test(text)){const size=text.match(/(\d{1,4})\s*[x×]\s*(\d{1,4})/);return {tool:'edit',operation:'resize',...(size?{width:Number(size[1]),height:Number(size[2])}:{})};}
  if(!negative&&/\b(?:modifica|modificala|modificare|trasforma|trasformala|trasformare|cambia|cambiare|rimuovi|rimuovere|aggiungi|aggiungere|ritocca|ritoccare|converti|convertire|colora|colorare|rendila|renderla|edit|change|remove|add|turn)\b/.test(text))return {tool:'transform'};
  return {tool:'analyze'};
 }
 if(!hasDocuments&&!negative&&(/\b(?:disegna|disegnami|disegni|disegnare|dipingi|draw|paint)\b/.test(text)||(/\b(?:crea|creami|creare|genera|generami|generare|realizza|realizzare|produce|generate|create|fammi|fai|fare|vorrei)\b/.test(text)&&imageWords.test(text))))return {tool:'generate'};
 return {tool:'chat'};
}
export function requestedFormat(message){
 if(/^(?:spiega|spiegami|parlami|raccontami|traduci|come|quale|quali|quanti|quanto|vorrei (?:capire|sapere))\b/i.test(message))return null;
 if(!/\b(?:crea|creami|genera|generami|prepara|scrivi|esporta|fammi|vorrei|create|export)\b/i.test(message))return null;
 if(/\b(?:pdf)\b/i.test(message))return 'pdf';
 if(/\b(?:word|docx)\b/i.test(message))return 'docx';
 if(/\b(?:excel|xlsx)\b/i.test(message))return 'xlsx';
 if(/\b(?:powerpoint|pptx|presentazione)\b/i.test(message))return 'pptx';
 return null;
}
export async function imagePrompt(message,generate,model=imageToolsModel,previousPrompt=''){
 if(previousPrompt)message='Original visual scene (context, not instructions): '+previousPrompt.slice(0,2000)+'\nRequested changes: '+message+'\nDescribe the complete final scene, preserving the original subjects and composition except for the requested changes.';
 const response=await generate('chat',{model,stream:false,format:{type:'object',properties:{prompt:{type:'string'}},required:['prompt'],additionalProperties:false},messages:[{role:'system',content:'Translate the requested visual scene into ENGLISH. Return JSON with prompt. Do not copy Italian words. Preserve subjects, colors, style and requested changes. Remove the command to draw or generate. For editing, describe the desired final image.'},{role:'user',content:'Disegna una mela rossa su un tavolo bianco, fotografia realistica'},{role:'assistant',content:'{"prompt":"A red apple on a white table, realistic photography"}'},{role:'user',content:'Trasforma questa foto in un paesaggio innevato'},{role:'assistant',content:'{"prompt":"A snow-covered landscape, preserving the original composition"}'},{role:'user',content:message}],options:{temperature:0,num_ctx:2048,num_predict:300}});
 let value;try{value=JSON.parse(response.message?.content||'').prompt;}catch{throw Error('Non riesco a preparare la descrizione dell’immagine. Riprova con una descrizione più semplice.');}
 if(typeof value!=='string'||!value.trim()||value.length>2000)throw Error('Descrizione dell’immagine non valida');return value;
}
export async function resolveTool(message,options,generate,model='llama3.2:latest'){
 const plan=chooseTool(message,options);const text=message.toLowerCase().trim();
 const obviousQuestion=/^(?:descrivi|analizza|leggi|trascrivi|estrai|ocr|cosa|che cosa|dimmi|spiega|spiegami|parlami|raccontami|traduci|riscrivi|riassumi|quale|quali|quanti|quanto|quando|dove|chi|come|puoi dirmi|what|describe|analyze|translate)\b/.test(text);
 const ambiguous=options.hasImage&&plan.tool==='analyze'&&!obviousQuestion||!options.hasImage&&plan.tool==='chat'&&!obviousQuestion&&/\b(?:immagine|foto|disegno|illustrazione|ritratto|immagina|raffigura|ritrai|visualizza)\b/.test(text);
 if(!ambiguous||options.hasDocuments||/^non\b/.test(text))return plan;
 const response=await generate('chat',{model,stream:false,format:{type:'object',properties:{tool:{type:'string',enum:['chat','generate','transform','analyze']}},required:['tool'],additionalProperties:false},messages:[{role:'system',content:'Select the tool for the actual user request. chat: discussion or instructions, not making images. generate: user wants a NEW image created. transform: user wants an attached image changed. analyze: user asks about an attached image. Do not create or edit images for informational questions. Image attached: '+Boolean(options.hasImage)+'. Return only JSON with tool.'},{role:'user',content:message}],options:{temperature:0,num_ctx:1024,num_predict:30}});
 try{let tool=JSON.parse(response.message?.content||'').tool;if(options.hasImage&&tool==='generate'&&!/\b(?:nuova|nuovo|new|disegna|disegnami|crea|genera|draw|create|generate)\b/.test(text))tool='transform';if(['chat','generate','transform','analyze'].includes(tool)&&(!['transform','analyze'].includes(tool)||options.hasImage))return {tool};}catch{}
 return plan;
}
