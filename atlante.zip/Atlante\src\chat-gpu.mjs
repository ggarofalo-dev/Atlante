export function chatGpuOptions(gpu){
 if(gpu!==undefined&&typeof gpu!=='boolean')throw Error('Opzione GPU non valida');
 return {num_gpu:gpu===false||(gpu===undefined&&process.env.ATLANTE_GPU==='0')?0:999};
}
export function withChatGpu(path,body,gpu){
 if(!['chat','generate'].includes(path)||!body)return body;
 return {...body,options:{...body.options,...chatGpuOptions(gpu)}};
}
