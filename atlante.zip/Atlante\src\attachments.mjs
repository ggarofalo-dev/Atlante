import {readPdf} from './pdf-text.mjs';
import {readImageText} from './ocr.mjs';
﻿import mammoth from 'mammoth';
import ExcelJS from 'exceljs';
export async function readAttachment({name,data}){
 if(typeof name!=='string'||name.length>200||typeof data!=='string'||data.length>14000000)throw Error('Allegato non valido (massimo 10 MB)');
 const bytes=Buffer.from(data.replace(/^data:[^,]*,/,'') ,'base64');if(bytes.length>10000000)throw Error('Allegato troppo grande');
 const extension=name.split('.').pop().toLowerCase();let text='',truncated=false,ocrPages=0,confidence=null,warnings=[];
 if(['txt','md','json','jsonl','csv','tsv'].includes(extension))text=bytes.toString('utf8');
 else if(extension==='docx'){const result=await mammoth.extractRawText({buffer:bytes});text=result.value;}
 else if(extension==='xlsx'){const book=new ExcelJS.Workbook();await book.xlsx.load(bytes);for(const sheet of book.worksheets){text+='\nFoglio: '+sheet.name+'\n';sheet.eachRow(row=>{if(text.length<1000000)text+=row.values.slice(1).map(v=>typeof v==='object'&&v!==null?(v.text??v.result??v.richText?.map(r=>r.text).join('')??''):v??'').join('\t')+'\n';});}}
 else if(extension==='pdf'){const result=await readPdf(bytes);({text,truncated,ocrPages,warnings}=result);}
 else if(['png','jpg','jpeg','webp'].includes(extension)){const result=await readImageText(bytes);text=result.text;confidence=result.confidence;ocrPages=1;if(confidence<70)warnings.push('OCR con bassa confidenza: verifica il testo riconosciuto, soprattutto numeri e nomi.');}
 else throw Error('Formato non supportato. Usa PDF, DOCX, XLSX, immagini PNG/JPG/WebP, TXT, MD, CSV, TSV, JSON o JSONL.');
 if(!text.trim())throw Error('Nessun testo leggibile, anche con OCR. Prova una scansione più nitida e orientata correttamente.');
 return {name,text:text.slice(0,1000000),kind:'document',truncated:truncated||text.length>1000000,ocr:ocrPages>0,ocrPages,confidence,warnings};
}

