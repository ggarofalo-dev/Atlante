$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object {
    @{name=$_.Name;memoryBytes=[double]$_.AdapterRAM;memorySource='Windows estimate'}
})
$voice = $false
try {
    Add-Type -AssemblyName System.Speech
    $speech = New-Object System.Speech.Synthesis.SpeechSynthesizer
    $voice = [bool]($speech.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -like 'it-*' })
    $speech.Dispose()
} catch {}
@{gpus=$gpus;italianVoice=$voice} | ConvertTo-Json -Depth 4 -Compress
