const $=id=>document.getElementById(id);
const paths={chat:'M4 4h16v12H9l-5 4V4Z',document:'M6 3h9l4 4v14H6V3Zm8 0v5h5M9 12h7m-7 4h7',image:'M3 4h18v16H3V4Zm0 12 5-5 5 5 3-3 5 5M15 8h.01',assistant:'M5 8h14v12H5V8Zm7-5v5M8 12h.01m8 0h.01M9 16h6',share:'M8 12l8-6M8 12l8 6M5 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6ZM19 3a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm0 12a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z',data:'M4 20V10m8 10V4m8 16v-7M2 20h20',code:'m8 6-6 6 6 6m8-12 6 6-6 6m-3-15-2 18',clock:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 4v5l4 2',settings:'M4 6h16M4 12h16M4 18h16M8 3v6m8 0v6m-6 0v6',users:'M8 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM2 21v-3a6 6 0 0 1 12 0v3m2-17a4 4 0 0 1 0 8m2 3a5 5 0 0 1 4 5v1',link:'m10 14 4-4M9 16l-2 2a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0m2 8a4 4 0 0 0 6 0l4-4a4 4 0 0 0-6-6l-2 2',device:'M7 2h10v20H7V2Zm0 15h10m-5 2h.01',book:'M3 4h7l2 2 2-2h7v16h-7l-2 2-2-2H3V4Zm9 2v16'};
function icon(name){const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-width','1.6');svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');const p=document.createElementNS(svg.namespaceURI,'path');p.setAttribute('d',paths[name]||paths.settings);svg.append(p);return svg;}
function item(id,label,glyph,description,target){const node=$(id);if(!node)return;node.classList.add('sidebar-nav-item');node.textContent='';const text=document.createElement('span');text.textContent=label;node.append(icon(glyph),text);node.title=description;$(target).append(node);}
const personal=[['notes-open','Documenti','document','Scrivi, modifica ed esporta i tuoi documenti'],['gallery-open','Immagini','image','Rivedi e riusa le immagini salvate'],['assistants-open','Assistenti','assistant','Crea assistenti con istruzioni e documenti propri'],['external-tools-open','Strumenti esterni','link','Collega i tuoi account per tutte le chat'],['data-open','Analisi dati','data','Analizza tabelle Excel e CSV'],['sharing-open','Condivisioni','share','Contenuti condivisi con utenti e gruppi'],['prompts-open','Prompt programmati','clock','Salva prompt ed eseguili a un orario scelto'],['codeg-open','Codeg','code','Lavora sui file di un progetto e verifica le modifiche']];
item('projects-open','Progetti','book','Crea e gestisci progetti per organizzare le conversazioni','sidebar-workspace-links');
for(const row of personal)item(...row,'sidebar-workspace-links');
const library=$('library-section');if(!library.hidden){
 const content=document.createElement('section');content.id='library-section';
 for(const child of [...library.children])if(child.tagName!=='SUMMARY')content.append(child);
 library.replaceWith(content);
 const dialog=document.createElement('dialog');dialog.id='library-dialog';dialog.className='workspace-dialog';dialog.setAttribute('aria-labelledby','library-title');
 dialog.innerHTML='<div class="setup-heading"><h2 id="library-title">Biblioteca condivisa</h2><button type="button" data-close>Chiudi</button></div>';
 dialog.querySelector('[data-close]').onclick=()=>dialog.close();dialog.append(content);
 const status=document.createElement('p');status.id='library-status';status.setAttribute('role','status');content.querySelector('#import').after(status);
 document.body.append(dialog);
 const open=document.createElement('button');open.id='library-open';open.type='button';open.setAttribute('aria-haspopup','dialog');open.setAttribute('aria-controls','library-dialog');
 open.onclick=()=>{dialog.showModal();dialog.scrollTop=0;};$('sidebar-workspace-links').append(open);
 item('library-open','Biblioteca condivisa','book','Importa e gestisci la conoscenza condivisa','sidebar-workspace-links');
}
const admin=[['response-settings-open','Risposte e voce','settings','Regola temperatura, stile, preset e voce del parlato'],['models-open','Modelli AI','assistant','Scarica modelli e scegli il predefinito'],['integrations-open','Connessioni esterne','link','Collega API, server MCP e account esterni'],['users-open','Utenti e permessi','users','Gestisci gli account che accedono ad Atlante'],['diagnostics-open','Diagnostica','data','Controlla lo stato dei componenti'],['setup-open','Configurazione Atlante','settings','Configura i componenti di Atlante'],['maintenance-open','Backup e manutenzione','settings','Backup, ripristino e aggiornamenti']];
for(const row of admin)item(...row,'sidebar-admin-links');$('sidebar-admin').hidden=!window.atlanteUser?.admin;

const accordion=[...$('sidebar-scroll').children].filter(node=>node.matches('details.sidebar-disclosure'));
for(const section of accordion)section.addEventListener('toggle',()=>{if(section.open)for(const other of accordion)if(other!==section)other.open=false;});
$('sidebar').addEventListener('click',event=>{if(event.target.closest('.sidebar-nav-item')&&document.body.classList.contains('sidebar-open'))$('sidebar-close').click();},true);
item('device-open','Collega un dispositivo','device','Apri Atlante su un telefono o altro dispositivo','account-dropdown');$('device-open').setAttribute('role','menuitem');
const organization=$('conversation-search')?.parentElement;if(organization){
 $('new').after($('conversations-import'));const exportLink=organization.querySelector('a');exportLink.setAttribute('role','menuitem');$('account-dropdown').append(exportLink);organization.querySelector('.organization-actions').hidden=true;
 $('conversation-search').placeholder='Cerca una conversazione…';
}
const resizer=document.createElement('div');resizer.id='sidebar-resizer';resizer.tabIndex=0;resizer.setAttribute('role','separator');resizer.setAttribute('aria-orientation','vertical');resizer.setAttribute('aria-label','Larghezza del menu laterale');resizer.setAttribute('aria-controls','sidebar');resizer.title='Trascina per ridimensionare · doppio clic per ripristinare';$('sidebar').append(resizer);
const desktop=matchMedia('(min-width:761px)'),defaultWidth=432,minWidth=240;
let preferredWidth=defaultWidth,dragging=null;
try{const saved=Number(localStorage.getItem('atlante-sidebar-width'));if(Number.isFinite(saved)&&saved!==288&&saved>=minWidth&&saved<=480)preferredWidth=saved;}catch{}
function maximumWidth(){return Math.max(minWidth,Math.min(480,innerWidth-420));}
function applyWidth(){const value=Math.round(Math.max(minWidth,Math.min(maximumWidth(),preferredWidth)));document.documentElement.style.setProperty('--sidebar-width',value+'px');resizer.setAttribute('aria-valuemin',String(minWidth));resizer.setAttribute('aria-valuemax',String(maximumWidth()));resizer.setAttribute('aria-valuenow',String(value));resizer.setAttribute('aria-valuetext',value+' pixel');return value;}
function saveWidth(){try{localStorage.setItem('atlante-sidebar-width',String(preferredWidth));}catch{}}
function setWidth(value){preferredWidth=Math.round(Math.max(minWidth,Math.min(maximumWidth(),value)));applyWidth();saveWidth();}
resizer.onpointerdown=event=>{if(!desktop.matches||event.button!==0)return;event.preventDefault();dragging={id:event.pointerId,start:event.clientX,width:applyWidth()};resizer.setPointerCapture(event.pointerId);document.body.classList.add('sidebar-resizing');};
resizer.onpointermove=event=>{if(!dragging||event.pointerId!==dragging.id)return;setWidth(dragging.width+event.clientX-dragging.start);};
function endDrag(){dragging=null;document.body.classList.remove('sidebar-resizing');}
resizer.onpointerup=resizer.onpointercancel=resizer.onlostpointercapture=endDrag;window.addEventListener('blur',endDrag);
resizer.ondblclick=()=>setWidth(defaultWidth);
resizer.onkeydown=event=>{if(!desktop.matches)return;const step=event.shiftKey?25:10;let value;if(event.key==='ArrowLeft')value=applyWidth()-step;else if(event.key==='ArrowRight')value=applyWidth()+step;else if(event.key==='Home')value=minWidth;else if(event.key==='End')value=maximumWidth();else if(event.key==='Enter')value=defaultWidth;else return;event.preventDefault();setWidth(value);};
window.addEventListener('resize',()=>{if(!desktop.matches)endDrag();applyWidth();});applyWidth();

const accountToggle=$('account-toggle'),accountDropdown=$('account-dropdown');
accountToggle.setAttribute('popovertarget','account-dropdown');
function closeAccount(){if(accountDropdown.matches(':popover-open'))accountDropdown.hidePopover();}
accountToggle.onclick=()=>{if(accountDropdown.matches(':popover-open'))return;const r=accountToggle.getBoundingClientRect();accountDropdown.style.width=Math.min(innerWidth-16,Math.max(220,r.width))+'px';accountDropdown.style.left=Math.max(8,Math.min(r.left,innerWidth-parseFloat(accountDropdown.style.width)-8))+'px';accountDropdown.style.bottom=(innerHeight-r.top+8)+'px';accountDropdown.style.maxHeight=Math.max(100,r.top-16)+'px';};
accountDropdown.addEventListener('toggle',()=>{const open=accountDropdown.matches(':popover-open');accountToggle.setAttribute('aria-expanded',String(open));if(open&&document.activeElement===accountToggle)accountDropdown.querySelector('[role=menuitem]').focus();});
accountDropdown.addEventListener('click',e=>{if(e.target.closest('[role=menuitem]'))closeAccount();});
accountDropdown.addEventListener('keydown',e=>{const items=[...accountDropdown.querySelectorAll('[role=menuitem]')].filter(e=>!e.disabled);let i=items.indexOf(document.activeElement);if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closeAccount();accountToggle.focus();return;}if(e.key==='Tab'){closeAccount();accountToggle.focus();return;}if(e.key==='ArrowDown')i=(i+1)%items.length;else if(e.key==='ArrowUp')i=(i+items.length-1)%items.length;else if(e.key==='Home')i=0;else if(e.key==='End')i=items.length-1;else return;e.preventDefault();items[i].focus();});
$('sidebar-close').addEventListener('click',closeAccount);$('sidebar-overlay').addEventListener('click',closeAccount);window.addEventListener('resize',closeAccount);$('sidebar-scroll').addEventListener('scroll',closeAccount);

accountToggle.addEventListener('keydown',e=>{if(!['ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();if(!accountDropdown.matches(':popover-open'))accountToggle.click();if(e.key==='ArrowUp')accountDropdown.querySelector('[role=menuitem]:last-child').focus();});
