import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {mkdir,mkdtemp,readFile,writeFile,rm,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {createRequire} from 'node:module';
import {installVulkan,vulkanDevices} from './sd-runtime.mjs';
const require=createRequire(import.meta.url);
export function videoRequest(message,previous=false){if(/^\s*(?:come|perché|perche|spiega|spiegami|non|evita)\b/i.test(message))return false;return /\b(?:genera(?:re)?|crea(?:re)?|realizza(?:re)?|produci|produrre|rifai|rigenera(?:re)?)\b[\s\S]*\b(?:video|filmato|clip)\b|\b(?:anima|animala|animalo|animare)\b/i.test(message)||previous&&/^(?:rifallo|rifalla|rigenera|fallo|falla|rendilo|rendila|aggiungi|togli|manca|cambia|modifica|più lento|più veloce)\b/i.test(message);}
export function videoParameters(message='',input={},previous={}){
 const size=message.match(/\b(\d{2,4})\s*[x×]\s*(\d{2,4})\b/),seconds=message.match(/\b(\d+(?:[.,]\d+)?)\s*(?:secondi|secondo|sec|s)\b/i);
 const p={width:512,height:288,fps:16,seconds:2,steps:20,seed:-1,...previous,...input};if(size){p.width=+size[1];p.height=+size[2];}if(seconds)p.seconds=Number(seconds[1].replace(',','.'));
 for(const [k,min,max] of [['width',128,1920],['height',128,1088],['fps',8,30],['seconds',1,20],['steps',4,60],['seed',-1,2147483647]])if(!Number.isFinite(p[k])||p[k]<min||p[k]>max||k!=='seconds'&&!Number.isInteger(p[k]))throw Error('Parametro video non valido: '+k);
 p.width=Math.ceil(p.width/32)*32;p.height=Math.ceil(p.height/32)*32;p.frames=Math.round((p.seconds*p.fps-1)/4)*4+1;p.frames=Math.max(5,p.frames);return p;
}
export function videoArgs(config,p,{root,promptFile,output,image,device='cpu'}){
 const components=config.record.components,path=key=>join(root,'models/video',components[key].local);
 const args=['-M','vid_gen','--diffusion-model',path('model'),'--vae',path('vae'),'--t5xxl',path('encoder'),'--prompt-file',promptFile,'-o',output,'-W',String(p.width),'-H',String(p.height),'--video-frames',String(p.frames),'--fps',String(p.fps),'--steps',String(p.steps),'--seed',String(p.seed),'--cfg-scale',components.highModel?'3.5':'6','--sampling-method','euler','--flow-shift','3','--diffusion-fa','--vae-tiling','--offload-to-cpu','--backend','diffusion='+device+',vae=cpu,clip=cpu'];
 if(components.highModel)args.push('--high-noise-diffusion-model',path('highModel'),'--high-noise-cfg-scale','3.5','--high-noise-steps',String(Math.max(2,Math.round(p.steps*.4))),'--high-noise-sampling-method','euler');if(components.clipVision)args.push('--clip_vision',path('clipVision'));if(image)args.push('-i',image);return args;
}
export function videoCommand(executable,args,{signal,progress=()=>{},cwd}={}){return new Promise((resolve,reject)=>{signal?.throwIfAborted();const child=spawn(executable,args,{cwd,windowsHide:true});let log='',settled=false;const append=data=>{log=(log+data.toString()).slice(-100000);const lines=data.toString().split(/\r?\n/).filter(l=>/\d+\s*\/\s*\d+|sampling|frame|loading model/i.test(l));if(lines.length)progress(lines.at(-1).slice(0,200));};child.stdout.on('data',append);child.stderr.on('data',append);const stop=()=>{if(process.platform==='win32'&&child.pid)spawn('taskkill',['/PID',String(child.pid),'/T','/F'],{windowsHide:true});else child.kill('SIGTERM');};signal?.addEventListener('abort',stop,{once:true});child.on('error',error=>{settled=true;signal?.removeEventListener('abort',stop);reject(error);});child.on('close',code=>{signal?.removeEventListener('abort',stop);if(settled)return;if(signal?.aborted)return reject(signal.reason);if(code!==0)return reject(Error('Generazione video non riuscita: '+log.slice(-1800)));resolve(log);});});}
export class VideoRuntime{
 constructor({root,saveArtifact,run=videoCommand}){Object.assign(this,{root,saveArtifact,run});}
 async generate({prompt,parameters,image},config,signal,progress=()=>{}){
  signal?.throwIfAborted();if(!config.model.modes.includes(image?'image':'text'))throw Error(image?'Questo modello genera video solo da testo. Scegli Wan 5B o I2V.':'Questo modello richiede un’immagine iniziale. Allega una foto o scegli Wan 5B/T2V.');
  let device='cpu',executable=join(this.root,'runtime/sd/sd-cli.exe');
  if(config.mode!=='cpu'){try{const dir=await installVulkan(this.root,{signal,progress}),gpu=vulkanDevices(await this.run(join(dir,'sd-cli.exe'),['--list-devices'],{signal,cwd:this.root}))[0];if(gpu){device=gpu.id;executable=join(dir,'sd-cli.exe');}else if(config.mode==='gpu')throw Error('Nessun dispositivo Vulkan disponibile');}catch(error){if(signal?.aborted||config.mode==='gpu')throw error;progress('Vulkan non disponibile: uso CPU. '+error.message);}}
  if(!existsSync(executable))throw Error('Runtime Stable Diffusion non installato: completa la configurazione immagini.');
  const cache=join(this.root,'.cache');await mkdir(cache,{recursive:true});const dir=await mkdtemp(join(cache,'video-'));
  try{const promptFile=join(dir,'prompt.txt'),output=join(dir,'video.avi'),mp4=join(dir,'video.mp4'),initial=image?join(dir,'initial.png'):null;await writeFile(promptFile,prompt);if(image)await writeFile(initial,image);
   progress('Generazione Wan su '+device+' · '+parameters.width+'×'+parameters.height+' · '+parameters.frames+' fotogrammi');await this.run(executable,videoArgs(config,parameters,{root:this.root,promptFile,output,image:initial,device}),{signal,progress,cwd:this.root});
   signal?.throwIfAborted();if(!existsSync(output))throw Error('Wan non ha prodotto il filmato AVI previsto.');progress('Converto il filmato in MP4…');
   const ffmpeg=require.resolve('@ffmpeg-installer/win32-x64/ffmpeg.exe');await this.run(ffmpeg,['-y','-i',output,'-an','-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart',mp4],{signal,cwd:this.root});if((await stat(mp4)).size>256*1024**2)throw Error('Filmato troppo grande (massimo 256 MB)');signal?.throwIfAborted();return {...await this.saveArtifact(await readFile(mp4),'mp4','Video AI'),videoModel:config.model.name};
  }finally{await rm(dir,{recursive:true,force:true});}
 }
}
