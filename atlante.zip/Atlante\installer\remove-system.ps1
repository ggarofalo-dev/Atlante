param([Parameter(Mandatory=$true)][string]$NodePath)
$ErrorActionPreference = 'Stop'
$rule = Get-NetFirewallRule -Name 'Atlante Local - Private LAN' -ErrorAction SilentlyContinue
if ($rule) {
    $application = $rule | Get-NetFirewallApplicationFilter
    if ($application.Program -eq $NodePath) { $rule | Remove-NetFirewallRule }
}
