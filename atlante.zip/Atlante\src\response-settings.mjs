import {existsSync,readFileSync,writeFileSync,renameSync,mkdirSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {randomUUID} from 'node:crypto';
export const RESPONSE_PRESETS=[
 {id:'standard',name:'Equilibrato',prompt:'Rispondi in italiano con chiarezza e un tono naturale. Usa elenchi quando aiutano la lettura.'},
 {id:'concise',name:'Sintetico',prompt:'Rispondi in italiano in modo breve e diretto. Parti dalla risposta e limita le spiegazioni ai punti necessari.'},
 {id:'detailed',name:'Approfondito',prompt:'Rispondi in italiano con spiegazioni articolate, esempi utili e passaggi chiari. Distingui fatti, ipotesi e limiti.'},
 {id:'technical',name:'Tecnico',prompt:'Rispondi in italiano con precisione tecnica. Indica procedure verificabili ed esempi concreti, adattando il dettaglio alla richiesta.'},
 {id:'creative',name:'Creativo',prompt:'Rispondi in italiano con idee originali e alternative concrete. Mantieni distinti gli elementi inventati dai fatti.'}
];
export const RESPONSE_DEFAULTS={temperature:0.1,length:'standard',preset:'standard',prompt:'',voice:'',rate:0,volume:100,presets:[]};
export function validateResponseSettings(input){
 const value={...RESPONSE_DEFAULTS,...input};
 if(typeof value.temperature!=='number'||!Number.isFinite(value.temperature)||value.temperature<0||value.temperature>2)throw Error('Temperatura da 0 a 2');
 if(!['short','standard','long'].includes(value.length))throw Error('Lunghezza della risposta non valida');
 if(typeof value.prompt!=='string'||value.prompt.length>6000)throw Error('Istruzioni fino a 6000 caratteri');
 if(typeof value.voice!=='string'||value.voice.length>200)throw Error('Voce non valida');
 if(!Number.isInteger(value.rate)||value.rate<-10||value.rate>10)throw Error('Velocità da -10 a 10');
 if(!Number.isInteger(value.volume)||value.volume<0||value.volume>100)throw Error('Volume da 0 a 100');
 if(!Array.isArray(value.presets)||value.presets.length>20)throw Error('Massimo 20 preset personali');
 const ids=new Set(RESPONSE_PRESETS.map(p=>p.id));
 const presets=value.presets.map(p=>{if(!p||typeof p.id!=='string'||!/^custom-[a-f0-9-]{36}$/.test(p.id)||ids.has(p.id)||typeof p.name!=='string'||!p.name.trim()||p.name.length>80||typeof p.prompt!=='string'||p.prompt.length>6000)throw Error('Preset personale non valido');ids.add(p.id);return {id:p.id,name:p.name.trim(),prompt:p.prompt};});
 if(!ids.has(value.preset))throw Error('Preset non disponibile');
 return {temperature:value.temperature,length:value.length,preset:value.preset,prompt:value.prompt,voice:value.voice,rate:value.rate,volume:value.volume,presets};
}
export class ResponseSettings{
 constructor(root){this.file=join(root,'data/response-settings.json');this.value=existsSync(this.file)?validateResponseSettings(JSON.parse(readFileSync(this.file,'utf8'))):structuredClone(RESPONSE_DEFAULTS);}
 get(){return structuredClone(this.value);}
 save(input){const value=validateResponseSettings(input);mkdirSync(dirname(this.file),{recursive:true});const temp=this.file+'.'+randomUUID()+'.tmp';writeFileSync(temp,JSON.stringify(value,null,2),'utf8');renameSync(temp,this.file);this.value=value;return this.get();}
 chat(){const v=this.get(),preset=[...RESPONSE_PRESETS,...v.presets].find(p=>p.id===v.preset);return {temperature:v.temperature,maxResponseTokens:{short:300,standard:600,long:1800}[v.length],responseInstructions:[preset.prompt,v.prompt].filter(Boolean).join('\n')};}
}
