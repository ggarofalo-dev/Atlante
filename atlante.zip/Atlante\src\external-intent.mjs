export function externalServiceRequest(message){
 const text=String(message).toLowerCase();
 const action=/\b(?:controlla|verifica|leggi|mostra|cerca|trova|consulta|riassumi|elenca|recupera|invia|manda|crea|aggiungi|quali|quante|quanti)\b/.test(text);
 if(/\b(?:email|mail|gmail|posta)\b/.test(text)&&(action||/\b(?:ricevut[aei]|arrivat[aei])\b/.test(text)))return 'gmail';
 if(/\b(?:drive)\b/.test(text)&&action)return 'drive';
 if(/\b(?:calendario|calendar|appuntamenti|impegni)\b/.test(text)&&(action||/\b(?:ho|mio|miei|mie)\b/.test(text)))return 'calendar';
 return null;
}
