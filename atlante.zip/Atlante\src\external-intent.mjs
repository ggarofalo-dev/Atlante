import {chooseTool,imageColorChange,imageFollowupChange,textReviewRequest} from './tools.mjs';
export function previousImageRequest(message,{hasPreviousImage=false,hasDocuments=false}={}){
 if(textReviewRequest(message)||!hasPreviousImage||hasDocuments||chooseTool(message).tool==='generate'||externalServiceRequest(message))return false;
 return imageFollowupChange(message)||imageColorChange(message)||/\b(?:immagine|foto|sfondo|modificala|trasformala|ruotala|ruota|specchia|ridimensiona|descrivila)\b|bianco e nero/i.test(message);
}
export function localImageRequest(message,options={}){
 return chooseTool(String(message),options).tool!=='chat';
}
export function currentDateAnswer(message,now=new Date()){
 if(!/^(?:sai |dimmi |mi dici |puoi dirmi )?(?:che (?:giorno|data) (?:è|e') (?:oggi)|(?:qual è|qual e') la data di oggi|che giorno siamo)[?! .]*$/i.test(String(message).trim()))return null;
 return 'Oggi è '+new Intl.DateTimeFormat('it-IT',{timeZone:'Europe/Rome',weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(now)+'.';
}
export function externalDiscussion(message){return !!currentDateAnswer(message)||/^(?:ciao|salve|buongiorno|buonasera|grazie|grazie mille|come stai)[?! .]*$/i.test(String(message).trim())||/\b(?:perch[eéè]|come mai).*\b(?:non riuscivi|non hai|non potevi|non riuscito|non riuscita)\b/i.test(String(message));}
export function externalServiceRequest(message,history=[]){
 if(textReviewRequest(message))return null;
 const text=String(message).toLowerCase();
 if(externalDiscussion(message)||/\b(?:non rispondermi|non rispondere|formato|testualmente|testualmnete|come (?:collego|configuro|funziona))\b/.test(text))return null;
 if((/^\s*(?:e )?da\s+[^?]+\??\s*$/i.test(text)||/^\s*(?:dammene|mostramene|fammene vedere|ne voglio)\s+\d+\b/i.test(text))&&history.findLast(m=>m.role==='user'&&/\b(?:mail|email|posta)\b/i.test(m.content)))return 'gmail';
 if(/\b(?:io dicevo|intendevo|volevo).*\bin arrivo\b/.test(text))return 'gmail';
 const action=/\b(?:controlla|verifica|leggi|mostra|cerca|trova|consulta|riassumi|elenca|recupera|ridimmi|ripeti|dimmi|leggere|invia|manda|crea|aggiungi|quali|quante|quanti)\b/.test(text);
 if(/\b(?:email|mail|gmail|posta)\b/.test(text)&&(action||/\b(?:ricevut[aei]|arrivat[aei]|da leggere|non lett[aei])\b/.test(text)))return 'gmail';
 if(/\b(?:drive)\b/.test(text)&&action)return 'drive';
 if(/\b(?:calendario|calendar|appuntamenti|impegni)\b/.test(text)&&(action||/\b(?:ho|mio|miei|mie)\b/.test(text)))return 'calendar';
 return null;
}
