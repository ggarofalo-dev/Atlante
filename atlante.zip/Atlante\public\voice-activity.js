﻿export function createVoiceActivity(status){
 const visual=document.createElement('div');visual.className='voice-activity';visual.hidden=true;visual.setAttribute('aria-hidden','true');status.before(visual);
 let mode=null;
 return (phase,conversation)=>{
  const next=conversation?'conversation':['requesting','recording','listening','transcribing'].includes(phase)?'recording':null;
  visual.hidden=!next;if(!next){visual.removeAttribute('data-phase');mode=null;return;}
  visual.dataset.phase=phase;visual.dataset.mode=next;
  if(mode!==next){mode=next;
   visual.innerHTML=next==='recording'?'<div class="voice-recording-mark"><svg viewBox="0 0 40 40" fill="none"><rect x="15" y="5" width="10" height="19" rx="5"/><path d="M10 19a10 10 0 0 0 20 0M20 29v6m-6 0h12"/></svg><span class="voice-recording-ring"></span></div><div class="voice-activity-wave"><i></i><i></i><i></i><i></i><i></i></div><span class="voice-activity-caption">Registrazione vocale</span>':'<div class="voice-conversation-mark"><span class="voice-conversation-orbit"></span><svg viewBox="0 0 40 40" fill="none"><path d="M8 21v-3a12 12 0 0 1 24 0v3M8 19H5v12h7V19H8Zm24 0h3v12h-7V19h4ZM32 31v3h-9"/></svg></div><div class="voice-activity-wave"><i></i><i></i><i></i><i></i><i></i></div><span class="voice-activity-caption">Conversazione vocale</span>';
  }
 };
}
