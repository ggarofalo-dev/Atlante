import {createOcr} from './ocr.mjs';
import {fileURLToPath} from 'node:url';
const assets=fileURLToPath(new URL('../node_modules/pdfjs-dist/',import.meta.url));
export function largeRaster(operators,OPS,pageArea){
 let matrix=[1,0,0,1,0,0];const stack=[];
 for(let i=0;i<operators.fnArray.length;i++){
  const op=operators.fnArray[i],args=operators.argsArray[i];
  if(op===OPS.save)stack.push([...matrix]);else if(op===OPS.restore)matrix=stack.pop()||[1,0,0,1,0,0];
  else if(op===OPS.transform&&args?.length===6){const [a,b,c,d,e,f]=matrix,[g,h,j,k,l,m]=args;matrix=[a*g+c*h,b*g+d*h,a*j+c*k,b*j+d*k,a*l+c*m+e,b*l+d*m+f];}
  else if([OPS.paintImageXObject,OPS.paintInlineImageXObject,OPS.paintImageMaskXObject].includes(op)&&Math.abs(matrix[0]*matrix[3]-matrix[1]*matrix[2])>=pageArea*.2)return true;
 }
 return false;
}
export async function readPdf(bytes){
 const {getDocument,OPS}=await import('pdfjs-dist/legacy/build/pdf.mjs');
 const task=getDocument({data:new Uint8Array(bytes),useSystemFonts:true,isEvalSupported:false,standardFontDataUrl:assets+'standard_fonts/',cMapUrl:assets+'cmaps/',cMapPacked:true,wasmUrl:assets+'wasm/'});
 let reader,text='',ocrPages=0,pdf;const started=Date.now(),warnings=[],low=[],empty=[];let truncated=false;
 try{
  pdf=await task.promise;truncated=pdf.numPages>300;
  for(let i=1;i<=Math.min(pdf.numPages,300)&&text.length<1000000;i++){
   const page=await pdf.getPage(i),content=await page.getTextContent();let extracted=content.items.map(item=>item.str+(item.hasEOL?'\n':' ')).join('').trim(),usedOcr=false;
   {
    const operators=await page.getOperatorList(),images=operators.fnArray.some(op=>[OPS.paintImageXObject,OPS.paintInlineImageXObject,OPS.paintImageMaskXObject,OPS.paintImageXObjectRepeat].includes(op)),bounds=page.getViewport({scale:1});
    if(images&&(extracted.length<250||largeRaster(operators,OPS,bounds.width*bounds.height))){
     if(ocrPages>=20||Date.now()-started>180000){truncated=true;warnings.push(`Pagina ${i}: OCR non eseguito per il limite di 20 pagine o 3 minuti. Importa il PDF in parti più piccole.`);}
     else{
      reader??=await createOcr();const unscaled=page.getViewport({scale:1}),scale=Math.min(3,4200/Math.max(unscaled.width,unscaled.height),Math.sqrt(12000000/(unscaled.width*unscaled.height))),viewport=page.getViewport({scale});
      const canvas=pdf.canvasFactory.create(Math.ceil(viewport.width),Math.ceil(viewport.height));
      try{await page.render({canvasContext:canvas.context,viewport,background:'rgb(255,255,255)'}).promise;const result=await reader.read(canvas.canvas.toBuffer('image/png'));ocrPages++;usedOcr=true;if(result.confidence<70)low.push(i);if(result.text){const normalized=s=>s.toLowerCase().replace(/\W/g,'');extracted=normalized(result.text).includes(normalized(extracted))?result.text:[extracted,result.text].filter(Boolean).join('\n');}else empty.push(i);}finally{pdf.canvasFactory.destroy(canvas);}
     }
    }
   }
   if(extracted)text+=`\n[Pagina ${i}${usedOcr?' · OCR':''}]\n${extracted}\n`;page.cleanup();if(i<Math.min(pdf.numPages,300)&&text.length>=1000000)truncated=true;
  }
  if(low.length)warnings.push('OCR con bassa confidenza nelle pagine '+low.join(', ')+': verifica numeri e nomi.');
  if(empty.length)warnings.push('Nessun testo OCR riconosciuto nelle pagine '+empty.join(', ')+'.');
  return {text,truncated:truncated||text.length>1000000,ocrPages,warnings};
 }finally{await reader?.close();await task.destroy();}
}
