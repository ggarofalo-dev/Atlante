import {readImageText,ocrAvailable} from './ocr.mjs';
import {speak,transcribe,voiceAvailable} from './voice.mjs';
import {diffusionAvailable,imageSettings} from './diffusion.mjs';
import {ComfyUI} from './comfyui.mjs';
import {encodeWav} from '../public/audio-codec.js';
import sharp from 'sharp';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {join} from 'node:path';
const run=promisify(execFile);
export function normalizeSpeechWav(bytes){
 if(bytes.toString('ascii',0,4)!=='RIFF'||bytes.toString('ascii',8,12)!=='WAVE')throw Error('Audio di prova non valido');
 let format=null,data=null;
 for(let offset=12;offset+8<=bytes.length;){const name=bytes.toString('ascii',offset,offset+4),size=bytes.readUInt32LE(offset+4),start=offset+8;if(start+size>bytes.length)throw Error('Audio di prova incompleto');if(name==='fmt '&&size>=16)format={type:bytes.readUInt16LE(start),channels:bytes.readUInt16LE(start+2),rate:bytes.readUInt32LE(start+4),bits:bytes.readUInt16LE(start+14)};if(name==='data')data=bytes.subarray(start,start+size);offset=start+size+(size%2);}
 if(!format||!data||format.type!==1||format.bits!==16||![1,2].includes(format.channels))throw Error('Formato audio di prova non supportato');
 const count=Math.floor(data.length/(2*format.channels)),samples=new Float32Array(count);
 for(let i=0;i<count;i++){let sum=0;for(let c=0;c<format.channels;c++)sum+=data.readInt16LE((i*format.channels+c)*2)/32768;samples[i]=sum/format.channels;}
 return Buffer.from(encodeWav(samples,format.rate));
}
export async function verifySetupComponents(root,signal){
 const result={};
 async function check(name,operation){try{signal.throwIfAborted();result[name]={ok:true,note:await operation()};}catch(e){if(signal.aborted)throw signal.reason;result[name]={ok:false,note:e.message};}}
 await check('ocr',async()=>{if(!ocrAvailable())throw Error('OCR non installato. Esegui nuovamente l’installer.');const image=await sharp(Buffer.from('<svg width="1000" height="220"><rect width="100%" height="100%" fill="white"/><text x="45" y="140" font-family="Arial" font-size="72" fill="black">Atlante pronto</text></svg>')).png().toBuffer();const read=await readImageText(image);if(!/atlante/i.test(read.text))throw Error('La lettura dell’immagine di prova non è riuscita');return 'Testo letto da un’immagine di prova.';});
 let speech=null;
 await check('speech',async()=>{speech=await speak({text:'Atlante è pronto. Puoi iniziare la conversazione.'},signal);if(speech.length<1000)throw Error('Audio di prova vuoto');return 'Voce italiana generata correttamente.';});
 await check('transcription',async()=>{if(!voiceAvailable())throw Error('Riconoscimento vocale non installato. Esegui nuovamente l’installer.');if(!speech)throw Error('Serve la voce italiana per la prova del riconoscimento');const audio=normalizeSpeechWav(speech);const read=await transcribe({audio:audio.toString('base64')},signal);if(!read.text)throw Error('Nessuna parola riconosciuta');return 'Audio di prova trascritto correttamente.';});
 await check('images',async()=>{const config=imageSettings.get();if(config.backend==='comfyui'){const catalog=await new ComfyUI(config.url).catalog(signal);if(!catalog.checkpoints.includes(config.checkpoint))throw Error('Checkpoint ComfyUI non disponibile: scegli un modello nelle impostazioni immagini');return 'ComfyUI locale raggiungibile e checkpoint presente. La prova non genera un’immagine completa.';}if(!diffusionAvailable())throw Error('Generazione immagini non installata. Esegui nuovamente l’installer.');await run(join(root,'runtime/sd/sd-cli.exe'),['--help'],{windowsHide:true,timeout:15000,maxBuffer:1024*1024,signal});return 'Motore avviabile e modello presente. La prova non genera un’immagine completa.';});
 return result;
}
