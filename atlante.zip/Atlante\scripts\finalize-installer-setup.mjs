import {fileURLToPath} from 'node:url';
import {Setup} from '../src/setup.mjs';
import {ModelManager} from '../src/model-manager.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const setup=new Setup({root});await setup.initialize();
const models=new ModelManager({setup,queue:{jobs:new Map()}});
await models.ensureDefault();
if(!setup.config.completed||!setup.config.defaultModel)throw Error('Nessun modello di chat pronto per completare la configurazione.');
console.log('Modello della chat preimpostato: '+setup.config.defaultModel);
