param([string]$InputFile,[string]$OutputFile,[switch]$ListVoices,[string]$VoiceName='',[ValidateRange(-10,10)][int]$Rate=0,[ValidateRange(0,100)][int]$Volume=100)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$localSpeech = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {
    if ($ListVoices) {
        $voices = @($localSpeech.GetInstalledVoices() | Where-Object { $_.Enabled } | ForEach-Object { @{ name=$_.VoiceInfo.Name; culture=$_.VoiceInfo.Culture.Name; gender=$_.VoiceInfo.Gender.ToString() } })
        [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
        ConvertTo-Json -InputObject $voices -Compress
        return
    }
    if (-not $InputFile -or -not $OutputFile) { throw 'Input e output richiesti' }
    $localSpeech.Rate = $Rate
    $localSpeech.Volume = $Volume
    if ($VoiceName) { $localSpeech.SelectVoice($VoiceName) } else {
    $italianVoice = $localSpeech.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -like 'it-*' } | Select-Object -First 1
    if (-not $italianVoice) { throw 'Voce italiana Windows non installata' }
    $localSpeech.SelectVoice($italianVoice.VoiceInfo.Name)
    }
    $localSpeech.SetOutputToWaveFile($OutputFile)
    $localSpeech.Speak([System.IO.File]::ReadAllText($InputFile,[System.Text.Encoding]::UTF8))
} finally { $localSpeech.Dispose() }
