﻿param([string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'Atlante'),[switch]$ValidateOnly)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$source = Split-Path -Parent $PSScriptRoot
function Verify-Package {
    $manifest = Get-Content (Join-Path $source 'manifest.json') -Raw | ConvertFrom-Json
    foreach ($file in $manifest.files) {
        $path = [IO.Path]::GetFullPath((Join-Path $source $file.path))
        if (-not $path.StartsWith($source + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Percorso pacchetto non valido' }
        if (-not (Test-Path -LiteralPath $path) -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $file.sha256) { throw "Pacchetto corrotto: $($file.path)" }
    }
}
function Download([string]$Url,[string]$Path,[string]$Hash) {
    if ((Test-Path -LiteralPath $Path) -and (!$Hash -or (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -eq $Hash)) { return }
    Write-Host "Download: $([IO.Path]::GetFileName($Path))"
    New-Item -ItemType Directory -Path (Split-Path $Path) -Force | Out-Null
    $partial = "$Path.part"
    if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
        & curl.exe --fail --location --retry 4 --retry-delay 3 --connect-timeout 30 --continue-at - --output $partial $Url
        if ($LASTEXITCODE -eq 33 -or $LASTEXITCODE -eq 22) {
            & curl.exe --fail --location --retry 4 --output $partial $Url
        }
        if ($LASTEXITCODE -ne 0) { throw "Download fallito: $Url" }
    } else { Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $partial }
    if ($Hash -and (Get-FileHash -LiteralPath $partial -Algorithm SHA256).Hash -ne $Hash) {
        Remove-Item -LiteralPath $partial
        throw "Checksum non valido: $Url. Ripetere installa.bat."
    }
    Move-Item -LiteralPath $partial -Destination $Path -Force
}
function Signed-By([string]$Path,[string]$Publisher) {
    $sig = Get-AuthenticodeSignature -LiteralPath $Path
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch $Publisher) { throw "Firma digitale non valida: $Path" }
}
function Run-Node([string[]]$Arguments) {
    & $script:nodePath @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Componente Node fallito: $($Arguments -join ' ')" }
}
function Shortcut([string]$Path,[string]$Arguments) {
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut($Path)
    $link.TargetPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $link.Arguments = $Arguments
    $link.WorkingDirectory = $InstallRoot
    $link.WindowStyle = 7
    $link.Save()
}
Verify-Package
if ($ValidateOnly) { Write-Host 'Pacchetto verificato. Nessuna modifica al sistema.'; exit 0 }
if (-not [Environment]::Is64BitOperatingSystem -or $env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { throw 'Questo pacchetto richiede Windows x64 (Intel/AMD).' }
. (Join-Path $PSScriptRoot 'consent.ps1')
$termsPath = Join-Path $PSScriptRoot 'CONDIZIONI.txt'
if (-not (Show-InstallerConditions $termsPath)) { Write-Host 'Installazione annullata: condizioni non accettate. Nessun componente installato.'; exit 2 }
$consentHash = (Get-FileHash -LiteralPath $termsPath -Algorithm SHA256).Hash.ToLowerInvariant()
$consentAt = [DateTime]::UtcNow.ToString('o')
New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
@{accepted=$true;acceptedAt=$consentAt;termsSha256=$consentHash;version=(Get-Content (Join-Path $source 'package.json') -Raw | ConvertFrom-Json).version} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $InstallRoot 'installation-consent.json') -Encoding UTF8
Start-Transcript -Path (Join-Path $InstallRoot 'installation.log') -Append | Out-Null
try {
    Write-Host 'ATLANTE - Installazione automatica. Il primo download puo richiedere tempo.'
    # Stop only the supervisor and child server belonging to this installation.
    $statusFile = Join-Path $InstallRoot 'data\service\status.json'
    $existingHealth = $null
    try { $existingHealth = Invoke-RestMethod 'http://127.0.0.1:3210/api/health' -TimeoutSec 2 } catch {}
    if ($existingHealth -and !(Test-Path $statusFile)) { throw 'La porta 3210 e gia occupata. Arrestare l altra installazione di Atlante prima di continuare.' }
    if (Test-Path $statusFile) {
        $state = Get-Content $statusFile -Raw | ConvertFrom-Json
        foreach ($processId in @($state.supervisorPid,$state.appPid)) {
            if ($processId) {
                $owned = Get-CimInstance Win32_Process -Filter "ProcessId=$processId"
                if ($owned -and $owned.CommandLine -and ($owned.CommandLine.Contains($InstallRoot) -or ($owned.ParentProcessId -eq $state.supervisorPid -and $owned.CommandLine -match 'src/server.mjs'))) { Stop-Process -Id $processId -Force }
            }
        }
    }
    if ([IO.Path]::GetFullPath($source) -ne [IO.Path]::GetFullPath($InstallRoot)) {
        foreach ($name in @('src','public','scripts','installer','package.json','package-lock.json','start.cmd','config')) {
            if (Test-Path -LiteralPath (Join-Path $source $name)) { Copy-Item -LiteralPath (Join-Path $source $name) -Destination $InstallRoot -Recurse -Force }
        }
    }
    Set-Location $InstallRoot
    New-Item -ItemType Directory -Path 'runtime\downloads','models' -Force | Out-Null
    $nodePath = $null
    $candidate = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($candidate) {
        $version = & $candidate.Source -p 'process.versions.node'
        if ($LASTEXITCODE -eq 0 -and [version]$version -ge [version]'24.0.0' -and (Test-Path (Join-Path (Split-Path $candidate.Source) 'node_modules\npm\bin\npm-cli.js'))) { $nodePath = $candidate.Source }
    }
    if (!$nodePath) {
        $nodePath = Join-Path $InstallRoot 'runtime\node-v24.21.0-win-x64\node.exe'
        if (!(Test-Path $nodePath)) {
            Download 'https://nodejs.org/dist/v24.21.0/node-v24.21.0-win-x64.zip' "$InstallRoot\runtime\downloads\node.zip" '158f7685b44de51f6c0df1d153526cbcd3e1bc739a8dfc607721cef75de9e541'
            Expand-Archive -LiteralPath 'runtime\downloads\node.zip' -DestinationPath 'runtime' -Force
        }
    }
    $env:PATH = (Split-Path $nodePath) + ';' + $env:PATH
    $npm = Join-Path (Split-Path $nodePath) 'node_modules\npm\bin\npm-cli.js'
    $lockHash = (Get-FileHash 'package-lock.json').Hash
    $stamp = 'runtime\dependencies.sha256'
    $depsOK = $false
    if ((Test-Path $stamp) -and (Get-Content $stamp) -eq $lockHash) {
        & $nodePath 'installer/verify-runtime.mjs'
        $depsOK = $LASTEXITCODE -eq 0
    }
    if (!$depsOK) {
        Run-Node -Arguments @($npm,'ci','--omit=dev','--ignore-scripts','--no-audit','--no-fund')
        Run-Node -Arguments @('installer/verify-runtime.mjs')
        Set-Content $stamp $lockHash -Encoding ASCII
    }
    $ollamaPath = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
    $installedOllama = Get-Command ollama.exe -ErrorAction SilentlyContinue
    if ($installedOllama) { $ollamaPath = $installedOllama.Source }
    if (!(Test-Path $ollamaPath)) {
        $setup = "$InstallRoot\runtime\downloads\OllamaSetup.exe"
        Download 'https://ollama.com/download/OllamaSetup.exe' $setup ''
        Signed-By $setup 'Ollama'
        $p = Start-Process -FilePath $setup -ArgumentList '/VERYSILENT /SUPPRESSMSGBOXES /NORESTART' -Wait -PassThru -WindowStyle Hidden
        if ($p.ExitCode -ne 0 -or !(Test-Path $ollamaPath)) { throw 'Installazione Ollama non riuscita' }
    }
    $env:OLLAMA_HOST = '127.0.0.1:11434'
    try { $null = Invoke-RestMethod 'http://127.0.0.1:11434/api/tags' -TimeoutSec 3 } catch {
        Start-Process -FilePath $ollamaPath -ArgumentList 'serve' -WindowStyle Hidden
    }
    $ready = $false
    for ($i=0;$i -lt 60;$i++) {
        try { $tags = Invoke-RestMethod 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2; $ready=$true; break } catch { Start-Sleep -Seconds 2 }
    }
    if (!$ready) { throw 'Ollama non risponde sulla porta 11434' }
    foreach ($model in @('llama3.2:latest','gemma3:4b')) {
        if ($tags.models.name -notcontains $model) {
            Write-Host "Modello: $model"
            & $ollamaPath pull $model
            if ($LASTEXITCODE -ne 0) { throw "Download modello fallito: $model" }
        }
    }
    Run-Node -Arguments @('scripts/setup-ocr.mjs')
    if (!(Test-Path 'runtime\whisper\Release\whisper-cli.exe')) {
        Download 'https://github.com/ggml-org/whisper.cpp/releases/download/v1.9.2/whisper-bin-x64.zip' "$InstallRoot\runtime\downloads\whisper.zip" '49dcc16de826f20bd53d44f947a1ae49dfa81f86cad67a64d80820cb192d674a'
        Expand-Archive 'runtime\downloads\whisper.zip' 'runtime\whisper' -Force
    }
    Download 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin' "$InstallRoot\models\ggml-base.bin" '60ed5bc3dd14eea856493d334349b405782ddcaf0028d4b5df4088345fba2efe'
    if (!(Test-Path 'runtime\sd\sd-cli.exe')) {
        Download 'https://github.com/leejet/stable-diffusion.cpp/releases/download/master-929-3f8527a/sd-master-3f8527a-bin-win-cpu-x64.zip' "$InstallRoot\runtime\downloads\sd.zip" '5e7caca2080321b25a12c1fa4175cb7d953f2b182309f8f73bfc9c725231d26c'
        Expand-Archive 'runtime\downloads\sd.zip' 'runtime\sd' -Force
    }
    Download 'https://huggingface.co/Comfy-Org/stable-diffusion-v1-5-archive/resolve/main/v1-5-pruned-emaonly-fp16.safetensors' "$InstallRoot\models\sd15.safetensors" 'e9476a13728cd75d8279f6ec8bad753a66a1957ca375a1464dc63b37db6e3916'
    $redist = "$InstallRoot\runtime\downloads\vc_redist.x64.exe"
    Download 'https://aka.ms/vc14/vc_redist.x64.exe' $redist ''
    Signed-By $redist 'Microsoft Corporation'
    Write-Host 'Windows richiedera il consenso per firewall, runtime e voce italiana.'
    $result = "$InstallRoot\runtime\system-result.txt"
    if (Test-Path $result) { Remove-Item -LiteralPath $result }
    $args = '-NoProfile -ExecutionPolicy Bypass -File "' + "$InstallRoot\installer\system.ps1" + '" -NodePath "' + $nodePath + '" -Redist "' + $redist + '" -Result "' + $result + '"'
    $p = Start-Process powershell.exe -Verb RunAs -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
    if ($p.ExitCode -ne 0 -or !(Test-Path $result) -or (Get-Content $result -Raw).Trim() -ne 'OK') { throw "Configurazione Windows fallita. Consultare $result" }
    # Verify Italian speech on the actual user's account before declaring success.
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$InstallRoot\installer\verify-voice.ps1"
    if ($LASTEXITCODE -ne 0) { throw 'Voce italiana non disponibile. Riavviare Windows e ripetere installa.bat.' }
    & "$InstallRoot\runtime\sd\sd-cli.exe" --help *> 'runtime\sd-check.log'
    if ($LASTEXITCODE -ne 0) { throw 'Motore immagini non avviabile. Consultare runtime\sd-check.log' }
    Set-Content 'models\sd15.ready' 'SD 1.5 fp16 verified; CPU runtime master-929-3f8527a' -Encoding ASCII
    @{nodePath=$nodePath;ollamaPath=$ollamaPath} | ConvertTo-Json | Set-Content 'runtime\install.json' -Encoding UTF8
    Write-Host 'Configurazione automatica immagini: rilevamento NVIDIA/AMD/Intel e prova del runtime compatibile.'
    Run-Node -Arguments @('scripts/configure-images.mjs')
    Run-Node -Arguments @('scripts/setup-https.mjs')
    $background = '-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + "$InstallRoot\scripts\run-background.ps1" + '"'
    Shortcut (Join-Path ([Environment]::GetFolderPath('Startup')) 'Atlante.lnk') $background
    $open = '-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + "$InstallRoot\installer\open.ps1" + '"'
    Shortcut (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Atlante.lnk') $open
    Start-Process powershell.exe -ArgumentList $background -WindowStyle Hidden
    $healthy = $false
    for ($i=0;$i -lt 60;$i++) {
        try { $health = Invoke-RestMethod 'http://127.0.0.1:3210/api/health' -TimeoutSec 2; if ($health.app -eq 'atlante') { $healthy=$true; break } } catch {}
        Start-Sleep -Seconds 2
    }
    if (!$healthy) { throw 'Atlante non si avvia. Consultare data\service\supervisor.log' }
    Write-Host 'Installazione completata. Apertura Atlante...'
    Start-Process 'http://localhost:3210'
} catch {
    Write-Host "ERRORE: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log: $InstallRoot\installation.log"
    exit 1
} finally { Stop-Transcript | Out-Null }

