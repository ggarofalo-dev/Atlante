$ErrorActionPreference = 'Stop'
$workspace = Split-Path -Parent $PSScriptRoot
$portable = Join-Path $workspace 'runtime\comfyui\ComfyUI_windows_portable'
$python = Join-Path $portable 'python_embeded\python.exe'
if (-not (Test-Path -LiteralPath $python)) { throw 'Installa ComfyUI con scripts\setup-comfyui.ps1.' }
try { $status = Invoke-RestMethod 'http://127.0.0.1:8188/system_stats' -TimeoutSec 2; if ($status.system) { Write-Output 'ComfyUI già attivo'; exit 0 } } catch { }
$logs = Join-Path $workspace 'data\comfyui'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
& node (Join-Path $PSScriptRoot 'start-comfyui.mjs')
if ($LASTEXITCODE -ne 0) { throw 'Avvio ComfyUI fallito.' }
