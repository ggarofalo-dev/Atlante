import {saveModelFolders} from '../src/model-paths.mjs';
import {fileURLToPath} from 'node:url';
await saveModelFolders(fileURLToPath(new URL('../',import.meta.url)),{local:process.argv[2],ollama:process.argv[3]});
