@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\install.ps1"
if errorlevel 1 (
  echo.
  echo Installazione non completata. Consultare il messaggio e il log indicati sopra.
  pause
  exit /b 1
)
exit /b 0
