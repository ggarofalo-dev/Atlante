@echo off
setlocal
if exist "%~dp0Installa Atlante.vbs" (
  start "" wscript.exe "%~dp0Installa Atlante.vbs"
) else (
  start "" wscript.exe "%~dp0installer\Installa Atlante.vbs"
)
exit /b 0
