@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0installer\install.ps1"
if errorlevel 2 if not errorlevel 3 (
  echo.
  echo Installazione annullata. Nessun componente installato.
  pause
  exit /b 2
)
if errorlevel 1 (
  echo.
  echo Installazione non completata. Consultare il messaggio e il log indicati sopra.
  pause
  exit /b 1
)
exit /b 0
