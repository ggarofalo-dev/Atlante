document.getElementById('login-form').onsubmit=async event=>{
 event.preventDefault();const button=document.getElementById('login-submit');button.disabled=true;
 const error=document.getElementById('login-error');error.textContent='';
 try{
  const response=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:document.getElementById('login-user').value.trim(),password:document.getElementById('login-password').value})});
  const result=await response.json();if(!response.ok)throw Error(result.error);location.replace('/');
 }catch(e){error.textContent=e.message;button.disabled=false;}
};
