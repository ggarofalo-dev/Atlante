﻿export function mediaGenerationKind(label,current=null){
 const text=String(label||'');
 if(/preparazione video|generazione (?:video|wan)|filmato|fotogrammi/i.test(text))return 'video';
 if(/preparazione descrizione|generazione immagine|generazione con (?:comfyui|stable diffusion)/i.test(text))return current==='video'?'video':'image';
 return current||'text';
}
export function showMediaProgress(element,kind){
 if(!kind)return;
 element.setAttribute('aria-busy','true');
 let visual=element.querySelector(':scope > .media-generation');
 if(visual?.dataset.kind===kind)return;
 visual?.remove();visual=document.createElement('div');visual.className='media-generation';visual.dataset.kind=kind;visual.setAttribute('aria-hidden','true');
 if(kind==='text'){
  visual.innerHTML='<div class="media-generation-scene"><span class="media-generation-orbit"></span><svg viewBox="0 0 240 140" fill="none"><path class="text-generation-sheet" d="M73 19h70l25 25v77H73Z"/><path d="M143 19v25h25"/><path class="text-generation-line" d="M89 59h61"/><path class="text-generation-line" d="M89 76h49"/><path class="text-generation-line" d="M89 93h58"/><path class="text-generation-caret" d="M152 87v13"/><path class="media-generation-spark" d="M47 42v12m-6-6h12m136 44v12m-6-6h12"/></svg></div><div class="media-generation-dots"><i></i><i></i><i></i></div>';
  element.append(visual);return;
 }
 visual.innerHTML=`<div class="media-generation-scene"><span class="media-generation-orbit"></span><svg viewBox="0 0 240 140" fill="none"><rect x="44" y="28" width="152" height="88" rx="12"/><circle cx="151" cy="53" r="10"/><path d="m52 100 38-36 35 30 24-20 39 32"/>${kind==='video'?'<path class="media-generation-play" d="m107 51 31 19-31 19Z"/>':''}<path class="media-generation-spark" d="M28 43v12m-6-6h12m170 41v12m-6-6h12"/></svg><span class="media-generation-scan"></span></div><div class="media-generation-dots"><i></i><i></i><i></i></div>`;
 element.append(visual);
}
