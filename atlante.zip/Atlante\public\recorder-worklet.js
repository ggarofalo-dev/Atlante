class AtlanteRecorder extends AudioWorkletProcessor{
 constructor(){super();this.buffer=new Float32Array(4096);this.used=0;this.port.onmessage=event=>{if(event.data==='flush'){this.flush();this.port.postMessage({flushed:true});}};}
 flush(){if(this.used){const samples=this.buffer.slice(0,this.used);this.port.postMessage({samples},[samples.buffer]);this.used=0;}}
 process(inputs){const channels=inputs[0];if(channels?.length){for(let i=0;i<channels[0].length;i++){let value=0;for(const channel of channels)value+=channel[i]||0;this.buffer[this.used++]=value/channels.length;if(this.used===this.buffer.length)this.flush();}}return true;}
}
registerProcessor('atlante-recorder',AtlanteRecorder);
