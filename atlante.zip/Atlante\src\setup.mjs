import {ollamaBase} from './ollama-config.mjs';
import {cpus,totalmem,freemem,platform} from 'node:os';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {readFile,writeFile,mkdir,statfs,unlink,rename} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {join} from 'node:path';
const run=promisify(execFile);
const GiB=1024**3;
export const modelCatalog=[
 {id:'llama3.2:1b',name:'Llama 3.2 · Essenziale',downloadGB:1.3,minRAM:6,description:'Per PC con poca memoria. Adatto a domande semplici; risposte meno approfondite.'},
 {id:'llama3.2:latest',name:'Llama 3.2 · Leggero',downloadGB:2,minRAM:8,description:'Richiede poche risorse. Buon punto di partenza per la chat quotidiana.'},
 {id:'gemma3:4b',name:'Gemma 3 · Equilibrato',downloadGB:3.3,minRAM:12,description:'Più capacità per testi e documenti, con un consumo di memoria contenuto.'},
 {id:'gemma3:12b',name:'Gemma 3 · Qualità',downloadGB:8.1,minRAM:24,description:'Per PC con molta memoria. Risposte più articolate; può essere lento senza GPU.'}
];
export function recommendModel(hardware){
 const ram=hardware.ramGB||0,available=hardware.availableGB??ram;
 const vram=Math.max(0,...(hardware.gpus||[]).filter(g=>g.memorySource==='NVIDIA').map(g=>g.memoryGB||0));
 if(ram>=24&&available>=12&&vram>=12||ram>=32&&available>=16)return {model:'gemma3:12b',reason:vram>=12?'RAM e memoria della GPU adatte al modello più grande del catalogo.':'RAM sufficiente per un modello più grande. Senza accelerazione GPU le risposte possono essere lente.'};
 if(ram>=12&&available>=5||ram>=12&&vram>=6)return {model:'gemma3:4b',reason:'Un compromesso prudente tra capacità e memoria disponibile.'};
 if(ram>=8&&available>=3)return {model:'llama3.2:latest',reason:'Modello leggero per lasciare memoria disponibile a Windows e alle altre applicazioni.'};
 return {model:'llama3.2:1b',reason:'La memoria disponibile è limitata: iniziamo dal modello più piccolo. Chiudi le applicazioni pesanti prima della prova.'};
}
export async function detectHardware(root){
 let gpus=[],italianVoice=false,warning=null;
 if(platform()==='win32'){
  try{const result=await run(join(process.env.SystemRoot||'C:/Windows','System32/WindowsPowerShell/v1.0/powershell.exe'),['-NoProfile','-ExecutionPolicy','Bypass','-File',join(root,'scripts/detect-hardware.ps1')],{windowsHide:true,timeout:20000,maxBuffer:1024*1024});const data=JSON.parse(result.stdout.trim());gpus=(data.gpus||[]).map(g=>({name:g.name,memoryGB:Number(g.memoryBytes||0)/GiB,memorySource:g.memorySource}));italianVoice=data.italianVoice===true;}catch{warning='Non è stato possibile leggere tutti i dettagli della GPU e della voce di Windows.';}
  try{const result=await run('nvidia-smi',['--query-gpu=name,memory.total','--format=csv,noheader,nounits'],{windowsHide:true,timeout:5000});gpus=gpus.filter(g=>!g.name.includes('NVIDIA'));for(const line of result.stdout.trim().split('\n')){const parts=line.trim().split(','),memoryGB=Number(parts.pop())/1024,name=parts.join(',').trim();if(!name||!Number.isFinite(memoryGB))continue;gpus.push({name,memoryGB,memorySource:'NVIDIA'});}}catch{}
 }
 let diskFreeGB=null;try{const disk=await statfs(root);diskFreeGB=disk.bavail*disk.bsize/GiB;}catch{}
 return {cpu:cpus()[0]?.model||'Processore non identificato',cores:cpus().length,ramGB:totalmem()/GiB,availableGB:freemem()/GiB,diskFreeGB,gpus,italianVoice,warning};
}
export class Setup {
 constructor({root,request=fetch,hardware=()=>detectHardware(root),capabilities,verifyComponents=async()=>({}),isBusy,lock,unlock}){
  Object.assign(this,{root,request,hardware,capabilities,verifyComponents,isBusy,lock,unlock});this.file=join(root,'data/setup.json');this.config={completed:false,defaultModel:null};this.hardwareCache=null;this.job=null;this.controller=null;this.tested=null;
 }
 async initialize(){try{const data=JSON.parse(await readFile(this.file,'utf8'));if(typeof data.defaultModel==='string')this.config={completed:data.completed===true,defaultModel:data.defaultModel,completedAt:data.completedAt||null};}catch{}}
 async api(path,body,signal=AbortSignal.timeout(10000)){
  const response=await this.request(ollamaBase+'/api/'+path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,signal});
  if(!response.ok)throw Error('Ollama non disponibile: '+(await response.text()).slice(0,250));return response.json();
 }
 async status(){
  if(!this.hardwareCache)this.hardwareCache=this.hardware();
  let cachedHardware;try{cachedHardware=await this.hardwareCache;}catch(e){this.hardwareCache=null;throw e;}
  let models=[],ollama=false,error=null;try{models=(await this.api('tags')).models?.map(m=>m.name)||[];ollama=true;}catch{error='Ollama non risponde. Attendi il suo avvio o esegui nuovamente l’installer.';}
  const hardware={...cachedHardware,availableGB:freemem()/GiB};
  try{const disk=await statfs(this.root);hardware.diskFreeGB=disk.bavail*disk.bsize/GiB;}catch{hardware.diskFreeGB=null;}
  const recommendation=recommendModel(hardware);
  return {config:this.config,hardware,recommendation,catalog:modelCatalog.map(m=>({...m,installed:models.includes(m.id),suitable:hardware.ramGB>=m.minRAM})),models,checks:{ollama,...await this.capabilities(),speech:hardware.italianVoice,storage:await this.storageCheck()},error,job:this.job};
 }
 async storageCheck(){const path=join(this.root,'data/.setup-write-'+randomUUID());try{await writeFile(path,'OK');await unlink(path);return true;}catch{return false;}}
 validateModel(model){if(!modelCatalog.some(m=>m.id===model))throw Error('Scegli un modello dal catalogo');}
 start(kind,model){
  this.validateModel(model);if(this.job&&['running','cancelling'].includes(this.job.state))throw Error('Una configurazione è già in corso');if(this.isBusy())throw Error('Attendi la fine della richiesta in corso');
  this.lock();this.tested=null;this.controller=new AbortController();this.job={kind,model,state:'running',message:kind==='download'?'Avvio del download…':'Carico il modello e provo una risposta…',progress:0,started:Date.now()};
  const operation=kind==='download'?this.pull(model,this.controller.signal):this.test(model,this.controller.signal);
  operation.then(result=>{this.job={...this.job,state:'done',progress:100,message:kind==='download'?'Modello pronto. Ora esegui la prova.':'La prova è riuscita.',result};}).catch(e=>{this.job={...this.job,state:this.controller.signal.aborted?'cancelled':'error',message:this.controller.signal.aborted?'Operazione interrotta. Puoi riprovare.':e.message};}).finally(()=>{this.unlock();this.controller=null;});
  return {...this.job};
 }
 cancel(){if(this.controller){this.job.state='cancelling';this.job.message='Interruzione in corso…';this.controller.abort(Error('Annullato'));}}
 async pull(model,signal){
  const response=await this.request(ollamaBase+'/api/pull',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model,stream:true}),signal:AbortSignal.any([signal,AbortSignal.timeout(2*3600000)])});
  if(!response.ok)throw Error('Download non riuscito: '+(await response.text()).slice(0,250));
  const decoder=new TextDecoder();let buffer='',success=false;const layers=new Map();
  const consume=line=>{if(!line.trim())return;const data=JSON.parse(line);if(data.error)throw Error(data.error);if(data.digest&&data.total)layers.set(data.digest,{total:data.total,completed:data.completed||0});const values=[...layers.values()],total=values.reduce((n,v)=>n+v.total,0),completed=values.reduce((n,v)=>n+v.completed,0);this.job.progress=total?Math.min(99,Math.floor(completed/total*100)):0;this.job.downloadedBytes=completed;this.job.totalBytes=total;this.job.message=data.status==='success'?'Download completato':data.status?.startsWith('pulling')?'Scarico il modello…':data.status?.includes('verifying')?'Verifico il download…':'Preparo il modello…';if(data.status==='success')success=true;};
  for await(const chunk of response.body){buffer+=decoder.decode(chunk,{stream:true});if(buffer.length>2*1024*1024)throw Error('Risposta download non valida');let at;while((at=buffer.indexOf('\n'))>=0){consume(buffer.slice(0,at));buffer=buffer.slice(at+1);}}
  buffer+=decoder.decode();consume(buffer);if(!success)throw Error('Download interrotto prima del completamento. Riprova per riprenderlo.');
  return {model};
 }
 async test(model,signal){
  const models=(await this.api('tags')).models||[];if(!models.some(m=>m.name===model))throw Error('Scarica il modello prima di eseguire la prova');
  const start=Date.now(),data=await this.api('chat',{model,stream:false,messages:[{role:'user',content:'Rispondi in italiano con una sola frase breve: sei pronto per aiutarmi?'}],options:{num_ctx:8192,num_predict:40,temperature:0,...(process.env.ATLANTE_GPU==='0'?{num_gpu:0}:{})},keep_alive:'15m'},AbortSignal.any([signal,AbortSignal.timeout(300000)]));
  if(!data.message?.content?.trim())throw Error('Il modello non ha restituito una risposta');
  let acceleration='Non verificata';try{const loaded=(await this.api('ps')).models?.find(m=>(m.name||m.model)===model);if(loaded)acceleration=loaded.size_vram>0?'GPU utilizzata, almeno in parte':'CPU';}catch{}
  this.job.message='Verifico i componenti installati…';
  const components=await this.verifyComponents(signal);
  const result={model,answer:data.message.content.trim(),seconds:(Date.now()-start)/1000,tokensPerSecond:data.eval_duration?data.eval_count/(data.eval_duration/1e9):null,acceleration,components};this.tested=result;return result;
 }
 async saveConfig(next){await mkdir(join(this.root,'data'),{recursive:true});const temp=this.file+'.'+randomUUID()+'.tmp';await writeFile(temp,JSON.stringify(next,null,2));await rename(temp,this.file);this.config=next;return this.config;}
 async finish(model){this.validateModel(model);if(!this.tested||this.tested.model!==model)throw Error('Esegui prima una prova riuscita del modello scelto');if(this.isBusy())throw Error('Attendi la fine della prova');return this.saveConfig({completed:true,defaultModel:model,completedAt:new Date().toISOString()});}
}
