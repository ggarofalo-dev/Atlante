import {encodeWav,joinSamples} from './audio-codec.js';
import {SpeechTurn} from './speech-turn.js';
export function createVoice({onBusy,onText,canStart=()=>true}){
 const $=id=>document.getElementById(id),mic=$('mic'),status=$('voice-status'),cancel=$('voice-cancel'),stop=$('voice-stop'),talk=$('voice-conversation');
 let phase='idle',conversation=false,token=0,context,stream,processor,timer,abort,audio,url,source,flush,resumeTimer;
 let chunks=[],listening=false,turn=new SpeechTurn();
 const say=text=>{status.textContent=text;};
 const capture=()=>['requesting','listening','recording','transcribing'].includes(phase);
 function state(next){phase=next;onBusy(capture()||(conversation&&next==='speaking'));cancel.hidden=!capture();mic.setAttribute('aria-pressed',String(['listening','recording'].includes(next)));const micLabel=['listening','recording'].includes(next)?'Termina la registrazione vocale':'Registra messaggio vocale';mic.setAttribute('aria-label',micLabel);mic.title=micLabel;talk.setAttribute('aria-pressed',String(conversation));const talkLabel=conversation?'Termina conversazione vocale':'Avvia conversazione vocale';talk.setAttribute('aria-label',talkLabel);talk.title=talkLabel;}
 function mute(value){listening=!value;stream?.getTracks().forEach(track=>{track.enabled=!value;});}
 function stopReading(){abort?.abort();if(source){source.onended=null;try{source.stop();}catch{}source=null;}audio?.pause();audio=null;if(url)URL.revokeObjectURL(url);url=null;stop.hidden=true;clearTimeout(resumeTimer);}
 async function release(){clearInterval(timer);mute(true);stream?.getTracks().forEach(t=>t.stop());stream=null;processor=null;const old=context;context=null;await old?.close().catch(()=>{});}
 async function end(message='Conversazione vocale terminata.'){
  token++;conversation=false;stopReading();await release();state('idle');say(message);
 }
 function resume(){if(!conversation||!context||!stream)return;turn=new SpeechTurn();chunks=[];mute(false);state('listening');say('Ti ascolto · parla e fai una pausa per inviare.');}
 function resumeAfterSpeech(){stop.hidden=true;if(conversation){mute(true);say('Torno ad ascoltare…');resumeTimer=setTimeout(resume,450);}else{state('idle');say('');}}
 cancel.onclick=()=>end(conversation?'Conversazione vocale terminata.':'Registrazione annullata.');
 stop.onclick=()=>{stopReading();if(conversation)resumeAfterSpeech();else{state('idle');say('Lettura interrotta.');}};
 async function available(){const r=await fetch('/api/voice/status'),config=await r.json();if(!r.ok)throw Error(config.error);if(!config.transcription)throw Error('Trascrizione locale non installata.');if(!window.isSecureContext||!navigator.mediaDevices){say('Il microfono richiede HTTPS. ');const a=document.createElement('a');a.href='/voice/setup';a.textContent='Configura la chat vocale';status.append(a);return false;}return true;}
 async function begin(handsFree=false){
  if(!canStart(handsFree)){say('Prima termina la richiesta oppure invia o rimuovi la bozza e gli allegati.');return;}
  stopReading();const current=++token;conversation=handsFree;state('requesting');say('Consenti l’accesso al microfono…');
  try{
   if(!await available()){conversation=false;state('idle');return;}
   if(current!==token)return;context=new AudioContext();await context.resume();await context.audioWorklet.addModule('/recorder-worklet.js');if(current!==token)return;
   const obtained=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
   if(current!==token){obtained.getTracks().forEach(t=>t.stop());return;}stream=obtained;chunks=[];turn=new SpeechTurn();listening=true;
   processor=new AudioWorkletNode(context,'atlante-recorder');processor.port.onmessage=e=>{
    if(e.data.flushed)flush?.();if(!e.data.samples||!listening||!context)return;
    if(conversation){const result=turn.feed(e.data.samples,context.sampleRate);if(result.started&&phase==='listening'){state('recording');say('Sto ascoltando… fai una pausa per inviare.');}if(result.ended){chunks=turn.frames;finish();}}
    else chunks.push(e.data.samples);
   };
   const input=context.createMediaStreamSource(stream),gain=context.createGain();gain.gain.value=0;input.connect(processor).connect(gain).connect(context.destination);
   if(handsFree){resume();return;}
   state('recording');say('Registrazione · premi il microfono per terminare');const started=Date.now();timer=setInterval(()=>{const seconds=Math.floor((Date.now()-started)/1000);say(`Registrazione ${seconds}/60 s · premi il microfono per terminare`);if(seconds>=60)finish();},1000);
  }catch(e){if(current===token)await end(e.name==='NotAllowedError'?'Accesso al microfono negato. Abilitalo nelle impostazioni del sito.':e.message);}
 }
 async function finish(){
  if(!['recording','listening'].includes(phase))return;
  if(conversation&&!turn.started){say('Ti ascolto · non ho ancora sentito una frase.');return;}
  const current=token,handsFree=conversation;clearInterval(timer);state('transcribing');
  if(!handsFree&&processor)await new Promise(resolve=>{flush=resolve;processor.port.postMessage('flush');setTimeout(resolve,500);});
  mute(true);const rate=context?.sampleRate,samples=joinSamples(chunks).slice(0,Math.floor((rate||16000)*60));if(!handsFree)await release();if(current!==token)return;say('Trascrizione locale…');
  try{
   const bytes=encodeWav(samples,rate);let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));abort=new AbortController();
   const r=await fetch('/api/voice/transcribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({audio:btoa(binary)}),signal:abort.signal}),result=await r.json();if(!r.ok)throw Error(result.error);if(current!==token)return;
   state(handsFree?'waiting':'idle');say(handsFree?'Atlante sta preparando la risposta…':'Controlla il testo, poi premi Invia.');onText(result.text,{autoSend:handsFree});
  }catch(e){if(current===token)await end(e.message||'Trascrizione non completata.');}
 }
 mic.onclick=()=>{if(phase==='listening'||phase==='recording')return finish();if(['requesting','transcribing','waiting'].includes(phase))return;if(conversation){stopReading();resumeAfterSpeech();}else begin(false);};
 talk.onclick=()=>conversation?end():begin(true);
 async function read(text,parent){
  stopReading();const current=token,handsFree=conversation;mute(true);state('speaking');abort=new AbortController();const signal=abort.signal;stop.hidden=false;stop.textContent=handsFree?'Interrompi e parla':'Ferma lettura';say('Preparazione della voce locale…');
  try{
   const spoken=text.replace(/```[\s\S]*?```/g,' Codice disponibile nella chat. ').replace(/https?:\/\/\S+/g,'').replace(/[#*_`]/g,'').slice(0,6000);
   const r=await fetch('/api/voice/speak',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:spoken}),signal});if(!r.ok)throw Error((await r.json()).error);const blob=await r.blob();if(signal.aborted||current!==token)return;
   if(handsFree&&conversation&&context){const decoded=await context.decodeAudioData(await blob.arrayBuffer());if(current!==token||signal.aborted)return;source=context.createBufferSource();source.buffer=decoded;source.connect(context.destination);source.onended=()=>{source=null;resumeAfterSpeech();};await context.resume();source.start();say('Atlante sta parlando · microfono in pausa.');}
   else{url=URL.createObjectURL(blob);audio=document.createElement('audio');audio.controls=true;audio.src=url;audio.className='voice-audio';parent.querySelector('.voice-audio')?.remove();parent.append(audio);audio.onended=resumeAfterSpeech;try{await audio.play();say('Lettura della risposta…');}catch{say('Premi play nella risposta per ascoltare.');}}
  }catch(e){if(!signal.aborted&&current===token)await end('Lettura non completata: '+e.message);}
 }
 function add(parent,text,actions=parent){const b=document.createElement('button');b.type='button';b.className='voice-read';b.textContent='Ascolta';b.onclick=async()=>{if(conversation)await end();read(text,parent);};actions.append(b);}
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&conversation)end('Conversazione vocale terminata: pagina non più attiva.');});window.addEventListener('pagehide',()=>end());
 return {get active(){return capture();},get conversational(){return conversation;},get phase(){return phase;},read,add,stopReading,end,fail:message=>end('Conversazione interrotta: '+message)};
}
