import {load} from 'cheerio';
import {randomUUID} from 'node:crypto';
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {join} from 'node:path';
import {readFileSync} from 'node:fs';
const safe=/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/;
const capabilities=['vision','tools','thinking','embedding','audio'];
export function parseLibrary(html){
 const $=load(html),models=new Map();
 $('#repo a[href^="/library/"]').each((_,el)=>{const card=$(el),name=card.attr('href').slice(9);if(!safe.test(name)||!card.find('h2').length)return;const labels=card.find('div.flex.flex-wrap').first().find('span').map((_,s)=>$(s).text().trim()).get(),sizes=labels.filter(v=>/^(?:\d+(?:\.\d+)?x)?\d+(?:\.\d+)?[bm]$|^e\d+b$/i.test(v));const caps=capabilities.filter(v=>labels.includes(v));models.set(name,{id:name+':latest',name,description:card.find('p').first().text().trim().slice(0,1200),capabilities:caps,chat:!caps.includes('embedding'),cloudOnly:labels.includes('cloud')&&!sizes.length,variants:sizes,source:'https://ollama.com/library/'+name});});
 if(!models.size)throw Error('Il catalogo Ollama non contiene modelli leggibili.');return [...models.values()];
}
export function parseVariants(html,name){
 const $=load(html),models=new Map();$('a[href^="/library/"]').each((_,el)=>{const link=$(el),id=link.attr('href').slice(9);if(!id.startsWith(name+':')||!new RegExp('^'+name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+':[a-zA-Z0-9][a-zA-Z0-9._-]*$').test(id))return;const text=link.text()+' '+link.closest('div.group').text();const match=text.match(/(\d+(?:\.\d+)?)\s*(GB|MB|TB)\b/i),bytes=match?Number(match[1])*1024**({MB:2,GB:3,TB:4}[match[2].toUpperCase()]):0;const cloud=/(?:^|[-:])cloud(?:$|-)/i.test(id)||/\bcloud\b/i.test(text)&&!bytes;const record={id,name:id,bytes,cloud,source:'https://ollama.com/library/'+id};if(!models.has(id)||bytes)models.set(id,record);});if(!models.size)throw Error('Varianti del modello non disponibili');return [...models.values()];
}
export class OllamaCatalog{
 constructor({root,request=fetch}){this.root=root;this.request=request;this.file=join(root,'data/ollama-catalog.json');this.models=JSON.parse(readFileSync(new URL('./ollama-catalog.json',import.meta.url),'utf8'));this.checkedAt=null;this.variants=new Map();}
 async initialize(){try{const saved=JSON.parse(await readFile(this.file,'utf8'));if(Array.isArray(saved.models)&&saved.models.every(m=>safe.test(m.id?.split(':')[0]||''))){this.models=saved.models;this.checkedAt=saved.checkedAt;}}catch{}return this;}
 async html(path,signal){const response=await this.request('https://ollama.com'+path,{signal:AbortSignal.any([signal||new AbortController().signal,AbortSignal.timeout(20000)]),redirect:'error'});if(!response.ok)throw Error('Catalogo Ollama non disponibile ('+response.status+')');let html='',size=0;const decoder=new TextDecoder();for await(const chunk of response.body){size+=chunk.length;if(size>12*1024*1024)throw Error('Catalogo Ollama troppo grande');html+=decoder.decode(chunk,{stream:true});}return html+decoder.decode();}
 async refresh(){const models=parseLibrary(await this.html('/library'));const checkedAt=new Date().toISOString();await mkdir(join(this.root,'data'),{recursive:true});const temp=this.file+'.'+randomUUID()+'.tmp';await writeFile(temp,JSON.stringify({models,checkedAt}));await rename(temp,this.file);this.models=models;this.checkedAt=checkedAt;this.variants.clear();return {models,checkedAt};}
 async inspect(name,signal){if(typeof name!=='string'||!safe.test(name))throw Error('Nome famiglia Ollama non valido');const cached=this.variants.get(name);if(cached&&Date.now()-cached.at<15*60000)return cached.result;const family=this.models.find(m=>m.id===name+':latest');const models=parseVariants(await this.html('/library/'+encodeURIComponent(name)+'/tags',signal),name).map(m=>({...family,...m,cloudOnly:m.cloud,downloadGB:m.bytes/1024**3}));const result={models,checkedAt:new Date().toISOString()};this.variants.set(name,{at:Date.now(),result});return result;}
}
