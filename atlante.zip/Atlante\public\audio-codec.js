export function encodeWav(samples,sampleRate){
 if(!Number.isFinite(sampleRate)||sampleRate<16000||sampleRate>192000)throw Error('Frequenza audio non supportata');
 const count=Math.floor(samples.length*16000/sampleRate),buffer=new ArrayBuffer(44+count*2),view=new DataView(buffer);
 const string=(offset,value)=>{for(let i=0;i<value.length;i++)view.setUint8(offset+i,value.charCodeAt(i));};
 string(0,'RIFF');view.setUint32(4,36+count*2,true);string(8,'WAVE');string(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,16000,true);view.setUint32(28,32000,true);view.setUint16(32,2,true);view.setUint16(34,16,true);string(36,'data');view.setUint32(40,count*2,true);
 for(let i=0;i<count;i++){const begin=Math.floor(i*sampleRate/16000),end=Math.min(samples.length,Math.max(begin+1,Math.floor((i+1)*sampleRate/16000)));let sum=0;for(let j=begin;j<end;j++)sum+=samples[j];const value=Math.max(-1,Math.min(1,sum/(end-begin)));view.setInt16(44+i*2,value<0?value*32768:value*32767,true);}
 return new Uint8Array(buffer);
}
export function joinSamples(chunks){const samples=new Float32Array(chunks.reduce((sum,chunk)=>sum+chunk.length,0));let offset=0;for(const chunk of chunks){samples.set(chunk,offset);offset+=chunk.length;}return samples;}
