import https from 'node:https';
import http from 'node:http';
import {lookup} from 'node:dns/promises';
import ipaddr from 'ipaddr.js';
import {load} from 'cheerio';
import {readPdf} from './pdf-text.mjs';

export async function readWebPdf(bytes,address){
 if(bytes.subarray(0,5).toString()!=='%PDF-')throw Error('Il contenuto ricevuto non è un PDF valido.');
 const result=await readPdf(bytes);
 if(!result.text.trim())throw Error('Nessun testo leggibile nel PDF.');
 const url=new URL(address);
 return {title:decodeURIComponent(url.pathname.split('/').findLast(p=>/\.pdf$/i.test(p))||url.hostname),url:url.href,text:result.text.slice(0,24000),links:[],kind:'PDF web letto',ocr:result.ocrPages>0,truncated:result.truncated||result.text.length>24000,warnings:result.warnings};
}

export function publicAddress(address){try{return ipaddr.process(address).range()==='unicast';}catch{return false;}}
export async function readPage(address,redirects=0){
 const url=new URL(address);
 if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.port&&!['80','443'].includes(url.port))throw Error('URL pubblica HTTP/HTTPS richiesta.');
 const hostname=url.hostname.replace(/^\[|\]$/g,'');
 const addresses=await lookup(hostname,{all:true});
 if(!addresses.length||addresses.some(a=>!publicAddress(a.address)))throw Error('Indirizzi locali e reti private non navigabili.');
 const pinned=addresses[0];
 return new Promise((resolve,reject)=>{
  const request=(url.protocol==='https:'?https:http).get(url,{headers:{'User-Agent':'AtlanteLocal/0.2','Accept':'text/html,text/plain,application/pdf'},lookup:(_h,options,cb)=>options.all?cb(null,[pinned]):cb(null,pinned.address,pinned.family)},res=>{
   if([301,302,303,307,308].includes(res.statusCode)){res.resume();if(redirects>=4)return reject(Error('Troppi reindirizzamenti'));if(!res.headers.location)return reject(Error('Redirect senza destinazione'));return readPage(new URL(res.headers.location,url).href,redirects+1).then(resolve,reject);}
   if(res.statusCode!==200){res.resume();return reject(Error('Pagina HTTP '+res.statusCode));}
   const pdf=/^application\/pdf(?:;|$)/i.test(res.headers['content-type']||'');
   if(!pdf&&!/text\/(html|plain)|application\/xhtml\+xml/.test(res.headers['content-type']||'')){res.resume();return reject(Error('La URL deve restituire HTML, testo o PDF.'));}
   let size=0;const chunks=[];res.on('data',chunk=>{size+=chunk.length;if(size>(pdf?10000000:2000000)){res.destroy(Error(pdf?'PDF troppo grande (massimo 10 MB)':'Pagina troppo grande'));return;}chunks.push(chunk);});res.on('error',reject);
   if(pdf){res.on('end',()=>readWebPdf(Buffer.concat(chunks),url.href).then(resolve,reject));return;}
   res.on('end',()=>{try{const html=Buffer.concat(chunks).toString('utf8');const $=load(html);const linkDocument=load(html);$('script,style,noscript,svg,nav,footer,header').remove();const title=$('title').text().trim()||url.hostname;const content=$('main,article').first();const text=(content.length?content.text():$('body').text()).replace(/\s+/g,' ').trim().slice(0,24000);const links=[];linkDocument('a[href]').each((_i,a)=>{try{const target=new URL(linkDocument(a).attr('href'),url);target.hash='';if(['https:','http:'].includes(target.protocol)&&!links.some(l=>l.url===target.href))links.push({title:linkDocument(a).text().trim().slice(0,160)||target.href,url:target.href});}catch{}});if(!text)throw Error('Nessun testo leggibile: il sito potrebbe richiedere JavaScript o login.');resolve({title,url:url.href,text,links:links.slice(0,60)});}catch(e){reject(e);}});
  });const deadline=setTimeout(()=>request.destroy(Error('Timeout totale pagina')),20000);request.on('close',()=>clearTimeout(deadline));request.setTimeout(15000,()=>request.destroy(Error('Timeout pagina')));request.on('error',reject);
 });
}
export async function browse(url,{follow=false,query='',reader=readPage}={}){
 const pages=[],errors=[];let first;
 try{first=await reader(url);pages.push(first);}catch(e){return {pages,errors:[{url,error:e.message}]};}
 if(follow){const terms=query.toLowerCase().match(/[\p{L}]{4,}/gu)||[];const candidates=first.links.filter(l=>new URL(l.url).origin===new URL(first.url).origin&&l.url!==first.url);candidates.sort((a,b)=>terms.filter(t=>b.title.toLowerCase().includes(t)).length-terms.filter(t=>a.title.toLowerCase().includes(t)).length);for(const link of candidates.slice(0,3)){try{pages.push(await reader(link.url));}catch(e){errors.push({url:link.url,error:e.message});}}}
 return {pages,errors};
}
