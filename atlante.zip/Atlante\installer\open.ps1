$root = Split-Path -Parent $PSScriptRoot
try { $null = Invoke-RestMethod 'http://127.0.0.1:3210/api/health' -TimeoutSec 2 } catch {
    Start-Process powershell.exe -ArgumentList ('-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + "$root\scripts\run-background.ps1" + '"') -WindowStyle Hidden
    for ($i=0;$i -lt 60;$i++) {
        try { $null = Invoke-RestMethod 'http://127.0.0.1:3210/api/health' -TimeoutSec 2; break } catch { Start-Sleep -Seconds 1 }
    }
}
Start-Process 'http://localhost:3210'
