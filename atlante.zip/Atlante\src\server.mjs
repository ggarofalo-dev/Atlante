import {externalServiceRequest,currentDateAnswer,externalDiscussion,localImageRequest,previousImageRequest} from './external-intent.mjs';
import {installGoogleWorkspace} from './google-workspace.mjs';
import {installGoogleCalendar} from './google-calendar.mjs';
import {startDesktopOAuth} from './oauth-desktop.mjs';
import {AttachmentSearch} from './document-retrieval.mjs';
import {ocrAvailable} from './ocr.mjs';
import {deviceLinks} from './devices.mjs';
import {liveSearch,wantsWeb} from './live-web.mjs';
import {completeKnowledge,webForbidden,publicKnowledgeRequest,combineKnowledgeSources} from './automatic-web.mjs';
import {chatGpuOptions,withChatGpu} from './chat-gpu.mjs';
import {conversationIntent,appReference} from './conversation-intent.mjs';
import http from 'node:http';
import https from 'node:https';
import {X509Certificate} from 'node:crypto';
import {hostname,networkInterfaces} from 'node:os';
import {mkdirSync,readFileSync,readdirSync,statSync,existsSync} from 'node:fs';
import {execFile} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {Store} from './store.mjs';
import {installDefaultKnowledge} from './default-knowledge.mjs';
import {Auth} from './auth.mjs';
import {Profiles} from './profiles.mjs';
import {assistants,assistant,saveAssistant,removeAssistant,sessionAssistant,notes,note,saveNote,removeNote,rewriteNote} from './workspace.mjs';
import {parseDataset,stageDataset,getDataset,bindDatasets,sessionDataset,profile,analyze,planAnalysis,analysisMarkdown} from './data-analysis.mjs';
import {Integrations} from './integrations.mjs';
import {importOpenApi} from './openapi.mjs';
import {Collaboration} from './collaboration.mjs';
import {Codeg} from './codeg.mjs';
import {Diagnostics} from './diagnostics.mjs';
import {ModelManager} from './model-manager.mjs';
import {Setup} from './setup.mjs';
import {ImageRuntime} from './image-runtime.mjs';
import {ImageModels} from './image-models.mjs';
import {verifySetupComponents} from './setup-checks.mjs';
import {RequestQueue} from './request-queue.mjs';
import {streamChat} from './ollama-stream.mjs';
import {Knowledge,embeddingModel} from './knowledge.mjs';
import {Maintenance} from './maintenance.mjs';
import {updateConversation,listConversations,projects,saveProject,assignProject,branchConversation,exportConversations,importConversations} from './conversations.mjs';
import {ResponseSettings,RESPONSE_PRESETS} from './response-settings.mjs';
import {chat,ollama} from './engine.mjs';
import {research} from './research.mjs';
import {browse} from './browser.mjs';
import {createArtifact,artifactRoot,deleteImageArtifact,saveArtifact} from './artifacts.mjs';
import {analyzeImage,editImage,decodeImage} from './images.mjs';
import {readAttachment} from './attachments.mjs';
import {chooseTool,requestedFormat,imagePrompt,resolveTool,imageToolsModel} from './tools.mjs';
import {generateImage,diffusionAvailable,imageSettings} from './diffusion.mjs';
import {voiceAvailable,transcribe,speak,speechVoices,maxVoiceSeconds} from './voice.mjs';
import {ensureTls} from './tls.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
mkdirSync(root+'data',{recursive:true});
mkdirSync(artifactRoot,{recursive:true});
const legacyStore=new Store(root+'data/atlante.sqlite');
installDefaultKnowledge(legacyStore);
const auth=new Auth(root+'data/auth.sqlite');await auth.initialize();
if(!auth.db.prepare("SELECT 1 FROM auth_meta WHERE key='legacy-artifacts'").get()){
 for(const name of readdirSync(artifactRoot))if(/^[a-f0-9-]{36}\.(docx|xlsx|pptx|pdf|txt|png)$/.test(name))auth.own('/artifacts/'+name,'admin');
 auth.db.prepare('INSERT INTO auth_meta VALUES(?,?)').run('legacy-artifacts','1');
}
function ownResult(result,user){for(const artifact of [result?.artifact,result?.originalArtifact])if(artifact)auth.own(artifact.url,user.id);return result;}
const port=Number(process.env.PORT||3210);
const httpsPort=Number(process.env.HTTPS_PORT||3212);
let tls=null,httpsReady=false;
try{tls=await ensureTls();}catch(e){console.error('HTTPS non disponibile:',e.message);}
let busy=false,maintenance;
const requests=new RequestQueue({blocked:()=>busy||!!maintenance?.running});
const knowledge=new Knowledge(legacyStore);
const attachmentSearch=new AttachmentSearch(knowledge);
const setup=new Setup({root,isBusy:()=>busy||!!requests.active||!!requests.pending.length,lock:()=>{busy=true;},unlock:()=>{busy=false;},capabilities:()=>({ocr:ocrAvailable(),transcription:voiceAvailable(),images:diffusionAvailable(),https:httpsReady}),verifyComponents:signal=>verifySetupComponents(root,signal)});
await setup.initialize();
const imageRuntime=new ImageRuntime({root,settings:imageSettings,isBusy:()=>busy||!!requests.active||!!requests.pending.length||!!maintenance?.running,lock:()=>{busy=true;},unlock:()=>{busy=false;}});
const modelManager=new ModelManager({setup,queue:requests});
const integrations=new Integrations({auth,root});
installGoogleCalendar(integrations,root);
installGoogleWorkspace(integrations,root);
const imageModels=await new ImageModels({root,settings:imageSettings,encrypt:value=>integrations.encrypt(value),decrypt:value=>integrations.decrypt(value),hardware:async()=>(await setup.status()).hardware,isBusy:()=>busy||!!requests.active||!!requests.pending.length||!!maintenance?.running,lock:()=>{busy=true;},unlock:()=>{busy=false;}}).initialize();
imageModels.prepare=async signal=>{await startLocalComfy();let loaded;try{loaded=await ollama('ps',undefined,signal);}catch{}for(const model of loaded?.models||[])await ollama('generate',{model:model.name,keep_alive:0},signal);};
const responseSettings=new ResponseSettings(root);
const diagnostics=new Diagnostics({setup,models:modelManager,queue:requests,components:signal=>verifySetupComponents(root,signal),https:()=>httpsReady});
const profiles=new Profiles({root,auth,legacyStore,isBusy:()=>busy||!!requests.active||!!requests.pending.length,execute:async(input,store,user)=>requests.submit(user.id,async signal=>ownResult(await executeChat(input,store,{signal,user}),user),{label:'Prompt programmato',session:input.session}).promise});
const collaboration=new Collaboration({auth,profiles});
const codeg=new Codeg(auth.db);
async function startLocalComfy(){if(!existsSync(root+'runtime/comfyui/ComfyUI_windows_portable/python_embeded/python.exe'))throw Error('ComfyUI non è installato su questo PC');return new Promise((resolve,reject)=>execFile(process.execPath,[root+'scripts/start-comfyui.mjs'],{cwd:root,windowsHide:true,timeout:10000},(e,stdout)=>e?reject(e):resolve({message:stdout.trim()})));}
if(imageSettings.get().backend==='comfyui'&&imageSettings.get().url==='http://127.0.0.1:8188'&&existsSync(root+'runtime/comfyui/ComfyUI_windows_portable/python_embeded/python.exe'))startLocalComfy().catch(e=>console.error('ComfyUI:',e.message));
maintenance=new Maintenance({root,auth,stores:()=>[{path:root+'data/auth.sqlite',db:auth.db},{path:root+'data/atlante.sqlite',db:legacyStore.db},...[...profiles.entries].filter(([id])=>id!=='admin').map(([id,p])=>({path:root+'data/users/'+id+'.sqlite',db:p.store.db}))],isBusy:()=>busy||!!requests.active||!!requests.pending.length});
const handler=async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'");
  res.setHeader('Permissions-Policy','microphone=(self)');
  let user=null;
  res.setHeader('Cache-Control','no-store');
  const send=(status,data)=>{if(user&&status===200)ownResult(data,user);const payload=JSON.stringify(data);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(payload);};
  try{
    const requestPort=req.socket.encrypted?httpsPort:port;
    const protocol=req.socket.encrypted?'https':'http';
    const allowedHosts=new Set(['localhost','127.0.0.1','0.0.0.0',hostname().toLowerCase(),...Object.values(networkInterfaces()).flat().filter(a=>a?.family==='IPv4').map(a=>a.address)].map(host=>`${host}:${requestPort}`));
    if(!allowedHosts.has(req.headers.host?.toLowerCase()))return send(403,{error:'Host non consentito'});
    if(req.headers.origin&&req.headers.origin!==`${protocol}://${req.headers.host}`)return send(403,{error:'Origine non consentita'});
    const path=new URL(req.url,'http://localhost').pathname;
    const appIcons={'/icons/atlante.svg':['icons/atlante.svg','image/svg+xml'],'/icons/atlante-32.png':['icons/atlante-32.png','image/png'],'/icons/atlante-180.png':['icons/atlante-180.png','image/png'],'/apple-touch-icon.png':['icons/atlante-180.png','image/png'],'/icons/atlante-192.png':['icons/atlante-192.png','image/png'],'/icons/atlante-512.png':['icons/atlante-512.png','image/png'],'/icons/atlante-maskable-512.png':['icons/atlante-maskable-512.png','image/png'],'/app.webmanifest':['app.webmanifest','application/manifest+json']};
    if(req.method==='GET'&&appIcons[path]){const [file,type]=appIcons[path];res.writeHead(200,{'Content-Type':type});return res.end(readFileSync(root+'public/'+file));}
    if(req.method==='GET'&&path==='/theme.css'){res.writeHead(200,{'Content-Type':'text/css; charset=utf-8'});return res.end(readFileSync(root+'public/theme.css'));}
    if(req.method==='GET'&&path==='/api/health')return send(200,{app:'atlante',pid:process.pid,maintenance:(()=>{const state=maintenance.status().latest;return state?{id:state.id,state:state.state}:null;})(),busy:busy||!!requests.active,scheduled:[...profiles.entries.values()].some(p=>p.scheduler.running),https:httpsReady});
    const publicAssets={'/login':['login.html','text/html'],'/login.js':['login.js','text/javascript'],'/style.css':['style.css','text/css'],'/voice/setup':['voice-help.html','text/html'],'/voice-help.js':['voice-help.js','text/javascript'],'/voice-help.css':['voice-help.css','text/css']};
    if(req.method==='GET'&&publicAssets[path]){const [file,type]=publicAssets[path];res.writeHead(200,{'Content-Type':type+'; charset=utf-8'});return res.end(readFileSync(root+'public/'+file));}
    if(req.method==='GET'&&path==='/voice/atlante-local-ca.crt'&&tls){res.writeHead(200,{'Content-Type':'application/x-x509-ca-cert','Content-Disposition':'attachment; filename="atlante-local-ca.crt"'});return res.end(new X509Certificate(tls.ca).raw);}
    if(req.method==='POST'&&path==='/api/auth/login'){
     if(!req.headers['content-type']?.startsWith('application/json'))return send(415,{error:'Richiesto JSON'});
     let body='',size=0;for await(const chunk of req){size+=chunk.length;if(size>4096)return send(413,{error:'Dati troppo grandi'});body+=chunk;}
     try{const input=JSON.parse(body),login=await auth.login(input.username,input.password,req.socket.remoteAddress);res.setHeader('Set-Cookie',auth.cookie(req,login.token));return send(200,{user:login.user});}catch(e){return send(401,{error:e.message});}
    }
    if(req.method==='GET'&&path==='/api/oauth/callback'){const q=new URL(req.url,'http://localhost').searchParams,nonce=(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('atlante_oauth='))?.slice(14)||'';let ok=false;try{await integrations.accounts.callback(q.get('state'),q.get('code'),nonce);ok=true;}catch{}res.setHeader('Set-Cookie','atlante_oauth=; Path=/api/oauth/callback; HttpOnly; SameSite=Lax; Max-Age=0'+(req.socket.encrypted?'; Secure':''));res.writeHead(302,{Location:ok?'/?account=connected':'/?account=failed'});return res.end();}
    user=auth.authenticate(req);
    if(!user){if(req.method==='GET'&&path==='/'){res.writeHead(302,{Location:'/login'});return res.end();}return send(401,{error:'Accedi per continuare'});}
    if(path.startsWith('/api/auth/api-token')){
      if(req.headers.authorization!==undefined||!auth.authenticateSession(req))return send(403,{error:'Gestisci il token dal tuo account nella pagina web'});
      if(req.method==='GET'&&path==='/api/auth/api-token')return send(200,{key:auth.apiToken(user.id),token:auth.recoverApiToken(user.id)});
      if(req.method==='POST'&&['/api/auth/api-token/create','/api/auth/api-token/renew','/api/auth/api-token/revoke'].includes(path)){
        if(!req.headers['content-type']?.startsWith('application/json'))return send(415,{error:'Richiesto JSON'});
        let size=0;for await(const chunk of req){size+=chunk.length;if(size>4096)return send(413,{error:'Dati troppo grandi'});}
        if(path.endsWith('/create'))return send(200,auth.createApiToken(user.id));
        if(path.endsWith('/renew'))return send(200,auth.createApiToken(user.id,{renew:true}));
        auth.revokeApiToken(user.id);return send(200,{ok:true});
      }
      return send(404,{error:'Non trovato'});
    }
    const {store,scheduler}=profiles.get(user);
    const requireAdmin=()=>{if(!user.admin)throw Object.assign(Error('Permesso admin richiesto'),{status:403});};
    const requireLibrary=()=>{if(!user.admin&&!user.library)throw Object.assign(Error('Gestione biblioteca non abilitata'),{status:403});};
    if(req.method==='GET'){
      if(path==='/api/codeg'){requireAdmin();return send(200,{sessions:codeg.list(user.id)});}
      if(path==='/api/codeg/session'){requireAdmin();return send(200,codeg.get(new URL(req.url,'http://localhost').searchParams.get('id'),user.id));}
      if(path==='/codeg.js'){res.writeHead(200,{'Content-Type':'text/javascript; charset=utf-8'});return res.end(readFileSync(root+'public/codeg.js'));}
      if(path==='/image-studio.js'){res.writeHead(200,{'Content-Type':'text/javascript; charset=utf-8'});return res.end(readFileSync(root+'public/image-studio.js'));}
      if(path==='/image-studio.css'){res.writeHead(200,{'Content-Type':'text/css; charset=utf-8'});return res.end(readFileSync(root+'public/image-studio.css'));}
      if(path==='/sidebar.js'){res.writeHead(200,{'Content-Type':'text/javascript; charset=utf-8'});return res.end(readFileSync(root+'public/sidebar.js'));}
      if(path==='/sidebar.css'){res.writeHead(200,{'Content-Type':'text/css; charset=utf-8'});return res.end(readFileSync(root+'public/sidebar.css'));}
      if(path==='/api/sharing')return send(200,{items:collaboration.list(user),candidates:collaboration.candidates(user),...collaboration.directory(user)});
      if(path==='/api/shared'){const q=new URL(req.url,'http://localhost').searchParams;return send(200,collaboration.get(q.get('id'),user,q.get('session')));}
      if(path==='/api/groups')return send(200,{groups:collaboration.groups(user)});
      if(path==='/api/integrations')return send(200,{connections:integrations.list(user),pending:integrations.pending(user)});
      if(path==='/api/integrations/audit'){requireAdmin();return send(200,auth.db.prepare('SELECT * FROM integration_audit ORDER BY created DESC LIMIT 100').all());}
      if(path==='/api/assistants')return send(200,{assistants:assistants(store)});
      if(path==='/api/assistant')return send(200,assistant(store,new URL(req.url,'http://localhost').searchParams.get('id')));
      if(path==='/api/response-settings'){requireAdmin();let voices=[],voiceError='';try{voices=await speechVoices();}catch(e){voiceError=e.message;}return send(200,{settings:responseSettings.get(),presets:RESPONSE_PRESETS,voices,voiceError});}
      if(path==='/api/notes')return send(200,{notes:notes(store)});
      if(path==='/api/note'){const q=new URL(req.url,'http://localhost').searchParams;return send(200,note(store,q.get('id'),Number(q.get('version'))||undefined));}
      if(path==='/api/dataset')return send(200,profile(getDataset(store,new URL(req.url,'http://localhost').searchParams.get('id'))));
      if(path==='/api/auth/me')return send(200,{user});
      if(path==='/api/diagnostics'){requireAdmin();return send(200,await diagnostics.status());}
      if(path==='/api/image/models'){requireAdmin();return send(200,await imageModels.status());}
      if(path==='/api/models'){requireAdmin();return send(200,await modelManager.status(user.id));}
      if(path==='/api/setup'){requireAdmin();const state=await setup.status();return send(200,{...state,images:{...await imageRuntime.status(state.hardware),modelJob:imageModels.job}});}
      if(path==='/api/maintenance'){requireAdmin();return send(200,maintenance.status());}
      if(path==='/api/maintenance/backup'){requireAdmin();const bytes=maintenance.backup();res.writeHead(200,{'Content-Type':'application/zip','Content-Disposition':'attachment; filename="Atlante-backup-'+new Date().toISOString().slice(0,10)+'.zip"'});return res.end(bytes);}
      if(path==='/api/knowledge'){requireLibrary();return send(200,knowledge.status());}
      if(path==='/api/projects')return send(200,projects(store));
      if(path==='/api/conversations/export'){const archive=exportConversations(store,new URL(req.url,'http://localhost').searchParams.get('session'));res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Content-Disposition':'attachment; filename="Atlante-conversazioni.json"'});return res.end(JSON.stringify(archive));}
      if(path==='/api/jobs')return send(200,[...requests.jobs.values()].filter(j=>j.owner===user.id).map(j=>requests.public(j)));
      const jobMatch=path.match(/^\/api\/jobs\/([a-f0-9-]{36})(\/events)?$/);
      if(jobMatch){const job=requests.get(jobMatch[1],user.id);if(!jobMatch[2])return send(200,requests.public(job));res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-store','Connection':'keep-alive'});const write=event=>{if(!res.destroyed)res.write('data: '+JSON.stringify(event)+'\n\n');};for(const event of job.events)write(event);if(['done','error','cancelled'].includes(job.state))return res.end();const listener=event=>{write(event);if(['done','error','cancelled'].includes(event.kind))res.end();};job.listeners.add(listener);const heartbeat=setInterval(()=>{if(!res.destroyed)res.write(': keepalive\n\n');},10000);res.on('close',()=>{clearInterval(heartbeat);job.listeners.delete(listener);});return;}
      if(path==='/api/users'){requireAdmin();return send(200,{users:auth.users()});}
      
      if(path==='/api/devices')return send(200,{devices:await deviceLinks({port:requestPort,protocol,preferred:req.socket.localAddress})});
      if(path==='/api/voice/status')return send(200,{transcription:voiceAvailable(),speech:process.platform==='win32',maxSeconds:maxVoiceSeconds,httpsUrl:httpsReady?`https://${req.headers.host.split(':')[0]}:${httpsPort}`:null,certificateUrl:'/voice/atlante-local-ca.crt',fingerprint:tls?new X509Certificate(tls.ca).fingerprint256:null});
      if(path==='/voice/atlante-local-ca.crt'&&tls){res.writeHead(200,{'Content-Type':'application/x-x509-ca-cert','Content-Disposition':'attachment; filename="atlante-local-ca.crt"'});return res.end(new X509Certificate(tls.ca).raw);}
      if(path==='/api/prompts')return send(200,scheduler.status());
      if(path==='/api/image/settings'){requireAdmin();return send(200,{settings:imageSettings.get(),sdModels:imageSettings.sdModels()});}
      if(path==='/api/image/options'){const s=imageSettings.get();return send(200,{...imageModels.choices(),...Object.fromEntries(['backend','checkpoint','sdModel','width','height','steps','cfg','seed','strength','negative','sampler','scheduler'].map(k=>[k,s[k]]))});}
      if(path==='/api/images'){const metadata=new Map(store.imageMetadata().map(item=>[item.url,item]));return send(200,readdirSync(artifactRoot).filter(name=>/^[a-f0-9-]{36}\.png$/.test(name)&&auth.owns('/artifacts/'+name,user.id)).map(name=>{const url='/artifacts/'+name;return metadata.get(url)||{url,name:'Immagine salvata.png',prompt:'',created:statSync(artifactRoot+name).mtime.toISOString(),session:null};}).sort((a,b)=>b.created.localeCompare(a.created)));}
      if(path==='/api/status'){let models=[],error=null;try{models=(await modelManager.installed()).filter(m=>m.chat).map(m=>m.name);}catch(e){error=e.message;}return send(200,{defaultModel:setup.config.defaultModel,models,error,documents:legacyStore.list().filter(d=>d.kind==='document').length,capabilities:{ocr:ocrAvailable(),browse:true,formats:['docx','xlsx','pptx','pdf','txt'],vision:models.some(m=>m.startsWith('gemma3:4b')),imageEditing:true,imageGeneration:diffusionAvailable()}});}
      if(/^\/artifacts\/[a-f0-9-]{36}\.(docx|xlsx|pptx|pdf|txt|png)$/.test(path)){
        if(!auth.owns(path,user.id)&&!collaboration.artifact(path,user))return send(404,{error:'File non trovato'});const name=path.split('/').pop();const bytes=readFileSync(artifactRoot+name);const png=name.endsWith('.png');res.writeHead(200,{'Content-Type':png?'image/png':'application/octet-stream','Content-Disposition':`${png?'inline':'attachment'}; filename="${name}"`});return res.end(bytes);
      }
      if(path==='/api/documents'){requireLibrary();return send(200,legacyStore.list().filter(d=>d.kind==='document'));}
      if(path==='/api/sessions'){const p=new URL(req.url,'http://localhost').searchParams;return send(200,listConversations(store,{query:(p.get('q')||'').slice(0,200),project:p.get('project')||''}));}
      if(path==='/api/conversation')return send(200,store.conversation(new URL(req.url,'http://localhost').searchParams.get('session')||''));
      if(path==='/api/document'){requireLibrary();const doc=legacyStore.document(new URL(req.url,'http://localhost').searchParams.get('id')||'');return send(doc?.kind==='document'?200:404,doc?.kind==='document'?doc:{error:'Documento non trovato'});}
      const assets={'/api-access.js':['api-access.js','text/javascript'],'/response-settings.js':['response-settings.js','text/javascript'],'/integration-guides.js':['integration-guides.js','text/javascript'],'/collaboration.js':['collaboration.js','text/javascript'],'/integrations.js':['integrations.js','text/javascript'],'/workspace.js':['workspace.js','text/javascript'],'/diagnostics.js':['diagnostics.js','text/javascript'],'/model-library.js':['model-library.js','text/javascript'],'/model-profiles.js':['model-profiles.js','text/javascript'],'/models.js':['models.js','text/javascript'],'/rich-chat.js':['rich-chat.js','text/javascript'],'/organize.js':['organize.js','text/javascript'],'/maintenance.js':['maintenance.js','text/javascript'],'/vendor/markdown-it.min.js':['vendor/markdown-it.min.js','text/javascript'],'/vendor/purify.min.js':['vendor/purify.min.js','text/javascript'],'/vendor/highlight.min.js':['vendor/highlight.min.js','text/javascript'],'/vendor/highlight.css':['vendor/highlight.css','text/css'],'/image-models.js':['image-models.js','text/javascript'],'/setup.js':['setup.js','text/javascript'],'/auth.js':['auth.js','text/javascript'],'/devices.js':['devices.js','text/javascript'],'/':['index.html','text/html'],'/app.js':['app.js','text/javascript'],'/prompts.js':['prompts.js','text/javascript'],'/style.css':['style.css','text/css'],'/voice.js':['voice.js','text/javascript'],'/conversation-voice.js':['conversation-voice.js','text/javascript'],'/speech-turn.js':['speech-turn.js','text/javascript'],'/audio-codec.js':['audio-codec.js','text/javascript'],'/recorder-worklet.js':['recorder-worklet.js','text/javascript'],'/voice/setup':['voice-help.html','text/html'],'/voice-help.js':['voice-help.js','text/javascript'],'/voice-help.css':['voice-help.css','text/css']};
      if(assets[path]){res.writeHead(200,{'Content-Type':assets[path][1]+'; charset=utf-8'});return res.end(readFileSync(root+'public/'+assets[path][0]));}
      return send(404,{error:'Non trovato'});
    }
    if(req.method!=='POST')return send(405,{error:'Metodo non supportato'});
    if(maintenance.running)return send(503,{error:'Manutenzione in corso. Attendi il riavvio.'});
    if(path==='/api/maintenance/upload'){requireAdmin();if(!req.headers['content-type']?.startsWith('application/zip'))return send(415,{error:'Carica uno ZIP'});const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>256*1024*1024)return send(413,{error:'ZIP massimo 256 MB'});chunks.push(chunk);}return send(200,maintenance.stage(new URL(req.url,'http://localhost').searchParams.get('kind'),Buffer.concat(chunks)));}
    if(!req.headers['content-type']?.startsWith('application/json'))return send(415,{error:'Richiesto JSON'});
    let body='',bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>16000000)return send(413,{error:'Dati troppo grandi'});body+=chunk;}
    const input=JSON.parse(body);
    if(path==='/api/image/settings'){requireAdmin();if(busy||requests.active||requests.pending.length)throw Error('Attendi il completamento delle operazioni');return send(200,imageSettings.save(input));}
    if(path==='/api/image/models/token'){requireAdmin();return send(200,await imageModels.saveToken(input.token));}
    if(path==='/api/image/models/updates'){requireAdmin();return send(200,await imageModels.updates());}
    if(path==='/api/image/models/search'){requireAdmin();return send(200,await imageModels.search(input.query,input.sort,input.cursor));}
    if(path==='/api/image/models/inspect'){requireAdmin();return send(200,await imageModels.inspect(input.repo));}
    if(path==='/api/image/models/download'){requireAdmin();return send(200,imageModels.start('download',input));}
    if(path==='/api/image/models/activate'){requireAdmin();return send(200,imageModels.start('activate',input));}
    if(path==='/api/image/models/delete'){requireAdmin();return send(200,await imageModels.remove(input.local));}
    if(path==='/api/image/models/cancel'){requireAdmin();imageModels.cancel();return send(200,{ok:true});}
    if(path==='/api/image/catalog'){requireAdmin();return send(200,await imageSettings.catalog(input.url,AbortSignal.timeout(15000)));}
    if(path==='/api/image/start'){requireAdmin();return send(200,await startLocalComfy());}
    if(path==='/api/image/jobs'){
      if(typeof input.prompt!=='string'||!input.prompt.trim()||input.prompt.length>2000)throw Error('Descrizione richiesta, massimo 2000 caratteri');
      const job=requests.submit(user.id,async(signal,delta,progress)=>{progress('Preparazione descrizione con '+imageToolsModel);const prompt=await imagePrompt(input.prompt,(path,body)=>ollama(path,body,signal),imageToolsModel);progress('Generazione immagine locale');const artifact=await generateImage({...input,prompt},signal,progress,imageModels.configuration(input.imageModel));signal.throwIfAborted();auth.own(artifact.url,user.id);store.imageResult({artifact,prompt:input.prompt,session:'image-studio-'+crypto.randomUUID(),remember:input.remember!==false});return {artifact};},{label:'Generazione immagine locale'});return send(200,{id:job.id});
    }
    if(path==='/api/codeg/create'){requireAdmin();return send(200,codeg.create(user.id,{...input,model:input.model||setup.config.defaultModel}));}
    if(path==='/api/codeg/revoke'){requireAdmin();return send(200,codeg.revoke(user.id,input.id));}
    if(path==='/api/codeg/run'){requireAdmin();codeg.get(input.id,user.id);const job=requests.submit(user.id,(signal,delta,progress)=>codeg.run(user.id,input,ollama,signal,progress),{label:'Codeg',session:input.id});return send(200,{id:job.id});}
    if(path==='/api/codeg/undo'){requireAdmin();if(requests.active||requests.pending.length)throw Error('Attendi la fine delle richieste in coda');return send(200,codeg.undo(user.id,input));}
    if(path==='/api/integrations/openapi'){requireAdmin();return send(200,importOpenApi(input.document,input.url));}
    if(path==='/api/oauth/start'){const origin=protocol+'://'+req.headers.host;const row=integrations.allowed(input.id,user);const result=row.oauth?.desktop?await startDesktopOAuth(integrations.accounts,input.id,user,origin,auth.token(req)):integrations.accounts.start(input.id,user,origin,auth.token(req));res.setHeader('Set-Cookie','atlante_oauth='+result.nonce+'; Path=/api/oauth/callback; HttpOnly; SameSite=Lax; Max-Age=600'+(req.socket.encrypted?'; Secure':''));return send(200,{url:result.url,callback:result.callback});}
    if(path==='/api/oauth/disconnect'){integrations.accounts.disconnect(input.id,user);return send(200,{ok:true});}
    if(path==='/api/sharing/save')return send(200,collaboration.share(input,user));
    if(path==='/api/sharing/revoke')return send(200,collaboration.revoke(input.id,user));
    if(path==='/api/groups/save')return send(200,collaboration.saveGroup(input,user));
    if(path==='/api/groups/delete'){collaboration.removeGroup(input.id,user);return send(200,{ok:true});}
    if(path==='/api/shared/save')return send(200,collaboration.save(input,user));
    if(path==='/api/shared/chat'){
      collaboration.chatTarget(input.id,user,input.session,input.new===true);
      const job=requests.submit(user.id,async(signal,delta,progress)=>{
        const target=collaboration.chatTarget(input.id,user,input.session,input.new===true),isolated=new Store(':memory:');
        try{
          chatGpuOptions(input.gpu);
          const model=input.model||setup.config.defaultModel||'llama3.2:latest',documents=target.store.sessionDocuments(target.session),generate=(path,body)=>ollama(path,withChatGpu(path,body,input.gpu),signal);
          const intent=await conversationIntent({message:input.message,history:target.messages,model,generate,signal});
          progress('Consulto prima le conoscenze condivise');
          const manualId=legacyStore.db.prepare("SELECT document_id FROM library_defaults WHERE key='atlante-guide'").get()?.document_id;
          const retrieval=intent.route==='app'?{sources:appReference(intent.query,legacyStore.document(manualId)?.id),warning:null}:documents.length?await attachmentSearch.search(input.message,isolated,{session:target.session,documents,remember:false,model,generate,signal,onProgress:progress}):await knowledge.search(input.message,isolated,signal,{model,generate});
          let pages=[],warning=retrieval.warning,result,webIncomplete=false;
          if(!['app','local'].includes(intent.route)&&input.web!==false&&!webForbidden(input.message)&&(input.web||wantsWeb(input.message))){
            try{progress('Cerco fonti aggiornate online');pages=(await liveSearch(input.message,{signal})).pages;if(!pages.length)throw Error('Nessuna fonte disponibile');}
            catch(error){signal.throwIfAborted();webIncomplete=true;warning='Approfondimento online non completato: '+error.message;if(!retrieval.sources.some(s=>s.kind!=='memory'))result={answer:'Non sono riuscito a recuperare informazioni aggiornate da internet. '+error.message+' Non posso confermare questi dati senza fonti aggiornate.',sources:[],webError:true,warning};}
          }else if(input.web!==false&&!['app','local'].includes(intent.route)){
            const completion=await completeKnowledge({message:input.message,sources:retrieval.sources,model,generate,hasAttachments:documents.length>0,signal,onProgress:progress});pages=completion.pages||[];warning=[warning,completion.warning].filter(Boolean).join('\n');webIncomplete=completion.searched&&!pages.length;
            if(completion.failed)result={answer:completion.answer,sources:[],webError:true,warning};
          }
          result??=await chat(isolated,{...responseSettings.chat(),responseInstructions:[responseSettings.chat().responseInstructions,webIncomplete?'L’approfondimento online non è riuscito: dichiaralo e usa soltanto i riscontri locali senza presentarli come aggiornati online.':''].filter(Boolean).join('\n'),message:input.message,model,remember:false,history:target.messages.slice(-10).map(m=>({role:m.role,content:m.content})),retrieved:pages.length?combineKnowledgeSources(retrieval.sources,pages):retrieval.sources,documents,pages,projectPrompt:target.row.kind==='project'?collaboration.resource(target.row).value.prompt:''},generate);
          signal.throwIfAborted();return {...collaboration.append(target,user,input.message,result),sources:result.sources||[],warning:result.warning||warning,webError:result.webError||webIncomplete};
        }finally{isolated.close();}
      },{label:'Chat condivisa'});return send(200,{id:job.id});
    }
    if(path==='/api/integrations/save'){requireAdmin();return send(200,integrations.save(input));}
    if(path==='/api/integrations/delete'){requireAdmin();integrations.remove(input.id);return send(200,{ok:true});}
    if(path==='/api/integrations/test'){requireAdmin();const job=requests.submit(user.id,signal=>integrations.inspect(input.id,user,signal),{label:'Verifica connessione esterna'});return send(200,{id:job.id});}
    if(path==='/api/integrations/reject')return send(200,integrations.reject(input.id,user));
    if(path==='/api/integrations/approve'){const pending=integrations.pending(user).find(p=>p.id===input.id);if(!pending)throw Error('Operazione scaduta o non disponibile');const job=requests.submit(user.id,async(signal,onDelta,onProgress)=>{const result=await integrations.chat({approval:input.id,user},(path,body)=>ollama(path,withChatGpu(path,body,input.gpu),signal),signal,onProgress);const text=result.answer;let id;if(result.remember!==false){id=store.message(result.session,'assistant',text);store.db.prepare('INSERT OR REPLACE INTO message_workspace VALUES(?,?)').run(id,JSON.stringify({approval:result.approval||null,toolEvents:result.toolEvents||[]}));}return {...result,messageId:id};},{label:'Operazione esterna',session:pending.session});return send(200,{id:job.id});}
    if(path==='/api/assistants/save'){const installed=await modelManager.installed();if(!installed.some(m=>m.name===input.model&&m.chat))throw Error('Scegli un modello di chat installato');return send(200,saveAssistant(store,input));}
    if(path==='/api/assistants/delete'){removeAssistant(store,input.id);return send(200,{ok:true});}
    if(path==='/api/notes/save')return send(200,saveNote(store,input));
    if(path==='/api/notes/delete'){removeNote(store,input.id);return send(200,{ok:true});}
    if(path==='/api/notes/rewrite'){if(input.id)note(store,input.id);const job=requests.submit(user.id,signal=>rewriteNote({...input,model:input.model||setup.config.defaultModel||'llama3.2:latest'},(path,body)=>ollama(path,body,signal),signal),{label:'Modifica documento'});return send(200,{id:job.id});}
    if(path==='/api/data/analyze'){const dataset=getDataset(store,input.id);const result=analyze(dataset,input.plan);return send(200,{analysis:result,answer:analysisMarkdown(result)});}
    if(path==='/api/data/export'){const dataset=getDataset(store,input.id),result=analyze(dataset,input.plan);return send(200,{artifact:await createArtifact({format:'xlsx',title:'Analisi '+dataset.name,rows:[result.headers,...result.rows]})});}
    if(path==='/api/diagnostics/action'){requireAdmin();return send(200,diagnostics.start(user.id,input.action));}
    if(path==='/api/models/catalog'){requireAdmin();return send(200,await modelManager.catalog.refresh());}
    if(path==='/api/models/variants'){requireAdmin();return send(200,await modelManager.catalog.inspect(input.model));}
    if(path==='/api/models/updates'){requireAdmin();return send(200,await modelManager.checkUpdates());}
    if(path==='/api/models/default'){requireAdmin();const job=requests.submit(user.id,()=>modelManager.setDefault(input.model),{label:'Scelta modello predefinito'});return send(200,await job.promise);}
    if(path==='/api/models/download'||path==='/api/models/delete'){requireAdmin();return send(200,modelManager.start(user.id,path.endsWith('/delete')?'delete':'download',input.model));}
    if(path==='/api/maintenance/apply'){requireAdmin();return send(200,maintenance.apply(input.id));}
    if(path==='/api/maintenance/uninstall'){requireAdmin();if(input.confirm!=='DISINSTALLA')throw Error('Scrivi DISINSTALLA per confermare');return send(200,maintenance.uninstall({keepData:input.keepData!==false}));}
    if(path==='/api/response-settings/save'){requireAdmin();if(input.voice&&!((await speechVoices()).some(v=>v.name===input.voice)))throw Error('Voce non installata sul server');return send(200,{settings:responseSettings.save(input)});}
    if(path==='/api/projects/save')return send(200,saveProject(store,input));
    if(path==='/api/projects/assign'){assignProject(store,String(input.session),String(input.project||''));return send(200,{ok:true});}
    if(path==='/api/projects/delete'){store.db.prepare('DELETE FROM session_projects WHERE project=?').run(input.id);store.db.prepare('DELETE FROM projects WHERE id=?').run(input.id);return send(200,{ok:true});}
    if(path==='/api/conversations/update')return send(200,updateConversation(store,input));
    if(path==='/api/conversations/import')return send(200,importConversations(store,input));
    if(path==='/api/jobs/cancel'){requests.cancel(input.id,user.id);return send(200,{ok:true});}
    if(path==='/api/knowledge/index'){requireLibrary();const job=requests.submit(user.id,async signal=>knowledge.index(signal),{label:'Indicizzazione biblioteca'});return send(200,{id:job.id});}
    if(path==='/api/knowledge/download'){requireLibrary();const job=requests.submit(user.id,async(signal,onDelta,onProgress)=>{const state={job:{}};const result=await setup.pull.call({...setup,job:state.job},embeddingModel,signal);return result;},{label:'Download ricerca semantica'});return send(200,{id:job.id});}
    if(path==='/api/jobs/submit'){
     const job=requests.submit(user.id,async(signal,onDelta,onProgress)=>{
      const current=auth.user(user.id);if(!current?.enabled)throw Error('Account disabilitato');let payload={...input};
      if(payload.edit){const branch=branchConversation(store,{session:String(payload.session),...payload.edit});payload={...payload,...branch,remember:true};if(branch.original?.url.endsWith('.png')&&auth.owns(branch.original.url,user.id))payload.image='data:image/png;base64,'+readFileSync(artifactRoot+branch.original.url.split('/').pop()).toString('base64');}
      return ownResult(await executeChat(payload,store,{signal,onDelta,onProgress,user}),user);
     },{label:'Chat',session:input.session});return send(200,{id:job.id});
    }
    if(path==='/api/auth/logout'){auth.logout(req);res.setHeader('Set-Cookie',auth.cookie(req));return send(200,{ok:true});}
    if(path==='/api/auth/password'){await auth.changePassword(user.id,input.current,input.password);res.setHeader('Set-Cookie',auth.cookie(req));return send(200,{ok:true});}
    if(path==='/api/setup/download'){requireAdmin();return send(200,setup.start('download',input.model));}
    if(path==='/api/setup/refresh'){requireAdmin();setup.hardwareCache=null;const state=await setup.status();return send(200,{...state,images:{...await imageRuntime.status(state.hardware),modelJob:imageModels.job}});}
    if(path==='/api/setup/images/start'){requireAdmin();return send(200,imageRuntime.start(input.mode||'auto'));}
    if(path==='/api/setup/images/cancel'){requireAdmin();imageRuntime.cancel();return send(200,{ok:true});}
    if(path==='/api/setup/test'){requireAdmin();return send(200,setup.start('test',input.model));}
    if(path==='/api/setup/cancel'){requireAdmin();setup.cancel();return send(200,{ok:true});}
    if(path==='/api/setup/finish'){requireAdmin();return send(200,await setup.finish(input.model));}
    if(path==='/api/users/save'){requireAdmin();const saved=await auth.update(input,user);if(saved.enabled)profiles.get(saved);else{profiles.disable(saved.id);requests.cancelOwner(saved.id);}return send(200,{user:saved});}
    if(path==='/api/users/delete'){requireAdmin();auth.remove(input.id,user);profiles.disable(input.id);requests.cancelOwner(input.id);return send(200,{ok:true});}
    if(path==='/api/prompts/save')return send(200,scheduler.save(input));
    if(path==='/api/prompts/delete'){scheduler.remove(input.id);return send(200,{ok:true});}
    if(path==='/api/prompts/toggle')return send(200,scheduler.toggle(input.id,input.enabled));
    if(path==='/api/prompts/run')return send(200,scheduler.manual(input.id));
    if(path==='/api/import'){requireLibrary();
      const docs=Array.isArray(input.documents)?input.documents:[input];
      if(docs.length>500)throw Error('Massimo 500 documenti per importazione');
      for(const d of docs)if(typeof d.text!=='string'||!d.text.trim()||d.text.length>1000000)throw Error('Ogni documento richiede text (1–1000000 caratteri)');
      const results=docs.map(d=>legacyStore.add({...d,kind:'document'}));let indexQueued=false;if(knowledge.status().active&&!requests.pending.some(job=>job.label==='Reindicizzazione biblioteca')){try{requests.submit(user.id,signal=>knowledge.index(signal),{label:'Reindicizzazione biblioteca'});indexQueued=true;}catch{}}return send(200,{results,indexQueued});
    }
    if(path==='/api/delete'){requireLibrary();if(legacyStore.document(String(input.id))?.kind!=='document')return send(404,{error:'Documento non trovato'});legacyStore.remove(String(input.id));return send(200,{ok:true});}
    if(path==='/api/clear-session'){for(const row of store.db.prepare('SELECT id FROM messages WHERE session=?').all(String(input.session)))auth.db.prepare('DELETE FROM shared_authors WHERE owner=? AND message=?').run(user.id,row.id);store.clearSession(String(input.session));return send(200,{ok:true});}
    if(path==='/api/images/delete'){if(!auth.owns(input.url,user.id))return send(404,{error:'Immagine non trovata'});await deleteImageArtifact(input.url,store);return send(200,{ok:true});}
    if(path==='/api/search'){requireLibrary();return send(200,(await knowledge.search(input.query,store)).sources.filter(d=>d.kind==='document'));}
    if(!['/api/chat','/api/voice/transcribe','/api/voice/speak','/api/attachment','/api/research','/api/browse','/api/export','/api/image/analyze','/api/image/edit','/api/image/generate'].includes(path))return send(404,{error:'Non trovato'});
    let queued;
    res.once('close',()=>{if(!res.writableEnded&&queued)requests.cancel(queued.id,user.id);});
    queued=requests.submit(user.id,async signal=>{
      if(path==='/api/voice/transcribe'||path==='/api/voice/speak'){
        const controller={signal};
        if(path==='/api/voice/transcribe')return send(200,await transcribe(input,controller.signal));
        const audio=await speak({...input,...responseSettings.get()},controller.signal);res.writeHead(200,{'Content-Type':'audio/wav','Cache-Control':'no-store'});res.end(audio);return;
      }
      if(path==='/api/attachment'){const result=await readAttachment(input);if(/\.(xlsx|csv|tsv)$/i.test(input.name)){const dataset=await parseDataset(input);result.datasetId=stageDataset(store,dataset);result.datasetProfile=profile(dataset);}return send(200,result);}
      if(path==='/api/export')return send(200,{artifact:await createArtifact(input)});
      if(path==='/api/image/analyze')return send(200,await analyzeImage(input,signal));
      if(path==='/api/image/edit'||path==='/api/image/generate'){const artifact=path==='/api/image/edit'?await editImage(input):await generateImage(input,signal,undefined,imageModels.configuration(input.imageModel));store.imageResult({artifact,prompt:String(input.prompt||'Modifica immagine').slice(0,3000),session:String(input.session||'default'),remember:input.remember!==false});return send(200,{artifact});}
      if(path==='/api/browse')return send(200,await browse(input.url,{follow:input.follow===true,query:input.query||''}));
      if(path==='/api/research'){
        if(typeof input.query!=='string'||!input.query.trim()||input.query.length>500)throw Error('Ricerca richiesta (massimo 500 caratteri)');
        return send(200,{sources:await research(input.query,store,input.language||'it')});
      }
      return send(200,await executeChat(input,store,{signal,user}));
    },{label:path.split('/').at(-1),session:input.session});await queued.promise;
  }catch(e){send(e.status||400,{error:e.message});}
};
const server=http.createServer(handler);
const secureServer=tls?https.createServer(tls,handler):null;
secureServer?.on('error',e=>{httpsReady=false;console.error('HTTPS:',e.message);});
secureServer?.listen(httpsPort,'0.0.0.0',()=>{httpsReady=true;console.log(`Atlante HTTPS in ascolto su 0.0.0.0:${httpsPort}`);});
server.listen(port,'0.0.0.0',()=>{console.log(`Atlante in ascolto su 0.0.0.0:${port}`);profiles.start();});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{requests.stop();profiles.stop();secureServer?.close();server.close(()=>{legacyStore.close();auth.close();process.exit(0);});setTimeout(()=>process.exit(0),3000).unref();});

async function executeChat(input,store,{signal,onDelta,onProgress,user}={}){
 let partial='';const emit=onDelta?text=>{partial+=text;onDelta(text);}:undefined;
 const before=store.db.prepare('SELECT max(id) id FROM messages WHERE session=?').get(String(input.session||'default')).id||0;
 try{const result=await performChat(input,store,{signal,onDelta:emit,onProgress,user});signal?.throwIfAborted();const session=String(input.session||'default'),last=store.db.prepare("SELECT id FROM messages WHERE session=? AND role='assistant' AND id>? ORDER BY id DESC LIMIT 1").get(session,before),userMessage=store.db.prepare("SELECT id FROM messages WHERE session=? AND role='user' AND id>? ORDER BY id DESC LIMIT 1").get(session,before);if(last){if(result.analysis||result.noteId)store.db.prepare('INSERT OR REPLACE INTO message_workspace VALUES(?,?)').run(last.id,JSON.stringify({analysis:result.analysis||null,datasetId:result.datasetId||null,noteId:result.noteId||null}));bindDatasets(store,session,input.documents||[],input.remember!==false);store.db.prepare('INSERT OR REPLACE INTO message_sources VALUES(?,?)').run(last.id,JSON.stringify(result.sources||[]));if(result.artifact&&!result.artifact.url.endsWith('.png'))store.db.prepare('INSERT OR REPLACE INTO message_files VALUES(?,?,?)').run(last.id,result.artifact.name,result.artifact.url);}return {...result,session,messageId:last?.id,userMessageId:userMessage?.id};}
 catch(e){if(signal?.aborted&&partial&&input.remember!==false&&!store.db.prepare('SELECT 1 FROM messages WHERE session=? AND id>?').get(String(input.session||'default'),before)){store.rememberDocuments(String(input.session||'default'),input.documents||[]);store.message(String(input.session||'default'),'user',input.message);store.message(String(input.session||'default'),'assistant',partial+'\n\n[Risposta interrotta]');}throw e;}
}
async function performChat(input,store,{signal,onDelta,onProgress,user}={}){
      signal?.throwIfAborted();
      chatGpuOptions(input.gpu);
      const localGenerate=(path,body)=>ollama(path,withChatGpu(path,body,input.gpu),signal);
      const generate=(path,body)=>path==='chat'&&onDelta&&!body.format?streamChat(withChatGpu(path,body,input.gpu),signal,onDelta):localGenerate(path,body);
      const assistantSession=String(input.session||'default');const assistantId=input.assistant===undefined?sessionAssistant(store,assistantSession):input.assistant;
      const chosenAssistant=assistantId?(String(assistantId).startsWith('share:')?(()=>{const item=collaboration.get(assistantId.slice(6),user);if(item.kind!=='assistant')throw Error('Assistente non disponibile');return item.value;})():assistant(store,assistantId)):null;
      input.model=chosenAssistant?.model||input.model||setup.config.defaultModel||'llama3.2:latest';
      if(input.remember!==false&&input.assistant!==undefined){if(assistantId)store.db.prepare('INSERT OR REPLACE INTO session_assistants VALUES(?,?)').run(assistantSession,assistantId);else store.db.prepare('DELETE FROM session_assistants WHERE session=?').run(assistantSession);}
      let warning=null;
      if(typeof input.message!=='string'||!input.message.trim()||input.message.length>12000)throw Error('Messaggio richiesto (massimo 12000 caratteri)');
      if(input.documents!==undefined&&(!Array.isArray(input.documents)||input.documents.length>4||input.documents.some(d=>typeof d.name!=='string'||d.name.length>200||typeof d.text!=='string'||d.text.length>1000000)))throw Error('Documenti allegati non validi');
      if(input.history!==undefined&&(!Array.isArray(input.history)||input.history.length>10||input.history.some(m=>!m||!['user','assistant'].includes(m.role)||typeof m.content!=='string'||m.content.length>12000)))throw Error('Contesto conversazione non valido');
      const dateAnswer=currentDateAnswer(input.message);if(dateAnswer){if(input.remember!==false){store.message(assistantSession,'user',input.message);store.message(assistantSession,'assistant',dateAnswer);}return {answer:dateAnswer,session:assistantSession,sources:[],metrics:{}};}
      const priorImage=!input.image&&!input.documents?.length?store.sessionImage(assistantSession):null;
      const reuseImage=previousImageRequest(input.message,{hasPreviousImage:!!priorImage,hasDocuments:!!input.documents?.length});
      let image=input.image;
      if(reuseImage){const imagePath=artifactRoot+priorImage.url.split('/').pop();if(!existsSync(imagePath))throw Error('L’immagine precedente non è più disponibile. Allega quella da modificare con il pulsante +.');image='data:image/png;base64,'+readFileSync(imagePath).toString('base64');}
      const imageRequest=localImageRequest(input.message,{hasImage:!!image,hasDocuments:!!input.documents?.length});
      const intent=imageRequest||input.documents?.length?{route:'general',query:input.message}:await conversationIntent({message:input.message,history:input.history||store.history(assistantSession),model:input.model,generate:localGenerate,signal});
      if(externalServiceRequest(input.message,input.history||store.history(assistantSession)))intent.route='external';
      if(intent.warning)warning=intent.warning;
      if(imageRequest)input.integration=null;
      const profileConnections=intent.route!=='external'||externalDiscussion(input.message)||imageRequest||publicKnowledgeRequest(input.message)?[]:user?integrations.active(user):[];
      const requestedService=externalServiceRequest(input.message,input.history||store.history(assistantSession)),requestedConnection=requestedService?'atlante-google-'+requestedService:null;
      const requiredConnection=requestedConnection&&profileConnections.includes(requestedConnection)?requestedConnection:null;
      const availableModels=(input.integration||profileConnections.length)&&!input.image&&!input.documents?.length&&!input.format?await modelManager.installed():[];
      let integrationModel=input.model;
      if(requiredConnection&&!availableModels.find(m=>m.name===integrationModel)?.capabilities.includes('tools')){const fallback=availableModels.find(m=>m.name==='llama3.2:latest'&&m.capabilities.includes('tools'))||availableModels.find(m=>m.capabilities.includes('tools'));if(!fallback)throw Error('Per consultare i servizi collegati installa un modello con supporto strumenti, ad esempio Llama 3.2.');integrationModel=fallback.name;warning='Servizio consultato con '+integrationModel+' (supporta gli strumenti).';}
      const automaticConnections=requiredConnection?[requiredConnection]:profileConnections.length&&availableModels.find(m=>m.name===input.model)?.capabilities.includes('tools')?profileConnections:null;
      if(input.integration||automaticConnections){if(!user)throw Error('Le connessioni esterne richiedono una sessione utente');if(input.image||input.documents?.length||input.format)throw Error('Usa gli strumenti esterni in un messaggio separato dagli allegati e dall’export');if(!availableModels.find(m=>m.name===integrationModel)?.capabilities.includes('tools'))throw Error('Questo modello non supporta gli strumenti. Scegli un modello con tool calling, ad esempio Llama 3.2.');const result=await integrations.chat({...responseSettings.chat(),connection:input.integration||automaticConnections,requireTools:!!requiredConnection,user,message:input.message,session:assistantSession,model:integrationModel,history:input.history||store.history(assistantSession),instruction:[responseSettings.chat().responseInstructions,chosenAssistant?.prompt].filter(Boolean).join('\n'),remember:input.remember!==false},localGenerate,signal,onProgress);if(input.integration||requiredConnection||result.completed||result.approval){if(input.remember!==false){store.message(assistantSession,'user',input.message);const messageId=store.message(assistantSession,'assistant',result.answer);store.db.prepare('INSERT OR REPLACE INTO message_workspace VALUES(?,?)').run(messageId,JSON.stringify({approval:result.approval||null,toolEvents:result.toolEvents||[]}));}return {...result,warning,sources:[],metrics:{}};}}
      const documents=input.documents||[];const imageSession=String(input.session||'default');
      if(input.project){if(!store.db.prepare('SELECT id FROM projects WHERE id=?').get(input.project))throw Error('Progetto non trovato');store.db.prepare('INSERT INTO session_projects VALUES(?,?) ON CONFLICT(session) DO UPDATE SET project=excluded.project').run(imageSession,input.project);}
      const datasetId=sessionDataset(store,imageSession,documents);const previousWorkspace=store.db.prepare('SELECT w.json FROM message_workspace w JOIN messages m ON m.id=w.message_id WHERE m.session=? ORDER BY m.id DESC LIMIT 1').get(imageSession);if(input.analysisPlan&&JSON.stringify(input.analysisPlan).length>12000)throw Error('Contesto analisi troppo lungo');let previousPlan=input.analysisPlan||(previousWorkspace?JSON.parse(previousWorkspace.json).analysis?.plan:null);if(documents.some(d=>d.datasetId)&&!input.analysisPlan&&datasetId!==(previousWorkspace?JSON.parse(previousWorkspace.json).datasetId:null))previousPlan=null;
      if(datasetId&&!image&&(/analizz|somma|totale|media|minimo|massimo|grafico|raggrupp|quante|quanti|contegg|fatturat|ricav|vendit|percentual|calcol|moltiplic|prodotto/i.test(input.message)||previousPlan&&/^(?:e\b|ora\b|invece\b|solo\b|filtra\b|aggiungi\b)/i.test(input.message))){
        onProgress?.('Analizzo i dati del foglio');const dataset=getDataset(store,datasetId),calculation=await planAnalysis(dataset,input.message,input.model,localGenerate,previousPlan);const analysis=analyze(dataset,calculation),answer=analysisMarkdown(analysis);signal?.throwIfAborted();let userMessageId,messageId;
        if(input.remember!==false){bindDatasets(store,imageSession,documents,true);store.rememberDocuments(imageSession,documents);userMessageId=store.message(imageSession,'user',input.message);messageId=store.message(imageSession,'assistant',answer);}
        const dataFormat=input.format||requestedFormat(input.message);const artifact=dataFormat==='xlsx'?await createArtifact({format:'xlsx',title:'Analisi '+dataset.name,rows:[analysis.headers,...analysis.rows]}):null;return {answer,analysis,datasetId,artifact,sources:[],warning:analysis.warnings.join(' '),metrics:{},messageId,userMessageId};
      }
      const plan=await resolveTool(input.message,{hasImage:!!image,hasDocuments:documents.length>0},localGenerate,imageToolsModel);
      if(!image&&!documents.length&&plan.tool==='chat'&&/\b(?:immagine|foto|modificala|trasformala|ruotala)\b/i.test(input.message)&&chooseTool(input.message,{hasImage:true}).tool!=='analyze')throw Error('Allega l’immagine da modificare con il pulsante + nella chat.');
      if(!image&&!documents.length&&/^(?:descrivi|analizza|cosa vedi)/i.test(input.message)&&/\b(?:immagine|foto)\b/i.test(input.message))throw Error('Allega l’immagine da analizzare con il pulsante + nella chat.');
      if(plan.tool!=='chat'){
        if(chosenAssistant&&!chosenAssistant.images)throw Error('Gli strumenti immagini sono disabilitati per questo assistente.');
        if(input.format)throw Error('Per creare un’immagine scegli Risposta in chat nelle opzioni.');
        let artifact=null,answer='',originalArtifact=null,ocr=null,scenePrompt=null;
        if(image)await decodeImage(image);
        if(plan.tool==='analyze'){const analysis=await analyzeImage({image,prompt:input.message,textModel:input.model},signal,localGenerate);answer=analysis.answer;ocr=analysis.ocr;warning=analysis.warning;if(ocr?.text&&input.remember!==false)store.rememberDocuments(imageSession,[{name:'Testo immagine (OCR)',text:ocr.text.slice(0,100000)}]);}
        else if(plan.tool==='edit')artifact=await editImage({image,...plan});
        else {
          onProgress?.('Preparazione descrizione con '+imageToolsModel);
          const prompt=await imagePrompt(input.message,localGenerate,imageToolsModel,reuseImage?priorImage.prompt:'');scenePrompt=prompt;
          onProgress?.('Generazione immagine con '+(imageSettings.get().backend==='comfyui'?'ComfyUI locale':'Stable Diffusion'));
          artifact=await generateImage({prompt,image:plan.tool==='transform'?image:undefined,...input.imageParameters},signal,onProgress,imageModels.configuration(input.imageModel));
        }
        if(image&&input.remember!==false){const {bytes}=await decodeImage(image);const sharp=(await import('sharp')).default;originalArtifact=await saveArtifact(await sharp(bytes).rotate().png().toBuffer(),'png','Immagine allegata');}
        store.imageResult({artifact,originalArtifact,scenePrompt:scenePrompt||(reuseImage?priorImage.prompt:undefined),answer:answer||'Immagine creata.',prompt:input.message,session:imageSession,remember:input.remember!==false});
        return {answer:answer||'Immagine creata.',artifact,tool:plan.tool,sources:ocr?.text?[{title:'Testo riconosciuto nell’immagine',kind:'OCR locale',url:''}]:[],warning,metrics:{},originalArtifact};
      }
      if(image)throw Error('Invia immagini e documenti in messaggi separati per analizzarli.');
      input.format=input.format||requestedFormat(input.message);
      if(chosenAssistant&&!chosenAssistant.web&&!webForbidden(input.message)&&(input.web||wantsWeb(input.message)||/https?:\/\//.test(input.message)))throw Error('Il web è disabilitato per questo assistente.');
      const hasAttached=documents.length>0||store.sessionDocuments(imageSession).length>0;
      onProgress?.('Consulto prima memoria e biblioteca');
      const manualId=legacyStore.db.prepare("SELECT document_id FROM library_defaults WHERE key='atlante-guide'").get()?.document_id;
      const retrieval=intent.route==='app'?{sources:appReference(intent.query,legacyStore.document(manualId)?.id),warning:null}:hasAttached?await attachmentSearch.search(input.message,store,{session:imageSession,documents,remember:input.remember!==false,model:input.model,generate:localGenerate,signal,onProgress}):await knowledge.search(input.message,store,signal,{model:input.model,generate:localGenerate});
      if(chosenAssistant?.documents.length){const personal=await attachmentSearch.search(input.message,store,{session:'assistant-'+chosenAssistant.id,documents:chosenAssistant.documents,remember:false,model:input.model,generate:localGenerate,signal,onProgress});if(personal.warning)warning=[warning,personal.warning].filter(Boolean).join('\n');retrieval.sources=[...retrieval.sources,...personal.sources];}
      const urls=input.web===false||intent.route==='app'||webForbidden(input.message)?[]:input.message.match(/https?:\/\/[^\s<>"\]]+/g)||[];
      let pages=[],links=[];
      for(const url of [...new Set(urls)].slice(0,2)){
        const result=await browse(url.replace(/[.,;!?)]+$/,''),{follow:input.follow===true,query:input.message});pages.push(...result.pages);links.push(...result.pages.flatMap(p=>p.links));
        if(result.errors.length)warning=result.errors.map(e=>e.url+': '+e.error).join('\n');
      }
      pages=pages.slice(0,4);
      const requestedWeb=intent.route!=='app'&&(intent.route!=='local'||wantsWeb(input.message))&&input.web!==false&&!webForbidden(input.message)&&(input.web||wantsWeb(input.message));
      let webIncomplete=false;
      if(!pages.length&&requestedWeb){try{onProgress?.('Approfondisco online dopo la ricerca locale');const found=await liveSearch(input.message,{signal});pages=found.pages;if(!pages.length)throw Error('Nessun testo disponibile nelle fonti');}catch(e){signal?.throwIfAborted();webIncomplete=true;warning=[warning,'Approfondimento online non completato: '+e.message].filter(Boolean).join('\n');if(!retrieval.sources.some(s=>s.kind!=='memory')){const answer='Non sono riuscito a recuperare informazioni aggiornate da internet. '+e.message+' Non posso confermare questi dati senza fonti aggiornate.';if(input.remember!==false){store.message(imageSession,'user',input.message);store.message(imageSession,'assistant',answer);}return {answer,sources:[],warning,webError:true,metrics:{}};}}}
      if(input.web!==false&&!pages.length&&!requestedWeb&&!['app','local'].includes(intent.route)){
        const completion=await completeKnowledge({message:input.message,sources:retrieval?.sources||[],model:input.model,generate:localGenerate,allowWeb:!chosenAssistant||chosenAssistant.web,hasAttachments:hasAttached||!!chosenAssistant?.documents.length,signal,onProgress});
        if(completion.warning)warning=[warning,completion.warning].filter(Boolean).join('\n');
        if(completion.failed){if(input.remember!==false){store.message(imageSession,'user',input.message);store.message(imageSession,'assistant',completion.answer);}return {answer:completion.answer,sources:[],warning,webError:true,metrics:{}};}
        if(completion.pages?.length)pages=completion.pages;
        if(completion.searched&&!pages.length)webIncomplete=true;
      }
      if(pages.length){retrieval.sources=combineKnowledgeSources(retrieval.sources,pages);links.push(...pages.flatMap(p=>p.links||[]));}
      const project=store.db.prepare('SELECT p.prompt FROM projects p JOIN session_projects sp ON sp.project=p.id WHERE sp.session=?').get(String(input.session||'default'));
      const result=await chat(store,{...input,...responseSettings.chat(),responseInstructions:[responseSettings.chat().responseInstructions,webIncomplete?'L’approfondimento online non è riuscito. Dichiaralo nella risposta e usa soltanto i riscontri locali disponibili; non presentare le informazioni come verificate online o aggiornate.':''].filter(Boolean).join('\n'),pages,retrieved:retrieval?.sources,projectPrompt:['Servizi attualmente collegati e autorizzati: '+(user?integrations.active(user).map(id=>integrations.row(id).name).join(', ')||'nessuno':'nessuno')+'. Disponibile non significa consultato: per dati aggiornati esegui lo strumento. Non negare le connessioni disponibili.',project?.prompt,chosenAssistant?.name?'Il nome dell’assistente selezionato è '+chosenAssistant.name+'. Mantieni questo nome nella presentazione e chiarisci che operi in Atlante.':'',chosenAssistant?.prompt,intent.route==='app'?'La richiesta corrente riguarda te o l’applicazione Atlante. Usa il dialogo e il manuale fornito per rispondere alla richiesta effettiva; non parlare di soggetti omonimi.':''].filter(Boolean).join('\n\n')},generate);
      retrieval?.commit?.();
      if(retrieval?.warning)warning=[warning,retrieval.warning].filter(Boolean).join('\n');
      if(result.contextTruncated)warning=[warning,'Il testo supera il contesto della risposta: sono mostrati solo i passaggi forniti al modello.'].filter(Boolean).join('\n');
      let artifact=null;
      if(input.format){if(result.metrics.truncated)throw Error('Contenuto del documento troppo lungo. Richiedi un documento più breve.');let structured;try{structured=JSON.parse(result.answer);}catch{throw Error('Il modello non ha prodotto un documento valido. Riprova con una richiesta più semplice.');}if(input.format==='xlsx'&&(!Array.isArray(structured.rows)||structured.rows.length<2))throw Error('Il modello ha omesso i dati della tabella. Riprova.');if(input.format==='pptx'&&(!Array.isArray(structured.slides)||!structured.slides.length))throw Error('Il modello ha omesso le diapositive. Riprova.');artifact=await createArtifact({...structured,format:input.format});if(['docx','pdf','txt'].includes(input.format)&&input.remember!==false){const draft=saveNote(store,{title:String(structured.title||'Documento').slice(0,200),text:String(structured.text||'').slice(0,100000)});result.noteId=draft.id;}result.answer='File creato: '+artifact.name;}
      if(input.remember!==false)for(const p of pages)store.add({title:p.title,text:p.text,url:p.url,license:'Verificare le condizioni della fonte',kind:'web'});
      return {...result,artifact,links:links.slice(0,60),warning,webError:webIncomplete};
}
