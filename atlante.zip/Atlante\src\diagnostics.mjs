import {existsSync} from 'node:fs';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {join} from 'node:path';
import {freemem,totalmem} from 'node:os';
import {ollamaBase} from './ollama-config.mjs';
const run=promisify(execFile),GB=1024**3;
const check=(id,title,state,note,action=null)=>({id,title,state,note,action});
export class Diagnostics{
 constructor({setup,models,queue,components,https=()=>false,startOllama=null,stopOllama=null}){Object.assign(this,{setup,models,queue,components,https});this.startOllama=startOllama||this.launchOllama;this.stopOllama=stopOllama||this.stopLocalOllama;this.tests=null;}
 async status(){
  const [setupResult,modelsResult,loadedResult]=await Promise.allSettled([this.setup.status(),this.models.installed(),this.models.api('ps')]);
  const state=setupResult.status==='fulfilled'?setupResult.value:null,installed=modelsResult.status==='fulfilled'?modelsResult.value:[],online=modelsResult.status==='fulfilled',loaded=loadedResult.status==='fulfilled'?loadedResult.value.models||[]:[];
  const free=freemem()/GB,total=totalmem()/GB,chat=installed.filter(m=>m.chat),configured=this.setup.config.defaultModel;
  const checks=[check('ollama','Ollama',online?'ok':'error',online?`${installed.length} modelli installati; ${loaded.length} in memoria.`:'Il server dei modelli non risponde. Controlla che Ollama sia installato e avviato.',online?'models':this.models.remote?'guide':'start-ollama'),check('models','Modello di chat',!online?'unknown':!chat.length||configured&&!chat.some(m=>m.name===configured)?'error':'ok',!online?'Non verificabile finché Ollama non risponde.':configured&&!chat.some(m=>m.name===configured)?`Il predefinito ${configured} non è disponibile.`:chat.length?`Predefinito: ${configured||chat.find(m=>m.name==='llama3.2:latest')?.name||chat[0].name}`:'Nessun modello di chat disponibile. Scaricane uno dal pannello Modelli.','models'),check('memory','Memoria del server',free<2||free/total<.1?'warning':'ok',`${free.toFixed(1)} GB liberi su ${total.toFixed(1)} GB. Liberare i modelli dalla memoria non li elimina dal disco.`,loaded.length?'unload':'guide')];
  const available=state?.checks||{};
  for(const [id,title,key]of [['transcription','Riconoscimento vocale','transcription'],['speech','Voce italiana','speech'],['images','Generazione immagini','images'],['ocr','Lettura immagini e scansioni','ocr']])checks.push(check(id,title,state?available[key]?'ok':'error':'unknown',state?available[key]?'Componente presente. Usa «Esegui prove» per verificarne il funzionamento.':'Componente assente o non rilevato. Consulta le istruzioni di riparazione.':'Controllo non riuscito. Ripeti la diagnosi.',available[key]?'test':'guide'));
  checks.push(check('vision','Analisi immagini',!online?'unknown':installed.some(m=>m.name==='gemma3:4b')?'ok':'warning',!online?'Ollama non raggiungibile.':installed.some(m=>m.name==='gemma3:4b')?'Gemma 3 4B disponibile.':'Manca Gemma 3 4B, usato da Atlante per l’analisi visiva. L’OCR può comunque leggere il testo.','models'));
  checks.push(check('storage','Salvataggio dati',state?available.storage?'ok':'error':'unknown',state?available.storage?'La cartella dei dati è scrivibile.':'Atlante non riesce a scrivere nella cartella dei dati. Controlla spazio e permessi.':'Controllo non riuscito.','guide'),check('https','HTTPS e microfono',this.https()?'ok':'warning',this.https()?'HTTPS attivo sul server. Su altri dispositivi serve anche una connessione sicura riconosciuta dal browser.':'HTTPS non attivo. Il microfono su altri dispositivi può essere bloccato.','voice-guide'));
  for(const item of checks){if(item.state==='ok'&&this.tests?.results[item.id]?.ok===false){item.state='error';item.note='Componente presente, ma l’ultima prova non è riuscita. '+this.tests.results[item.id].note;item.action=item.id==='models'?'models':'guide';}}
  return {checkedAt:new Date().toISOString(),remote:this.models.remote,checks,hardware:state?.hardware||null,queue:{active:this.queue.active?'Richiesta in esecuzione':null,waiting:this.queue.pending.length},tests:this.tests};
 }
 async launchOllama(){
  if(process.platform!=='win32')throw Error('Avvia Ollama sul server, poi ripeti la diagnosi.');
  const candidates=[process.env.LOCALAPPDATA&&join(process.env.LOCALAPPDATA,'Programs','Ollama','ollama.exe'),process.env.ProgramFiles&&join(process.env.ProgramFiles,'Ollama','ollama.exe')].filter(Boolean),exe=candidates.find(existsSync);
  if(!exe)throw Error('Ollama non trovato. Esegui di nuovo installa.bat sul server.');
  const script=`Start-Process -FilePath '${exe.replaceAll("'","''")}' -ArgumentList 'serve' -WindowStyle Hidden`;
  await run('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{windowsHide:true,timeout:15000});
 }
 async stopLocalOllama(){
  if(process.platform!=='win32')throw Error('Il riavvio guidato di Ollama richiede Windows.');
  const endpoint=new URL(ollamaBase);
  if(endpoint.protocol!=='http:'||Number(endpoint.port||80)!==11434||endpoint.pathname!=='/')throw Error('Il riavvio guidato richiede Ollama locale sulla porta 11434.');
  const script=`$ErrorActionPreference='Stop'
 $listeners=@(Get-NetTCPConnection -LocalPort 11434 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
 foreach($ollamaProcessId in $listeners){
  $target=Get-CimInstance Win32_Process -Filter "ProcessId=$ollamaProcessId"
  if(!$target -or $target.Name -ne 'ollama.exe' -or $target.CommandLine -notmatch '\\bserve\\b'){throw 'La porta 11434 non appartiene a un server Ollama riconosciuto. Nessun processo arrestato.'}
 }
 foreach($ollamaProcessId in $listeners){
  & taskkill.exe /PID $ollamaProcessId /T /F | Out-Null
  if($LASTEXITCODE -ne 0 -and (Get-Process -Id $ollamaProcessId -ErrorAction SilentlyContinue)){throw 'Impossibile arrestare il server Ollama.'}
 }`;
  await run('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{windowsHide:true,timeout:15000});
 }
 start(owner,action){
  if(!['test','unload','start-ollama','restart-ollama'].includes(action))throw Error('Azione diagnostica non valida');
  if(['start-ollama','restart-ollama'].includes(action)&&this.models.remote)throw Error('Avvia o riavvia Ollama sul server remoto.');
  const job=this.queue.submit(owner,async(signal,onDelta,onProgress)=>{
   if(action==='restart-ollama'){
    signal.throwIfAborted();onProgress('Riavvio del server Ollama');await this.stopOllama();
    // Restore service even if cancellation arrives after stopping the process.
    try{await this.models.api('tags',undefined,'GET',AbortSignal.timeout(1000));}catch{await this.startOllama();}
    for(let i=0;i<60;i++){try{await this.models.api('tags',undefined,'GET',AbortSignal.timeout(1000));signal.throwIfAborted();return {message:'Ollama riavviato e disponibile. I modelli verranno ricaricati alla prossima domanda.'};}catch(e){if(signal.aborted)throw signal.reason;}await new Promise(r=>setTimeout(r,500));}
    throw Error('Ollama non risponde dopo il riavvio. Consulta Diagnostica e i log sul PC server.');
   }
   if(action==='unload'){const {models=[]}=await this.models.api('ps');for(const model of models){signal.throwIfAborted();onProgress('Libero memoria: '+model.name);await this.models.api('generate',{model:model.name,keep_alive:0},'POST',signal);}return {message:'Modelli rimossi dalla memoria. Verranno ricaricati quando serviranno.'};}
   if(action==='start-ollama'){try{await this.models.api('tags');return {message:'Ollama è già raggiungibile.'};}catch{}signal.throwIfAborted();await this.startOllama();for(let i=0;i<20;i++){signal.throwIfAborted();try{await this.models.api('tags',undefined,'GET',AbortSignal.any([signal,AbortSignal.timeout(1000)]));return {message:'Ollama avviato.'};}catch{}await new Promise(r=>setTimeout(r,250));}throw Error('Ollama non risponde dopo l’avvio. Consulta le istruzioni di riparazione.');}
   const results={};onProgress('Prova risposta del modello');
   try{const installed=await this.models.installed(),model=this.setup.config.defaultModel||installed.find(m=>m.name==='llama3.2:latest'&&m.chat)?.name||installed.find(m=>m.chat)?.name;if(!model)throw Error('Nessun modello di chat installato');const data=await this.models.api('chat',{model,stream:false,messages:[{role:'user',content:'Rispondi solo: pronto'}],options:{num_predict:16,num_ctx:2048}},'POST',AbortSignal.any([signal,AbortSignal.timeout(180000)]));if(!data.message?.content?.trim())throw Error('Risposta vuota');results.models={ok:true,note:'Il modello ha restituito una risposta.'};}catch(e){if(signal.aborted)throw signal.reason;results.models={ok:false,note:e.message};}
   onProgress('Prove locali: voce, riconoscimento, OCR e motore immagini');Object.assign(results,await this.components(signal));signal.throwIfAborted();this.tests={testedAt:new Date().toISOString(),results};return {message:'Prove completate. Consulta i risultati.',...this.tests};
  },{label:({test:'Diagnostica: prove dei componenti',unload:'Diagnostica: libera memoria','start-ollama':'Diagnostica: avvio Ollama','restart-ollama':'Riavvio Ollama'})[action]});return {id:job.id};
 }
}
