import {readFileSync,existsSync} from 'node:fs';
import {mkdir,writeFile,rename,unlink,realpath,statfs} from 'node:fs/promises';
import {join,resolve,isAbsolute,sep,dirname} from 'node:path';
import {homedir} from 'node:os';
import {randomUUID} from 'node:crypto';
export function modelFolders(root){
 const file=join(root,'data/model-folders.json');let saved={};
 if(existsSync(file))saved=JSON.parse(readFileSync(file,'utf8').replace(/^\uFEFF/,''));
 return {local:saved.local||join(root,'models'),ollama:saved.ollama||process.env.OLLAMA_MODELS||join(homedir(),'.ollama','models')};
}
export function modelPath(root,...parts){return join(modelFolders(root).local,...parts);}
export async function modelDiskFreeGB(root,readStats=statfs){
 let path=modelPath(root);
 for(;;){
  try{const disk=await readStats(path);return Number(disk.bavail)*Number(disk.bsize)/1024**3;}
  catch(error){if(error.code!=='ENOENT')return null;const parent=dirname(path);if(parent===path)return null;path=parent;}
 }
}
export async function saveModelFolders(root,input){
 const folders={};
 for(const key of ['local','ollama']){
  const value=input[key];if(typeof value!=='string'||!value.trim()||!isAbsolute(value.trim())||/[\x00-\x1f]/.test(value))throw Error('Inserisci percorsi assoluti validi sul PC server.');
  const path=resolve(value.trim());
  for(const name of ['src','public','scripts','installer','data','runtime','config','distribute','PagineWeb','node_modules']){const protectedPath=resolve(root,name);if(path===protectedPath||path.startsWith(protectedPath+sep)||protectedPath.startsWith(path+sep))throw Error('Scegli una cartella dedicata ai modelli, separata da applicazione, dati e runtime.');}
  await mkdir(path,{recursive:true});const probe=join(path,'.atlante-write-'+randomUUID());await writeFile(probe,'',{flag:'wx'});await unlink(probe);folders[key]=await realpath(path);
 }
 if(folders.local===folders.ollama||folders.local.startsWith(folders.ollama+sep)||folders.ollama.startsWith(folders.local+sep))throw Error('Le due cartelle dei modelli devono essere separate.');
 await mkdir(join(root,'data'),{recursive:true});const file=join(root,'data/model-folders.json'),temp=file+'.'+randomUUID()+'.tmp';await writeFile(temp,JSON.stringify(folders,null,2)+'\n');await rename(temp,file);return folders;
}
