import {Document,Packer,Paragraph,HeadingLevel} from 'docx';
import ExcelJS from 'exceljs';
import pptxgen from 'pptxgenjs';
import PDFDocument from 'pdfkit';
import {mkdir,writeFile,readFile,unlink} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
export const artifactRoot=fileURLToPath(new URL('../data/artifacts/',import.meta.url));
export async function deleteImageArtifact(url,store,directory=artifactRoot){
 if(typeof url!=='string'||!/^\/artifacts\/[a-f0-9-]{36}\.png$/.test(url))throw Error('Immagine non valida');
 const name=url.slice('/artifacts/'.length);
 try{await unlink(directory+name);}catch(e){if(e.code!=='ENOENT')throw e;}
 store.removeImage(url);
}
export async function saveArtifact(buffer,extension,title='Atlante'){
 await mkdir(artifactRoot,{recursive:true});const id=randomUUID()+'.'+extension;await writeFile(artifactRoot+id,buffer);return {name:title.slice(0,80)+'.'+extension,url:'/artifacts/'+id};
}
export async function createArtifact({format,title='Documento Atlante',text='',rows,slides}){
 title=String(title).slice(0,180);text=String(text).slice(0,60000);
 if(!['docx','xlsx','pptx','pdf','txt'].includes(format))throw Error('Formato non supportato');
 let buffer;
 if(format==='txt')buffer=Buffer.from(title+'\n\n'+text);
 if(format==='docx')buffer=await Packer.toBuffer(new Document({sections:[{children:[new Paragraph({text:title,heading:HeadingLevel.TITLE}),...text.split('\n').map(line=>new Paragraph({text:line,spacing:{after:120}}))]}]}));
 if(format==='xlsx'){
  const book=new ExcelJS.Workbook();const sheet=book.addWorksheet('Dati');
  const data=Array.isArray(rows)&&rows.length?rows:text.split('\n').map(line=>line.split('\t'));
  if(data.length>2000)throw Error('Massimo 2000 righe');
  data.forEach(row=>{if(!Array.isArray(row)||row.length>40)throw Error('Righe non valide');sheet.addRow(row.map(v=>typeof v==='number'&&Number.isFinite(v)?v:String(v??'').slice(0,10000)));});
  sheet.getRow(1).font={bold:true,color:{argb:'FFFFFFFF'}};sheet.getRow(1).fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF193F52'}};sheet.columns.forEach(c=>{c.width=28;c.alignment={wrapText:true,vertical:'top'};});sheet.views=[{state:'frozen',ySplit:1}];buffer=await book.xlsx.writeBuffer();
 }
 if(format==='pptx'){
  const ppt=new pptxgen();ppt.layout='LAYOUT_WIDE';ppt.author='Atlante';ppt.subject=title;
  const items=Array.isArray(slides)&&slides.length?slides:[{title,text}];
  let count=0;for(const item of items.slice(0,20)){const chunks=String(item.text||'').match(/[\s\S]{1,800}/g)||[''];for(const chunk of chunks){if(count++>=30)throw Error('Presentazione troppo lunga: massimo 30 slide');const slide=ppt.addSlide();slide.background={color:'102331'};slide.addText(String(item.title||title).slice(0,120),{x:.65,y:.5,w:12,h:1,fontSize:28,color:'78E5CC',bold:true,breakLine:false,fit:'shrink'});slide.addText(chunk,{x:.65,y:1.7,w:12,h:5,fontSize:21,color:'FFFFFF',fit:'shrink',valign:'top'});}}
  buffer=await ppt.write({outputType:'nodebuffer'});
 }
 if(format==='pdf'){
  buffer=await new Promise((resolve,reject)=>{const pdf=new PDFDocument({size:'A4',margin:50});const chunks=[];pdf.on('data',c=>chunks.push(c));pdf.on('end',()=>resolve(Buffer.concat(chunks)));pdf.on('error',reject);pdf.font('C:/Windows/Fonts/arial.ttf').fontSize(22).text(title).moveDown().fontSize(11).text(text,{lineGap:5});pdf.end();});
 }
 return saveArtifact(buffer,format,title);
}
