function New-InstallerConsentDialog([string]$TermsPath) {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    if (-not (Test-Path -LiteralPath $TermsPath -PathType Leaf)) { throw 'Condizioni mancanti: scaricare nuovamente il pacchetto Atlante.' }
    $terms = [IO.File]::ReadAllText($TermsPath, [Text.Encoding]::UTF8)
    if ([string]::IsNullOrWhiteSpace($terms)) { throw 'Condizioni non leggibili: scaricare nuovamente il pacchetto Atlante.' }
    $form = New-Object Windows.Forms.Form
    $form.Text = 'Atlante - Condizioni di utilizzo'
    $form.Size = New-Object Drawing.Size(760, 680)
    $form.MinimumSize = New-Object Drawing.Size(520, 480)
    $form.StartPosition = 'CenterScreen'
    $form.Font = New-Object Drawing.Font('Segoe UI', 10)
    $form.AutoScaleMode = 'Dpi'
    $form.MinimizeBox = $false
    $form.MaximizeBox = $false
    $form.Tag = $false
    $layout = New-Object Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.Padding = New-Object Windows.Forms.Padding(20)
    $layout.ColumnCount = 1
    $layout.RowCount = 4
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('AutoSize')))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent', 100)))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('AutoSize')))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('AutoSize')))
    $intro = New-Object Windows.Forms.Label
    $intro.Text = 'Prima di installare Atlante, leggi le condizioni. Se rifiuti, non viene installato alcun componente.'
    $intro.AutoSize = $true
    $intro.Dock = 'Fill'
    $intro.Margin = New-Object Windows.Forms.Padding(0, 0, 0, 14)
    $text = New-Object Windows.Forms.TextBox
    $text.Multiline = $true
    $text.ReadOnly = $true
    $text.ScrollBars = 'Vertical'
    $text.Dock = 'Fill'
    $text.BackColor = [Drawing.Color]::White
    $text.Text = $terms -replace "`r?`n", "`r`n"
    $check = New-Object Windows.Forms.CheckBox
    $check.Name = 'accept-conditions'
    $check.Text = 'Ho letto e accetto le responsabilita e le condizioni di utilizzo.'
    $check.AutoSize = $false
    $check.Dock = 'Fill'
    $check.Height = 60
    $check.Checked = $false
    $check.Margin = New-Object Windows.Forms.Padding(0, 16, 0, 16)
    $actions = New-Object Windows.Forms.FlowLayoutPanel
    $actions.AutoSize = $true
    $actions.Dock = 'Fill'
    $actions.FlowDirection = 'RightToLeft'
    $install = New-Object Windows.Forms.Button
    $install.Name = 'install'
    $install.Text = 'Installa'
    $install.Size = New-Object Drawing.Size(150, 42)
    $install.Margin = New-Object Windows.Forms.Padding(8, 0, 0, 0)
    $install.Enabled = $false
    $reject = New-Object Windows.Forms.Button
    $reject.Name = 'reject'
    $reject.Text = 'Rifiuta ed esci'
    $reject.Size = New-Object Drawing.Size(150, 42)
    $reject.DialogResult = 'Cancel'
    $actions.Controls.AddRange(@($install, $reject))
    $layout.Controls.Add($intro, 0, 0)
    $layout.Controls.Add($text, 0, 1)
    $layout.Controls.Add($check, 0, 2)
    $layout.Controls.Add($actions, 0, 3)
    $form.Controls.Add($layout)
    $form.CancelButton = $reject
    $form.AcceptButton = $install
    $form.Add_Shown({ $text.Select(0, 0); $form.ActiveControl = $check }.GetNewClosure())
    $check.Add_CheckedChanged({ $install.Enabled = $check.Checked }.GetNewClosure())
    $install.Add_Click({ if ($check.Checked) { $form.Tag = $true; $form.DialogResult = 'OK'; $form.Close() } }.GetNewClosure())
    return $form
}

function Show-InstallerConditions([string]$TermsPath) {
    $form = New-InstallerConsentDialog $TermsPath
    try { [void]$form.ShowDialog(); return ($form.Tag -eq $true -and $form.DialogResult -eq [Windows.Forms.DialogResult]::OK) }
    finally { $form.Dispose() }
}
