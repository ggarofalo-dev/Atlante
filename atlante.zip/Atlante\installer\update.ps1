. (Join-Path $PSScriptRoot 'startup.ps1')
function Update-ExistingAtlante([string]$Source,[string]$Root,[int]$Port=3210,[switch]$NoBrowser,[Nullable[bool]]$AutoStart=$null) {
    Set-InstallerStep 'files' 'Verifico la versione installata e preparo il pacchetto di aggiornamento...'
    $existing=Get-ExistingAtlante $Root
    if(!$existing){throw 'Installazione esistente non riconosciuta. Seleziona la cartella corretta.'}
    $configFile=Join-Path $Root 'runtime\install.json';$nodePath=$null
    if(Test-Path -LiteralPath $configFile){$config=Get-Content -LiteralPath $configFile -Raw|ConvertFrom-Json;$nodePath=$config.nodePath}
    if(!$nodePath -or !(Test-Path -LiteralPath $nodePath)){$candidate=Get-Command node.exe -ErrorAction SilentlyContinue;if($candidate){$nodePath=$candidate.Source}}
    if(!$nodePath -or !(Test-Path -LiteralPath $nodePath)){throw 'Node non trovato per aggiornare Atlante. Ripristina il runtime prima di riprovare.'}
    $health=$null
    try{$health=Invoke-RestMethod ("http://127.0.0.1:$Port/api/health") -TimeoutSec 3}catch{}
    if($health -and $health.app -ne 'atlante'){throw 'La porta di Atlante appartiene a un altro programma.'}
    if($health.busy -or $health.scheduled -or $health.maintenance.state -eq 'running'){throw 'Atlante sta elaborando richieste. Attendi che finisca prima di aggiornare.'}
    if($health){
        $statusFile=Join-Path $Root 'data\service\status.json'
        if(!(Test-Path -LiteralPath $statusFile)){throw 'Atlante e attivo senza supervisore riconosciuto. Arrestalo prima di aggiornare.'}
        $state=Get-Content -LiteralPath $statusFile -Raw|ConvertFrom-Json
        if($state.appPid -ne $health.pid){throw 'La porta di Atlante appartiene a un altra installazione. Arrestala prima di aggiornare.'}
    }
    $id=[Guid]::NewGuid().ToString();$directory=Join-Path $Root ('.maintenance\'+$id);$payload=Join-Path $directory 'payload'
    New-Item -ItemType Directory -Path $payload -Force|Out-Null
    $manifest=Get-Content -LiteralPath (Join-Path $Source 'manifest.json') -Raw|ConvertFrom-Json
    $seen=@{}
    foreach($entry in $manifest.files){
        $relative=$entry.path.Replace('/','\')
        if($relative -notmatch '^(?:src\\|atlanteLibs\\|public\\|scripts\\|installer\\|config\\google-desktop\.json$|package\.json$|package-lock\.json$|start\.cmd$|installa\.bat$|Installa Atlante\.vbs$|LEGGIMI\.txt$)' -or $relative.Contains('..') -or $relative.Contains(':') -or $seen.ContainsKey($relative.ToLowerInvariant())){throw "File non consentito nel pacchetto: $relative"}
        $seen[$relative.ToLowerInvariant()]=$true
        $target=Join-Path $payload $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force|Out-Null
        Copy-Item -LiteralPath (Join-Path $Source $relative) -Destination $target
        if((Get-FileHash -LiteralPath $target).Hash -ne $entry.sha256){throw "Checksum aggiornamento non valido: $relative"}
    }
    $jobFile=Join-Path $directory 'job.json'
    @{id=$id;kind='update';directory=$directory;payload=$payload;root=$existing.root;nodePath=$nodePath;appPid=$health.pid;port=$Port;version=$manifest.version}|ConvertTo-Json|Set-Content -LiteralPath $jobFile -Encoding UTF8
    if($script:progressFile){$script:installProgress.log=Join-Path $directory 'worker.log';Publish-InstallerProgress}
    Set-InstallerStep 'dependencies' 'Preparo e verifico le librerie del nuovo pacchetto...'
    $workerScript=Join-Path $payload 'scripts\maintenance-worker.ps1'
    $command="& '$($workerScript.Replace("'","''"))' -JobFile '$($jobFile.Replace("'","''"))'"
    $encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
    $worker=Start-Process powershell.exe -ArgumentList @('-NoProfile','-NonInteractive','-EncodedCommand',$encoded) -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $directory 'worker.log') -RedirectStandardError (Join-Path $directory 'worker-error.log')
    $processHandle=$worker.Handle
    $phase='dependencies'
    while(!$worker.WaitForExit(500)){
        $resultFile=Join-Path $directory 'result.json'
        if(Test-Path -LiteralPath $resultFile){
            try{$result=Get-Content -LiteralPath $resultFile -Raw|ConvertFrom-Json}catch{continue}
            if($result.phase -in @('apply','start') -and $result.phase -ne $phase){$phase=$result.phase;Set-InstallerStep $phase $result.message}
        }
    }
    $worker.WaitForExit();$worker.Refresh()
    $result=Get-Content -LiteralPath (Join-Path $directory 'result.json') -Raw|ConvertFrom-Json
    if(($null -ne $worker.ExitCode -and $worker.ExitCode -ne 0) -or $result.state -ne 'done'){throw ($result.message+' Dettagli in '+$directory)}
    if($phase -eq 'dependencies'){Set-InstallerStep 'apply' 'Pacchetto applicato; dati e modelli conservati.'}
    if($phase -ne 'start'){Set-InstallerStep 'start' 'Atlante aggiornato e riavviato.'}
    Register-AtlanteInstallation $Root
    if($null -ne $AutoStart){Set-AtlanteStartup $Root ([bool]$AutoStart)}
    Complete-InstallerProgress $true ('Aggiornamento completato alla versione '+$manifest.version+'. Dati, configurazione e modelli conservati.')
    if(!$NoBrowser){Start-Process "http://localhost:$Port"}
}
