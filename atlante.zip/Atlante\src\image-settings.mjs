import {existsSync,readFileSync,writeFileSync,renameSync,mkdirSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {localComfyUrl,validateWorkflow,ComfyUI} from './comfyui.mjs';
export const imageDefaults={backend:'sd',url:'http://127.0.0.1:8188',checkpoint:'',sdModel:'sd15.safetensors',width:512,height:512,steps:15,cfg:7,seed:42,strength:.55,negative:'',sampler:'euler',scheduler:'normal',customWorkflow:false,workflows:{}};
export function imageParameters(input={}){
 const p={...imageDefaults,...input};for(const [key,min,max,integer]of [['width',256,2048,true],['height',256,2048,true],['steps',4,100,true],['cfg',0,30,false],['seed',0,4294967295,true],['strength',.1,1,false]]){p[key]=Number(p[key]);if(!Number.isFinite(p[key])||p[key]<min||p[key]>max||integer&&!Number.isInteger(p[key]))throw Error('Parametro immagine non valido: '+key);}if(p.width%64||p.height%64)throw Error('Le dimensioni devono essere multipli di 64');if(typeof p.negative!=='string'||p.negative.length>2000)throw Error('Prompt negativo massimo 2000 caratteri');for(const key of ['sampler','scheduler'])if(typeof p[key]!=='string'||!/^[a-zA-Z0-9_.+-]{1,80}$/.test(p[key]))throw Error('Parametro non valido: '+key);return p;
}
export class ImageSettings {
 constructor(root){this.root=root;this.file=join(root,'data','image-settings.json');}
 get(){return existsSync(this.file)?{...imageDefaults,...JSON.parse(readFileSync(this.file,'utf8'))}:{...imageDefaults};}
 sdModels(){return readdirSync(join(this.root,'models')).filter(n=>/\.(safetensors|ckpt)$/i.test(n));}
 save(input){const p=imageParameters(input);if(!['sd','comfyui'].includes(p.backend))throw Error('Motore immagini non valido');p.url=localComfyUrl(p.url);if(typeof p.checkpoint!=='string'||p.checkpoint.length>250||p.checkpoint.includes('..')||/^[\\/]|:/.test(p.checkpoint))throw Error('Checkpoint non valido');if(!this.sdModels().includes(p.sdModel))throw Error('Modello SD non trovato');if(typeof p.customWorkflow!=='boolean')throw Error('Scelta workflow non valida');const workflows={};for(const [mode,graph]of Object.entries(p.workflows||{})){if(!['generate','transform','inpaint'].includes(mode))throw Error('Tipo workflow non valido');workflows[mode]=validateWorkflow(graph);}if(JSON.stringify(workflows).length>150000)throw Error('Workflow troppo grande');const config=Object.fromEntries(Object.keys(imageDefaults).map(k=>[k,p[k]]));config.workflows=workflows;mkdirSync(join(this.root,'data'),{recursive:true});const temp=this.file+'.'+randomUUID()+'.tmp';writeFileSync(temp,JSON.stringify(config,null,2),'utf8');renameSync(temp,this.file);return config;}
 async catalog(url,signal){return new ComfyUI(url||this.get().url).catalog(signal);}
}
