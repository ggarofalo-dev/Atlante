param([Parameter(Mandatory=$true)][string]$JobFile)
$ErrorActionPreference = 'Stop'
$job = Get-Content -LiteralPath $JobFile -Raw -Encoding UTF8 | ConvertFrom-Json
$root = [IO.Path]::GetFullPath($job.root).TrimEnd('\')
$stage = [IO.Path]::GetFullPath($job.directory)
if (-not $stage.StartsWith($root + '\.maintenance\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid maintenance directory' }
if ($root -eq [IO.Path]::GetPathRoot($root) -or -not (Test-Path -LiteralPath (Join-Path $root 'src\server.mjs')) -or ((Get-Item -LiteralPath $root).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Invalid Atlante root' }
function Child-Path([string]$Path) {
    $absolute = [IO.Path]::GetFullPath($Path)
    if (-not $absolute.StartsWith($root + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Path outside Atlante' }
    return $absolute
}
function Result([string]$State,[string]$Message) {
    @{id=$job.id;kind=$job.kind;state=$State;message=$Message;updated=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $stage 'result.json') -Encoding UTF8
}
function Remove-Tree([string]$Path) {
    $absolute = [IO.Path]::GetFullPath($Path)
    if ($absolute -ne $root -and -not $absolute.StartsWith($root + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Removal outside Atlante' }
    $item = Get-Item -LiteralPath $absolute -Force
    # Unlink junctions without visiting the shared directory they point to.
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
        if ($item.PSIsContainer) { [IO.Directory]::Delete($absolute) } else { Remove-Item -LiteralPath $absolute -Force }
        return
    }
    if ($item.PSIsContainer) { foreach ($child in Get-ChildItem -LiteralPath $absolute -Force) { Remove-Tree $child.FullName } }
    Remove-Item -LiteralPath $absolute -Force
}
function Stop-Atlante {
    $status = Join-Path $root 'data\service\status.json'
    $supervisor = $null
    if (Test-Path -LiteralPath $status) {
        $state = Get-Content $status -Raw -Encoding UTF8 | ConvertFrom-Json
        $supervisor = $state.supervisorPid
        $owned = Get-CimInstance Win32_Process -Filter "ProcessId=$($state.appPid)" -ErrorAction SilentlyContinue
        if ($owned -and $owned.ParentProcessId -eq $supervisor -and $owned.CommandLine -match 'src[/\\]server.mjs') { $job.appPid = $state.appPid }
    }
    if ($supervisor) {
        $process = Get-CimInstance Win32_Process -Filter "ProcessId=$supervisor"
        if ($process -and $process.CommandLine.Replace('/','\').Contains($root) -and $process.CommandLine -match 'watchdog.mjs') { Stop-Process -Id $supervisor -Force }
    }
    $process = Get-CimInstance Win32_Process -Filter "ProcessId=$($job.appPid)"
    if ($process -and $process.ExecutablePath -eq $job.nodePath -and $process.CommandLine -match 'src[/\\]server.mjs' -and ($process.CommandLine.Replace('/','\').Contains($root) -or $process.ParentProcessId -eq $supervisor)) { Stop-Process -Id $job.appPid -Force }
    Start-Sleep -Seconds 2
}
function Start-Atlante {
    $arguments = '-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + (Join-Path $root 'scripts\run-background.ps1') + '"'
    Start-Process powershell.exe -ArgumentList $arguments -WindowStyle Hidden -WorkingDirectory $root
}
function Healthy {
    for ($i=0;$i -lt 40;$i++) {
        Start-Sleep -Seconds 2
        try { $health = Invoke-RestMethod ("http://127.0.0.1:$($job.port)/api/health") -TimeoutSec 2; if ($health.app -eq 'atlante') { return $true } } catch {}
    }
    return $false
}
$rollback = Join-Path $stage 'rollback'
$changed = $false
try {
    Result 'running' 'Preparazione operazione'
    if ($job.kind -eq 'update') {
        $nodeDirectory = Split-Path $job.nodePath
        $npm = Join-Path $nodeDirectory 'node_modules\npm\bin\npm-cli.js'
        if (-not (Test-Path -LiteralPath $npm)) { throw 'npm non trovato: ripetere installa.bat' }
        Push-Location $job.payload
        try {
            $env:PATH = $nodeDirectory + ';' + $env:PATH
            $ErrorActionPreference = 'Continue'
            & $job.nodePath $npm ci --omit=dev --ignore-scripts --no-audit --no-fund --cache (Join-Path $root '.cache\npm') *> (Join-Path $stage 'dependencies.log')
            $ErrorActionPreference = 'Stop'
            if ($LASTEXITCODE -ne 0) { throw 'Download librerie fallito. Consultare dependencies.log.' }
            $ErrorActionPreference = 'Continue'
            & $job.nodePath (Join-Path $job.payload 'installer\verify-runtime.mjs') *> (Join-Path $stage 'verification.log')
            $ErrorActionPreference = 'Stop'
            if ($LASTEXITCODE -ne 0) { throw 'Verifica librerie fallita. Consultare verification.log.' }
        } finally { Pop-Location }
    }
    Start-Sleep -Seconds 3
    if ($job.kind -eq 'uninstall') {
        $installConfig = Join-Path $root 'runtime\install.json'
        if ((Test-Path -LiteralPath $installConfig) -and (Get-NetFirewallRule -Name 'Atlante Local - Private LAN' -ErrorAction SilentlyContinue)) {
            $helper = Join-Path $root 'installer\remove-system.ps1'
            $process = Start-Process powershell.exe -Verb RunAs -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+$helper+'" -NodePath "'+$job.nodePath+'"') -Wait -PassThru -WindowStyle Hidden
            if ($process.ExitCode -ne 0) { throw 'Rimozione firewall non completata' }
        }
        Stop-Atlante
        $shell = New-Object -ComObject WScript.Shell
        foreach ($folder in @([Environment]::GetFolderPath('Startup'),[Environment]::GetFolderPath('Desktop'))) {
            $link = Join-Path $folder 'Atlante.lnk'
            if (Test-Path -LiteralPath $link) { if ($shell.CreateShortcut($link).WorkingDirectory.TrimEnd('\') -eq $root) { Remove-Item -LiteralPath $link } }
        }
        $task = Get-ScheduledTask -TaskName 'Atlante Local - Always On' -ErrorAction SilentlyContinue
        if ($task -and ($task.Actions.Arguments -join ' ').Contains($root)) { Unregister-ScheduledTask -TaskName $task.TaskName -Confirm:$false }
        if ($job.keepData) {
            $saved = Join-Path (Split-Path $root) ('Atlante-dati-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
            if ([IO.Path]::GetFullPath((Split-Path $saved)) -ne [IO.Path]::GetFullPath((Split-Path $root))) { throw 'Invalid preservation path' }
            Move-Item -LiteralPath (Child-Path (Join-Path $root 'data')) -Destination $saved
        }
        # The root was explicitly authorized through the application's uninstall confirmation.
        if ($root -eq [IO.Path]::GetPathRoot($root) -or -not (Test-Path -LiteralPath (Join-Path $root 'src\server.mjs'))) { throw 'Invalid uninstall root' }
        Set-Location $env:TEMP
        Remove-Tree $root
        exit 0
    }
    Stop-Atlante
    New-Item -ItemType Directory -Path $rollback -Force | Out-Null
    if ($job.kind -eq 'restore') {
        Move-Item -LiteralPath (Child-Path (Join-Path $root 'data')) -Destination (Join-Path $rollback 'data')
        $changed = $true
        Copy-Item -LiteralPath (Join-Path $job.payload 'data') -Destination $root -Recurse
    } elseif ($job.kind -eq 'update') {
        $changed = $true
        foreach ($name in @('src','public','scripts','installer','package.json','package-lock.json','start.cmd','node_modules','config')) {
            if (-not (Test-Path -LiteralPath (Join-Path $job.payload $name))) { continue }
            $old = Child-Path (Join-Path $root $name)
            if (Test-Path -LiteralPath $old) { Move-Item -LiteralPath $old -Destination (Join-Path $rollback $name) }
            Copy-Item -LiteralPath (Join-Path $job.payload $name) -Destination $root -Recurse
        }
    } else { throw 'Operazione non valida' }
    Start-Atlante
    if (-not (Healthy)) { throw 'La nuova installazione non risponde: ripristino automatico' }
    Result 'done' 'Operazione completata'
} catch {
    $message = $_.Exception.Message
    if ($changed) {
        try {
            $health = Invoke-RestMethod ("http://127.0.0.1:$($job.port)/api/health") -TimeoutSec 2
            $job.appPid = $health.pid
        } catch {}
        try { Stop-Atlante } catch {}
        foreach ($item in Get-ChildItem -LiteralPath $rollback) {
            $target = Child-Path (Join-Path $root $item.Name)
            if (Test-Path -LiteralPath $target) { Remove-Tree $target }
            Move-Item -LiteralPath $item.FullName -Destination $target
        }
        try { Start-Atlante } catch {}
    }
    Result 'error' $message
    exit 1
}
