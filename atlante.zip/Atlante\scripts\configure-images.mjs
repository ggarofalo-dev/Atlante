import {fileURLToPath} from 'node:url';
import {ImageSettings} from '../src/image-settings.mjs';
import {ImageRuntime} from '../src/image-runtime.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const runtime=new ImageRuntime({root,settings:new ImageSettings(root)});
try{const result=await runtime.configure('auto',undefined,message=>console.log(message));console.log(result.message);}catch(error){console.error(error.message);process.exitCode=1;}
