import {randomUUID} from 'node:crypto';
const minute=60000;
const formatter=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Rome',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
function localParts(at){return Object.fromEntries(formatter.formatToParts(new Date(at)).map(p=>[p.type,p.value]));}
function civil(at){const p=localParts(at);return `${p.year}-${p.month}-${p.day}`;}
function dateValid(day){return /^\d{4}-\d{2}-\d{2}$/.test(day)&&Number.isFinite(Date.parse(day+'T12:00:00Z'))&&new Date(day+'T12:00:00Z').toISOString().slice(0,10)===day;}
function localTime(day,time){const nominal=Date.parse(`${day}T${time}:00Z`);return [nominal-2*3600000,nominal-3600000].filter(at=>{const p=localParts(at);return civil(at)===day&&`${p.hour}:${p.minute}`===time;}).sort((a,b)=>a-b)[0]??null;}
export function nextOccurrence(job,after){
 if(job.mode==='saved')return null;
 if(job.mode==='once'){const at=localTime(job.date,job.time);return at!==null&&at>after?at:null;}
 const base=Date.parse(civil(after)+'T12:00:00Z');
 for(let i=0;i<370;i++){const date=new Date(base+i*86400000),day=date.toISOString().slice(0,10);if(job.mode==='weekly'&&!job.days.includes(date.getUTCDay()))continue;const at=localTime(day,job.time);if(at!==null&&at>after)return at;}
 return null;
}
export function validateJob(input){
 if(!input||typeof input!=='object')throw Error('Prompt non valido');
 const {title,prompt,model,mode='saved',time='08:00',date='',days=[],web=false,enabled=true}=input;
 if(typeof title!=='string'||!title.trim()||title.length>100)throw Error('Titolo richiesto, massimo 100 caratteri');
 if(typeof prompt!=='string'||!prompt.trim()||prompt.length>12000)throw Error('Prompt richiesto, massimo 12000 caratteri');
 if(typeof model!=='string'||!model.trim()||model.length>100||/cloud/i.test(model))throw Error('Scegli un modello locale');
 if(!['saved','daily','weekly','once'].includes(mode)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))throw Error('Programmazione non valida');
 if(typeof web!=='boolean'||typeof enabled!=='boolean')throw Error('Opzioni non valide');
 if(!Array.isArray(days)||days.some(d=>!Number.isInteger(d)||d<0||d>6)||(mode==='weekly'&&!days.length))throw Error('Scegli almeno un giorno della settimana');
 if(mode==='once'&&(!dateValid(date)||localTime(date,time)===null))throw Error('Data o orario italiano non valido');
 return {title:title.trim(),prompt:prompt.trim(),model:model.trim(),mode,time,date:mode==='once'?date:'',days:[...new Set(days)].sort(),web,enabled:mode==='saved'?false:enabled};
}
export class Scheduler{
 constructor(store,{now=Date.now,isBusy=()=>false,execute}={}){
  this.store=store;this.db=store.db;this.now=now;this.isBusy=isBusy;this.execute=execute;this.lastTick=now();this.running=null;this.queue=[];this.timer=null;this.stopped=false;
  this.db.exec(`CREATE TABLE IF NOT EXISTS prompt_jobs(id TEXT PRIMARY KEY,json TEXT,next_at INTEGER);
   CREATE TABLE IF NOT EXISTS prompt_runs(id TEXT PRIMARY KEY,job_id TEXT,title TEXT,scheduled_at INTEGER,started INTEGER,finished INTEGER,status TEXT,session TEXT,detail TEXT);`);
 }
 jobs(){return this.db.prepare('SELECT * FROM prompt_jobs ORDER BY rowid DESC').all().map(row=>({id:row.id,...JSON.parse(row.json),nextAt:row.next_at}));}
 status(){return {timezone:'Europe/Rome',running:this.running,jobs:this.jobs(),recent:this.db.prepare('SELECT id,job_id,title,scheduled_at,started,finished,status,CASE WHEN EXISTS(SELECT 1 FROM messages WHERE messages.session=prompt_runs.session) THEN session ELSE NULL END session,detail FROM prompt_runs ORDER BY rowid DESC LIMIT 100').all()};}
 save(input){
  const job=validateJob(input),id=input.id||randomUUID();if(typeof id!=='string'||!/^[-a-f0-9]{36}$/.test(id))throw Error('Identificativo non valido');
  if(input.id&&!this.db.prepare('SELECT id FROM prompt_jobs WHERE id=?').get(id))throw Error('Prompt non trovato');
  const nextAt=job.enabled?nextOccurrence(job,this.now()):null;if(job.enabled&&nextAt===null)throw Error('Scegli una data futura');
  this.cancelPending(id,'Programmazione modificata');this.db.prepare('INSERT INTO prompt_jobs VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json,next_at=excluded.next_at').run(id,JSON.stringify(job),nextAt);return {id,...job,nextAt};
 }
 remove(id){if(typeof id!=='string')throw Error('Identificativo richiesto');this.cancelPending(id,'Prompt eliminato');this.db.prepare('DELETE FROM prompt_jobs WHERE id=?').run(id);}
 cancelPending(id,detail){this.queue=this.queue.filter(entry=>entry.job.id!==id);this.db.prepare("UPDATE prompt_runs SET status='skipped',finished=?,detail=? WHERE job_id=? AND status='queued'").run(this.now(),detail,id);}
 toggle(id,enabled){const job=this.jobs().find(j=>j.id===id);if(!job)throw Error('Prompt non trovato');if(typeof enabled!=='boolean')throw Error('Stato non valido');return this.save({...job,enabled});}
 enqueue(job,scheduledAt,manual=false){const id=randomUUID();this.db.prepare("INSERT INTO prompt_runs VALUES(?,?,?,?,NULL,NULL,'queued',NULL,'')").run(id,job.id,job.title,scheduledAt);this.queue.push({id,job,manual});return id;}
 manual(id){const job=this.jobs().find(j=>j.id===id);if(!job)throw Error('Prompt non trovato');if(this.queue.some(e=>e.job.id===id)||this.running?.jobId===id)throw Error('Questo prompt è già in esecuzione o in attesa');const runId=this.enqueue(job,this.now(),true);this.pump();return {runId};}
 start(){
  this.stopped=false;const now=this.now();this.lastTick=now;
  this.db.prepare("UPDATE prompt_runs SET status='interrupted',finished=?,detail='Atlante riavviato: esecuzione non recuperata' WHERE status IN ('running','queued')").run(now);
  for(const job of this.jobs()){
   if(job.enabled&&job.nextAt!==null&&job.nextAt<=now)this.db.prepare("INSERT INTO prompt_runs VALUES(?,?,?,?,NULL,?,'skipped',NULL,?)").run(randomUUID(),job.id,job.title,job.nextAt,now,'PC o Atlante non disponibile all’orario previsto: esecuzione non recuperata');
   const next=job.enabled?nextOccurrence(job,now):null;if(job.mode==='once'&&job.enabled&&!next)job.enabled=false;this.db.prepare('UPDATE prompt_jobs SET json=?,next_at=? WHERE id=?').run(JSON.stringify(validateJob(job)),next,job.id);
  }
  this.timer=setInterval(()=>this.tick(),10000);this.timer.unref();
 }
 stop(){this.stopped=true;clearInterval(this.timer);}
 tick(){
  if(this.stopped)return;const now=this.now(),gap=now-this.lastTick;
  if(gap>minute){for(const entry of [...this.queue])this.cancelPending(entry.job.id,'PC sospeso o Atlante non disponibile: esecuzione in attesa saltata');}
  for(const job of this.jobs().filter(j=>j.enabled&&j.nextAt!==null&&j.nextAt<=now)){
   const missed=gap>minute||now-job.nextAt>=minute||job.nextAt<this.lastTick;
   if(missed){this.db.prepare("INSERT INTO prompt_runs VALUES(?,?,?,?,NULL,?,'skipped',NULL,?)").run(randomUUID(),job.id,job.title,job.nextAt,now,'Orario trascorso mentre Atlante non era disponibile: esecuzione saltata');}
   else this.enqueue(job,job.nextAt);
   const next=nextOccurrence(job,now);if(job.mode==='once')job.enabled=false;this.db.prepare('UPDATE prompt_jobs SET json=?,next_at=? WHERE id=?').run(JSON.stringify(validateJob(job)),job.enabled?next:null,job.id);
  }
  this.lastTick=now;this.pump();
 }
 async pump(){
  if(this.stopped||this.running||this.isBusy()||!this.queue.length)return;
  const {id,job}=this.queue.shift(),session=randomUUID();this.running={id,jobId:job.id,title:job.title,session};
  this.db.prepare("UPDATE prompt_runs SET status='running',started=?,session=? WHERE id=?").run(this.now(),session,id);
  this.db.prepare('INSERT INTO session_titles VALUES(?,?) ON CONFLICT(session) DO UPDATE SET title=excluded.title').run(session,`${job.title} · ${new Date(this.now()).toLocaleString('it-IT',{timeZone:'Europe/Rome'})}`);
  try{
   const result=await this.execute({message:job.prompt,model:job.model,web:job.web,session,remember:true});
   if(!this.store.history(session).length){this.store.message(session,'user',job.prompt);this.store.message(session,'assistant',result.answer);}
   const last=this.db.prepare("SELECT id,content FROM messages WHERE session=? AND role='assistant' ORDER BY id DESC LIMIT 1").get(session);
   const sources=(result.sources||[]).filter(s=>/^https?:\/\//.test(s.url));
   if(last)this.db.prepare('UPDATE messages SET content=? WHERE id=?').run(result.answer+(sources.length?'\n\nFonti consultate:\n'+sources.map((s,i)=>`[${i+1}] ${s.title}\n${s.url}`).join('\n'):''),last.id);
   if(result.artifact&&!result.artifact.url.endsWith('.png'))this.db.prepare('INSERT INTO message_files VALUES(?,?,?)').run(last.id,result.artifact.name,result.artifact.url);
   this.db.prepare('UPDATE prompt_runs SET status=?,finished=?,detail=? WHERE id=?').run(result.webError?'error':'done',this.now(),result.warning||'',id);
  }catch(e){if(!this.store.history(session).length)this.store.message(session,'user',job.prompt);this.store.message(session,'assistant','Esecuzione non completata: '+e.message);this.db.prepare("UPDATE prompt_runs SET status='error',finished=?,detail=? WHERE id=?").run(this.now(),String(e.message).slice(0,1000),id);}
  finally{this.running=null;if(!this.stopped)this.pump();}
 }
}
